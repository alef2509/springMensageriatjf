package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import java.time.ZonedDateTime;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class DocumentoTransporteCanceladoEvent implements DomainEvent {

	private final String id;
	private final ZonedDateTime quando;
	private final String usuario;

	public static DocumentoTransporteCanceladoEvent from(final DocumentoTransporte documentoTransporte) {
		return new DocumentoTransporteCanceladoEvent(documentoTransporte.getId().toString(),
													 documentoTransporte.getSituacao().getQuando(),
													 documentoTransporte.getSituacao().getUsuarioId());
	}

}
