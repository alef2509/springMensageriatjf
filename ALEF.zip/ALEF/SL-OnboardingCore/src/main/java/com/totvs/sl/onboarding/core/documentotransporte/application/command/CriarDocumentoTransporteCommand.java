package com.totvs.sl.onboarding.core.documentotransporte.application.command;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.LocalDate;
import java.time.ZonedDateTime;

@Data(staticConstructor = "of")
public final class CriarDocumentoTransporteCommand {

    private  final String numero;
    private  final ZonedDateTime emissao;
    private  final String serie;
    private  final String modelo;
    private  final String chaveAcesso;
    private  final CotacaoFreteId cotacaoFreteId;
    private  final ClienteId remetenteId;
    private  final ClienteId destinatarioId;
    private  final ClienteId pagadorFreteId;
}
