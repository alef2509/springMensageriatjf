package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class DocumentoTransporteDocumentoCargaExcluidoEvent implements DomainEvent {


	private final String documentoTransporteId;
	private final String id;

	public static DocumentoTransporteDocumentoCargaExcluidoEvent from(final DocumentoTransporte documentoTransporte,
																	  final DocumentoCargaId documentoCargaId) {


		return new DocumentoTransporteDocumentoCargaExcluidoEvent(documentoTransporte.getId().toString(),
																  documentoCargaId.getId().toString());
	}

}
