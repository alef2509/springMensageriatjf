package com.totvs.sl.onboarding.core.documentotransporte.application;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingPublisher;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteDomainRepository;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition;
import lombok.AllArgsConstructor;
import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
@AllArgsConstructor
public class DocumentoTransporteApplicationService {

    private static final String CHAVEACESSO_IDX = "documentotransportechave_idx";

    private final DocumentoTransporteDomainRepository repository;
    private final OnboardingPublisher publisher;

    public DocumentoTransporteId handle(final CriarDocumentoTransporteCommand cmd) {

        var documentoTransporte = DocumentoTransporte.builder()
                .id(DocumentoTransporteId.generate())
                .numero(cmd.getNumero())
                .serie(cmd.getSerie())
                .emissao(cmd.getEmissao())
                .modelo(cmd.getModelo())
                .chaveAcesso(cmd.getChaveAcesso())
                .cotacaoFreteId(cmd.getCotacaoFreteId())
                .remetenteId(cmd.getRemetenteId())
                .destinatarioId(cmd.getRemetenteId())
                .pagadorFreteId(cmd.getPagadorFreteId())
                .build();

        try {
            repository.insert(documentoTransporte);
        } catch (JpaSystemException exception) {
            throw this.tratarExceptionPersistencia(exception, cmd.getChaveAcesso());
        }

        publisher.dispatch(documentoTransporte.getEvents());

        return documentoTransporte.getId();

    }

    public void handle(final AlterarDocumentoTransporteCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        documentoTransporte.alterar(cmd.getCotacaoFreteId(),
                                    cmd.getRemetenteId(),
                                    cmd.getDestinatarioId(),
                                    cmd.getPagadorFreteId());

        repository.update(documentoTransporte);

        publisher.dispatch(documentoTransporte.getEvents());

    }

    public void handle(final CancelarDocumentoTransporteCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        documentoTransporte.cancelar(cmd.getIdCancel());

        repository.update(documentoTransporte);

        publisher.dispatch(documentoTransporte.getEvents());
    }


    public void handle(final AnularDocumentoTransporteCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        documentoTransporte.anular(cmd.getIdAnula());

        repository.update(documentoTransporte);

        publisher.dispatch(documentoTransporte.getEvents());
    }

    public void handle(final AutorizarDocumentoTransporteCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        documentoTransporte.autorizar(cmd.getIdAutoriza(), cmd.getChaveAcesso());

        repository.update(documentoTransporte);

        publisher.dispatch(documentoTransporte.getEvents());
    }

    public void handle(final AdicionarDocumentoCargaCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        var documentoCarga = DocumentoCarga.builder()
                .id(DocumentoCargaId.generate())
                .emissao(cmd.getEmissao())
                .numero(cmd.getNumero())
                .serie(cmd.getSerie())
                .modelo(cmd.getModelo())
                .chaveAcesso(cmd.getChaveAcesso())
                .build();

        documentoTransporte.adicionarDocumentoCarga(documentoCarga);
        repository.update(documentoTransporte);
        publisher.dispatch(documentoTransporte.getEvents());
    }

    public void handle(final ExcluirDocumentoCargaCommand cmd) {

        var documentoTransporte = repository.findByIdOrThrowNotFound(cmd.getId());

        documentoTransporte.excluirDocumentoCarga(cmd.getIdCarga());
        repository.update(documentoTransporte);
        publisher.dispatch(documentoTransporte.getEvents());
    }

    private RuntimeException tratarExceptionPersistencia(final JpaSystemException exception,
                                                         final String chaveAcesso) {
        var cause = exception.getRootCause();

        if ((cause != null) && (cause.getMessage().contains(CHAVEACESSO_IDX)))
            return new ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition(chaveAcesso);

        return exception;
    }
}


