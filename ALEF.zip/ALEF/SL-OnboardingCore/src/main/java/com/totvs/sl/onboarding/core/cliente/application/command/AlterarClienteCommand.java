package com.totvs.sl.onboarding.core.cliente.application.command;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;

import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarClienteCommand {
	private final ClienteId id;
	private final String nome;
}
