package com.totvs.sl.onboarding.core.cliente.application.command;

import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;

import lombok.Data;

@Data(staticConstructor = "of")
public final class CriarClienteCommand {
	private final String nome;
	private final DocumentoIdentificacao documento;
}
