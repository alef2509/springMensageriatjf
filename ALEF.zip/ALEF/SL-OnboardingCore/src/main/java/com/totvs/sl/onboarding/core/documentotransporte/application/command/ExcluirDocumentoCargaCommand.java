package com.totvs.sl.onboarding.core.documentotransporte.application.command;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.Data;

@Data(staticConstructor = "of")
public class ExcluirDocumentoCargaCommand {
    private final DocumentoTransporteId id;
    private final DocumentoCargaId idCarga;
}
