package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAlteradoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAnuladoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAutorizadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCanceladoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCriadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaAdicionadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaExcluidoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteConstraintException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteNaoPermiteAutorizacaoSemChaveAcessoException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteSituacaoNaoPermiteAnulacaoException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteSituacaoNaoPermiteAutorizacaoException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteSituacaoNaoPermiteCancelarException;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@Aggregate
@Table(name = "documento_transporte")
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)

//DATREINOLOG-264
public class DocumentoTransporte extends AggregateDomainMetadataInfo<DocumentoTransporteId> {

	@Size(max = 9, message = "DocumentoTransporte.numero.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoTransporte.numero.Pattern")
	@NotBlank(message = "DocumentoTransporte.numero.NotBlank")
	private String numero;

	@Size(max = 3, message = "DocumentoTransporte.serie.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoTransporte.serie.Pattern")
	@NotBlank(message = "DocumentoTransporte.serie.NotBlank")
	private String serie;

	@NotNull(message = "DocumentoTransporte.emissao.NotNull")
	private ZonedDateTime emissao;

	@Size(max = 2, message = "DocumentoTransporte.modelo.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoTransporte.modelo.Pattern")
	@NotBlank(message = "DocumentoTransporte.modelo.NotBlank")
	private String modelo;

	@Size(min = 44, max = 44, message = "DocumentoTransporte.chaveAcesso.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoTransporte.chaveAcesso.Pattern")
	private String chaveAcesso;

	@NotNull(message = "DocumentoTransporte.situacao.NotNull")

	private RegistroSituacao situacao;
	private CotacaoFreteId cotacaoFreteId;
	private ClienteId remetenteId;
	private ClienteId destinatarioId;
	private ClienteId pagadorFreteId;
	private List<RegistroSituacao> historicoSituacao = new ArrayList<>();
	private List<DocumentoCarga> documentosCarga = new ArrayList<>();

	@Builder
	public DocumentoTransporte(DocumentoTransporteId id,
							   String numero,
							   String serie,
							   ZonedDateTime emissao,
							   String modelo,
							   String chaveAcesso,
							   CotacaoFreteId cotacaoFreteId,
							   ClienteId remetenteId,
							   ClienteId destinatarioId,
							   ClienteId pagadorFreteId) {
		super(id);
		this.numero = numero;
		this.serie = serie;
		this.emissao = emissao;
		this.modelo = modelo;
		this.chaveAcesso = chaveAcesso;
		this.situacao = RegistroSituacao.ofDigitado();
		this.historicoSituacao.add(this.situacao);
		this.cotacaoFreteId = cotacaoFreteId;
		this.remetenteId = remetenteId;
		this.destinatarioId = destinatarioId;
		this.pagadorFreteId = pagadorFreteId;

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBDocumentoTransporteConstraintException(violations);
		});

		this.registerEvent(DocumentoTransporteCriadoEvent.from(this));

	}

	public Optional<CotacaoFreteId> getCotacaoFreteId() {
		return Optional.ofNullable(this.cotacaoFreteId);
	}

	public Optional<ClienteId> getRemetenteId() {
		return Optional.ofNullable(this.remetenteId);
	}

	public Optional<ClienteId> getDestinatarioId() {
		return Optional.ofNullable(this.destinatarioId);
	}

	public Optional<ClienteId> getPagadorFreteId() {
		return Optional.ofNullable(this.pagadorFreteId);
	}

	//DATREINOLOG-265
	public void anular(String usuarioId) {

		if (this.situacao.isAnulado()) {
			return;
		}

		if (!this.situacao.isDigitado() && !this.situacao.isAutorizado()) {
			throw new ONBDocumentoTransporteSituacaoNaoPermiteAnulacaoException();
		}

		this.situacao = RegistroSituacao.ofAnulado(usuarioId);
		this.historicoSituacao.add(this.situacao);

		this.registerEvent(DocumentoTransporteAnuladoEvent.from(this));
	}

	//DATREINOLOG-265
	public void autorizar(String usuarioId, String chaveAcesso) {

		if (this.situacao.isAutorizado()) {
			return;
		}

		if (!this.situacao.isDigitado()) {
			throw new ONBDocumentoTransporteSituacaoNaoPermiteAutorizacaoException();
		}

		if (chaveAcesso == null) {
			throw new ONBDocumentoTransporteNaoPermiteAutorizacaoSemChaveAcessoException();
		}

		this.chaveAcesso = chaveAcesso;
		this.situacao = RegistroSituacao.ofAutorizado(usuarioId);
		this.historicoSituacao.add(this.situacao);

		this.registerEvent(DocumentoTransporteAutorizadoEvent.from(this));

	}

	//DATREINOLOG-265
	public void cancelar(String usuarioId) {

		if (this.situacao.isCancelado()) {
			return;
		}

		if (!this.situacao.isDigitado() && !this.situacao.isAutorizado()) {
			throw new ONBDocumentoTransporteSituacaoNaoPermiteCancelarException();
		}

		this.situacao = RegistroSituacao.ofCancelado(usuarioId);
		this.historicoSituacao.add(this.situacao);

		this.registerEvent(DocumentoTransporteCanceladoEvent.from(this));
	}

	//DATREINOLOG-265
	public void alterar(CotacaoFreteId cotacaoFreteId,
						ClienteId remetenteId,
						ClienteId destinatarioId,
						ClienteId pagadorFreteId) {

		if (!this.situacao.isDigitado()) {
			throw new ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException();
		}

		this.cotacaoFreteId = cotacaoFreteId;
		this.remetenteId = remetenteId;
		this.destinatarioId = destinatarioId;
		this.pagadorFreteId = pagadorFreteId;

		this.registerEvent(DocumentoTransporteAlteradoEvent.from(this));

	}

	//DATREINOLOG-265
	public void adicionarDocumentoCarga(DocumentoCarga documentoCarga) {

		this.documentosCarga.add(documentoCarga);

		this.registerEvent(DocumentoTransporteDocumentoCargaAdicionadoEvent.from(this, documentoCarga));

	}

	//DATREINOLOG-265
	public void excluirDocumentoCarga(DocumentoCargaId documentoCargaId) {

		this.documentosCarga.stream()
							.filter(documento -> documento.getId().equals(documentoCargaId))
							.findFirst()
							.ifPresent(documentoCarga -> {
								this.documentosCarga.remove(documentoCarga);
								this.registerEvent(DocumentoTransporteDocumentoCargaExcluidoEvent.from(this,
																									   documentoCargaId));
							});

	}

}
