package com.totvs.sl.onboarding.core.documentotransporte.amqp;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd.*;
import com.totvs.sl.onboarding.core.documentotransporte.application.DocumentoTransporteApplicationService;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.documentotransporte.exception.*;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.tjf.core.message.TOTVSMessage;
import com.totvs.tjf.core.validation.ValidatorService;
import lombok.AllArgsConstructor;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeInput.class)
public class DocumentoTransporteSubscriber {

    private final DocumentoTransporteApplicationService service;
    private final ValidatorService validator;

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = CriarDocumentoTransporteCmd.CONDITIONAL_EXPRESSION)
    public void criarDocumentoTransporte(TOTVSMessage<CriarDocumentoTransporteCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBCriarDocumentoTransporteException(violations);
        });

        var command = CriarDocumentoTransporteCommand.of(cmd.getNumero(), DateTimeUtils.getNow(),
                cmd.getSerie(),cmd.getModelo(),cmd.getChaveAcesso(), CotacaoFreteId.from(cmd.getCotacaoFreteId()),ClienteId.from(cmd.getRemetenteId()),
                ClienteId.from(cmd.getDestinatarioId()),ClienteId.from(cmd.getPagadorFreteId()));

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AlterarDocumentoTransporteCmd.CONDITIONAL_EXPRESSION)
    public void alterarDocumentoTransporte(TOTVSMessage<AlterarDocumentoTransporteCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAlterarDocumentoTransporteException(violations);
        });

        var command = AlterarDocumentoTransporteCommand.of(DocumentoTransporteId.from(cmd.getId()), CotacaoFreteId.from(cmd.getId()),
                ClienteId.from(cmd.getRemetenteId()), ClienteId.from(cmd.getDestinatarioId()), ClienteId.from(cmd.getPagadorFreteId()));

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = CancelarDocumentoTransporteCmd.CONDITIONAL_EXPRESSION)
    public void cancelarDocumentoTransporte(TOTVSMessage<CancelarDocumentoTransporteCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAnularDocumentoTransporteException(violations);
        });

        var command = CancelarDocumentoTransporteCommand.of(DocumentoTransporteId.from(cmd.getId()), cmd.getIdCancel());

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AnularDocumentoTransporteCmd.CONDITIONAL_EXPRESSION)
    public void anularDocumentoTransporte(TOTVSMessage<AnularDocumentoTransporteCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAnularDocumentoTransporteException(violations);
        });
        var command = AnularDocumentoTransporteCommand.of(DocumentoTransporteId.from(cmd.getId()), cmd.getIdAnula());

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AutorizarDocumentoTransporteCmd.CONDITIONAL_EXPRESSION)
    public void autorizarDocumentoTransporte(TOTVSMessage<AutorizarDocumentoTransporteCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAutorizarDocumentoTransporteException(violations);
        });

        var command = AutorizarDocumentoTransporteCommand.of(DocumentoTransporteId.from(cmd.getId()), cmd.getIdAutoriza(), cmd.getChaveAcesso());

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AdicionarDocumentoCargaCmd.CONDITIONAL_EXPRESSION)
    public void adicionarDocumentoCarga(TOTVSMessage<AdicionarDocumentoCargaCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAdicionarDocumentoCargaException(violations);
        });

        var command = AdicionarDocumentoCargaCommand.of(DocumentoTransporteId.from(cmd.getId()), cmd.getEmissao(),
                                                                                    cmd.getNumero(), cmd.getSerie(),
                                                                                    cmd.getModelo(), cmd.getChaveAcesso());

        service.handle(command);
    }

    @StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = ExcluirDocumentoCargaCmd.CONDITIONAL_EXPRESSION)
    public void excluirDocumentoCarga(TOTVSMessage<ExcluirDocumentoCargaCmd> message) {

        var cmd = message.getContent();

        validator.validate(cmd).ifPresent(violations -> {
            throw new ONBAExcluirDocumentoCargaException(violations);
        });

        var command = ExcluirDocumentoCargaCommand.of(DocumentoTransporteId.from(cmd.getId()), DocumentoCargaId.from(cmd.getIdCarga()));

        service.handle(command);
    }
}
