package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import java.time.LocalDate;
import java.time.ZonedDateTime;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(access = AccessLevel.PRIVATE)
public final class DocumentoTransporteCriadoEvent implements DomainEvent {

	private final String id;
	private final String numero;
	private final ZonedDateTime emissao;
	private final String serie;
	private final String modelo;
	private final String chaveAcesso;
	private final String situacao;
	private final String cotacaoFreteId;
	private final String remetenteId;
	private final String destinatarioId;
	private final String pagadorFreteId;

	public static DocumentoTransporteCriadoEvent from(final DocumentoTransporte documentoTransporte) {
		return DocumentoTransporteCriadoEvent.builder()
											 .id(documentoTransporte.getId().toString())
											 .numero(documentoTransporte.getNumero())
											 .emissao(documentoTransporte.getEmissao())
											 .serie(documentoTransporte.getSerie())
											 .modelo(documentoTransporte.getModelo())
											 .chaveAcesso(documentoTransporte.getChaveAcesso())
											 .situacao(documentoTransporte.getSituacao().getValor().toString())
											 .cotacaoFreteId(documentoTransporte.getCotacaoFreteId()
																				.map(CotacaoFreteId::toString)
																				.orElse(null))
											 .remetenteId(documentoTransporte.getRemetenteId()
																			 .map(ClienteId::toString)
																			 .orElse(null))
											 .destinatarioId(documentoTransporte.getDestinatarioId()
																				.map(ClienteId::toString)
																				.orElse(null))
											 .pagadorFreteId(documentoTransporte.getPagadorFreteId()
																				.map(ClienteId::toString)
																				.orElse(null))

											 .build();
	}
}
