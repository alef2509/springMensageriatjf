package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(access = AccessLevel.PRIVATE)
public final class DocumentoTransporteAlteradoEvent implements DomainEvent {

	private final String id;
	private final String cotacaoFreteId;
	private final String remetenteId;
	private final String destinatarioId;
	private final String pagadorFreteId;

	public static DocumentoTransporteAlteradoEvent from(final DocumentoTransporte documentoTransporte) {
		return DocumentoTransporteAlteradoEvent.builder()
											   .id(documentoTransporte.getId().toString())
											   .cotacaoFreteId(documentoTransporte.getCotacaoFreteId()
																				  .map(CotacaoFreteId::toString)
																				  .orElse(null))
											   .remetenteId(documentoTransporte.getRemetenteId()
																			   .map(ClienteId::toString)
																			   .orElse(null))
											   .destinatarioId(documentoTransporte.getDestinatarioId()
																				  .map(ClienteId::toString)
																				  .orElse(null))
											   .pagadorFreteId(documentoTransporte.getPagadorFreteId()
																				  .map(ClienteId::toString)
																				  .orElse(null))
											   .build();
	}

}
