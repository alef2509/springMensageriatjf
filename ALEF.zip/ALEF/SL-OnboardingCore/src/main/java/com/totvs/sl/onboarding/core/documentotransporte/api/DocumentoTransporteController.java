package com.totvs.sl.onboarding.core.documentotransporte.api;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.api.dto.*;
import com.totvs.sl.onboarding.core.documentotransporte.application.DocumentoTransporteApplicationService;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBCriarDocumentoTransporteException;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.core.validation.ValidatorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
@RequestMapping(path = DocumentoTransporteController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuideline.ApiGuidelineVersion.V2)
@AllArgsConstructor
public class DocumentoTransporteController {

    public static final String PATH = "/api/v1/documentosTransporte";

    private final DocumentoTransporteApplicationService service;
    private final ValidatorService validator;

    @PostMapping
    @Operation(description = "Cadastrar um novo Documento de Transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Documento de Transporte cadastrado com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação para cadastramento de Documento de Transporte inválida") })
    public ResponseEntity<Void> criar(@RequestBody CriarDocumentoTransporteDTO dto) {

        validator.validate(dto).ifPresent(violations -> {
            throw new ONBCriarDocumentoTransporteException(violations);
        });

        var cmd = CriarDocumentoTransporteCommand.of(dto.getNumero(), DateTimeUtils.getNow(),
                dto.getSerie(),dto.getModelo(),dto.getChaveAcesso(), CotacaoFreteId.from(dto.getCotacaoFreteId()),ClienteId.from(dto.getRemetenteId()),
                ClienteId.from(dto.getDestinatarioId()),ClienteId.from(dto.getPagadorFreteId()));

        var id = service.handle(cmd);

        var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(id.toString()).build().toUri();
        return ResponseEntity.created(uri).build();
    }


    @Operation(description = "Alterar um documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de transporte alterado com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de alteração inválida e alteração não realizada."),
            @ApiResponse(responseCode = "404", description = "O Documento de transporte não foi encontrado.") })
    @PostMapping(path = "/{id}/alterar")
    public ResponseEntity<Void> alterar(@PathVariable String id, @RequestBody AlterarDocumentoTransporteDTO dto) {

        validator.validate(dto).ifPresent(violations -> {
            throw new ONBCriarDocumentoTransporteException(violations);
        });

        var cmd = AlterarDocumentoTransporteCommand.of( DocumentoTransporteId.from(id),CotacaoFreteId.from(dto.getCotacaoFreteId()),ClienteId.from(dto.getRemetenteId()),
                ClienteId.from(dto.getDestinatarioId()),ClienteId.from(dto.getPagadorFreteId()));

        service.handle(cmd);

        return ResponseEntity.noContent().build();
    }


    @Operation(description = "Cancelar um documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de transporte cancelado com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de cancelamento inválida e cancelamento não realizado."),
            @ApiResponse(responseCode = "404", description = "O Documento de transporte não foi encontrado.") })
    @PostMapping(path = "/{id}/cancelar")
    public ResponseEntity<Void> cancelar(@PathVariable String id, @RequestBody CancelarDocumentoTransporteDTO dto) {

        var cmd = CancelarDocumentoTransporteCommand.of( DocumentoTransporteId.from(id),dto.getUsuarioId());
        this.service.handle(cmd);

        return ResponseEntity.noContent().build();
    }

    @Operation(description = "Anular um documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de transporte anulado com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de anulação inválida e anulação não realizada."),
            @ApiResponse(responseCode = "404", description = "O Documento de transporte não foi encontrado.") })
    @PostMapping(path = "/{id}/anular")
    public ResponseEntity<Void> anular(@PathVariable String id, @RequestBody AnularDocumentoTransporteDTO dto) {

        var cmd = AnularDocumentoTransporteCommand.of( DocumentoTransporteId.from(id),dto.getUsuarioId());
        this.service.handle(cmd);

        return ResponseEntity.noContent().build();
    }


    @Operation(description = "Autorizar um documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de transporte autorizado com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de autorização inválida e autorização não realizado."),
            @ApiResponse(responseCode = "404", description = "O Documento de transporte não foi encontrado.") })
    @PostMapping(path = "/{id}/autorizar")
    public ResponseEntity<Void> autorizar(@PathVariable String id, @RequestBody AutorizarDocumentoTransporteDTO dto) {
        var cmd = AutorizarDocumentoTransporteCommand.of( DocumentoTransporteId.from(id),dto.getUsuarioId(), dto.getChaveAcesso());
        this.service.handle(cmd);

        return ResponseEntity.noContent().build();
    }

    @Operation(description = "Incluir um documento de carga no documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de carga incluido no documento de transporte com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de inclusão inválida e inclusão  não realizado."),
            @ApiResponse(responseCode = "404", description = "O Documento de carga não pode ser incluido.") })
    @PostMapping(path = "/{id}/adicionarDocumentoCarga")
    public ResponseEntity<Void> adicionarDocumentoCarga(@PathVariable String id, @RequestBody AdicionarDocumentoCargaDTO dto) {
        var cmd = AdicionarDocumentoCargaCommand.of( DocumentoTransporteId.from(id),
                                                                              dto.getEmissao(), dto.getNumero(),
                                                                              dto.getSerie(), dto.getModelo(),
                                                                              dto.getChaveAcesso());
        this.service.handle(cmd);

        return ResponseEntity.noContent().build();
    }

    @Operation(description = "Excluir um documento de carga no documento de transporte.", method = "POST")
    @ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Documento de carga excluido no documento de transporte com sucesso."),
            @ApiResponse(responseCode = "400", description = "Solicitação de exclusão inválida e exclusão  não realizado."),
            @ApiResponse(responseCode = "404", description = "O Documento de carga não pode ser excluido.") })
    @PostMapping(path = "/{id}/documentoCarga/{documentoCargaId}/excluir", consumes = MediaType.ALL_VALUE)
    public ResponseEntity<Void> excluirDocumentoCarga(@PathVariable String id,@PathVariable String documentoCargaId ) {
        var cmd = ExcluirDocumentoCargaCommand.of( DocumentoTransporteId.from(id), DocumentoCargaId.from(documentoCargaId));
        this.service.handle(cmd);

        return ResponseEntity.noContent().build();
    }

}
