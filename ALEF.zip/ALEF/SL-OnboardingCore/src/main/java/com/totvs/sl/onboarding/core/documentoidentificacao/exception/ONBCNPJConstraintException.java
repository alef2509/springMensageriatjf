package com.totvs.sl.onboarding.core.documentoidentificacao.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("ONBConstraintException")
public class ONBCNPJConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -1520477342271706659L;

	public ONBCNPJConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
