package com.totvs.sl.onboarding.core.cliente.repository;

import java.sql.Types;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteDomainRepository;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteNaoEncontradoException;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;

@Repository
public class ClienteRepository extends CrudAggregateRepository<Cliente, ClienteId>
		implements ClienteDomainRepository {
	private static final String CONDICAO_ID = "id = ?";

	public ClienteRepository(EntityManager em, ObjectMapper mapper) {
		super(em, mapper.copy());
	}

	@Override
	public Optional<Cliente> findById(ClienteId id) {
		return this.findOne(CONDICAO_ID, new SqlParameterValue(Types.VARCHAR, id));
	}

	@Override
	public Cliente findByIdOrThrowNotFound(ClienteId id) {
		return findById(id).orElseThrow(ONBClienteNaoEncontradoException::new);
	}

}