package com.totvs.sl.onboarding.core.config.swagger;

import org.springdoc.core.GroupedOpenApi;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.OAuthFlow;
import io.swagger.v3.oas.models.security.OAuthFlows;
import io.swagger.v3.oas.models.security.Scopes;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.security.SecurityScheme.Type;

@Configuration
@EnableConfigurationProperties(SwaggerProperties.class)
public class SwaggerConfiguration {

	private final SwaggerProperties properties;

	public static final String SWAGGER_DESCRIPTION = "Interface de apresentação das API REST disponíveis para o Serviço Onboarding Core";
	public static final String SWAGGER_OAUTH_NAME = "spring_oauth";
	public static final String SWAGGER_TITLE = "Serviço Onboarding Core: API REST";
	public static final String SWAGGER_VERSION = "1.0.0";

	public SwaggerConfiguration(SwaggerProperties properties) {
		this.properties = properties;
	}

	@Bean
	public OpenAPI openApi() {
		return new OpenAPI().info(new Info().title(SWAGGER_TITLE)
											.description(SWAGGER_DESCRIPTION)
											.version(SWAGGER_VERSION))
							.addSecurityItem(new SecurityRequirement().addList(SWAGGER_OAUTH_NAME))
							.components(new Components().addSecuritySchemes(SWAGGER_OAUTH_NAME,
																			new SecurityScheme().type(Type.OAUTH2)
																								.flows(new OAuthFlows().implicit(new OAuthFlow().authorizationUrl(properties.getOauth2()
																																											.getAuthServer()
																										+ "/connect/authorize")
																																				.scopes(new Scopes().addString("authorization_api",
																																											   "Authorization API"))))));
	}

	@Bean
	public GroupedOpenApi hideApis() {
		return GroupedOpenApi.builder().group("default").pathsToMatch("/**").build();
	}

}
