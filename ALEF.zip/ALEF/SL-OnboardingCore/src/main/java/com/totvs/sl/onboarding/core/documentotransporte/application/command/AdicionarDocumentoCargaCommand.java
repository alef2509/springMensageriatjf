package com.totvs.sl.onboarding.core.documentotransporte.application.command;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.time.LocalDate;

@Data(staticConstructor = "of")
public final class AdicionarDocumentoCargaCommand {
    private final DocumentoTransporteId id;
    private final LocalDate emissao;
    private final String numero;
    private final String serie;
    private final String modelo;
    private final String chaveAcesso;
}
