package com.totvs.sl.onboarding.core.cliente.domain.model;

import java.util.Optional;

import com.totvs.tjf.repository.aggregate.AggregateRepository;

public interface ClienteDomainRepository extends AggregateRepository<Cliente, ClienteId> {

	public Optional<Cliente> findById(final ClienteId id);

	public Cliente findByIdOrThrowNotFound(final ClienteId id);

	public Cliente insert(final Cliente cliente);

	public Cliente update(final Cliente cliente);

}
