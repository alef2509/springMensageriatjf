package com.totvs.sl.onboarding.core.documentotransporte.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para cadastro de um novo documento de transporte.")

public final class CriarDocumentoTransporteDTO {

    @Schema(description = "Numero do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.numero.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.numero.Size}")
    private  final String numero;

    @Schema(description = "serie do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.serie.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.serie.Size}")
    private  final String serie;

    @Schema(description = "modelo do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.modelo.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.modelo.Size}")
    private  final String modelo;

    @Schema(description = "chave de acesso do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.chaveAcesso.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.chaveAcesso.Size}")
    private  final String chaveAcesso;

    @Schema(description = "cotacao do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.cotacaoFreteId.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.cotacaoFreteId.Size}")
    private  final String cotacaoFreteId;

    @Schema(description = "remetente do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.remetenteId.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.remetenteId.Size}")
    private  final String remetenteId;

    @Schema(description = "destinatario do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.destinatarioId.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.destinatarioId.Size}")
    private  final String destinatarioId;

    @Schema(description = "pagador do frete do documento de transporte.", required = true)
    @NotBlank(message = "{CriarDocumentoTransporteDTO.pagadorFreteId.NotBlank}")
    @Size(max = 60, message = "{CriarDocumentoTransporteDTO.pagadorFreteId.Size}")
    private  final String pagadorFreteId;
}
