package com.totvs.sl.onboarding.core.cliente.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class ClienteId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1L;

	protected ClienteId(UUID id) {
		super(id);
	}

	public static ClienteId generate() {
		return new ClienteId(UUID.randomUUID());
	}

	@JsonCreator
	public static ClienteId from(String id) {
		return id != null ? new ClienteId(UUID.fromString(id)) : null;
	}
}
