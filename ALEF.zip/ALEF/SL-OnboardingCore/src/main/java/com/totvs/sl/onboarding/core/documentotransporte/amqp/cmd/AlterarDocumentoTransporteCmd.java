package com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(staticName = "of")
public final class AlterarDocumentoTransporteCmd {

    public static final String NAME = "AlterarDocumentoTransporteCmd";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

    private final String id;
    private  final String cotacaoFreteId;
    private  final String remetenteId;
    private  final String destinatarioId;
    private  final String pagadorFreteId;
}
