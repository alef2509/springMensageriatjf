package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.tjf.core.common.domain.ValueObject;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class RegistroSituacao implements ValueObject {

	private final SituacaoDocumento valor;
	private final ZonedDateTime quando;
	private final String usuarioId;

	public static RegistroSituacao ofDigitado() {
		return new RegistroSituacao(SituacaoDocumento.DIGITADO, DateTimeUtils.getNow(), null);
	}

	public static RegistroSituacao ofAutorizado(String usuarioId) {
		return new RegistroSituacao(SituacaoDocumento.AUTORIZADO, DateTimeUtils.getNow(), usuarioId);
	}

	public static RegistroSituacao ofCancelado(String usuarioId) {
		return new RegistroSituacao(SituacaoDocumento.CANCELADO, DateTimeUtils.getNow(), usuarioId);
	}

	public static RegistroSituacao ofAnulado(String usuarioId) {
		return new RegistroSituacao(SituacaoDocumento.ANULADO, DateTimeUtils.getNow(), usuarioId);
	}

	public boolean isDigitado() {
		return this.valor.equals(SituacaoDocumento.DIGITADO);
	}

	public boolean isAnulado() {
		return this.valor.equals(SituacaoDocumento.ANULADO);
	}

	public boolean isAutorizado() {
		return this.valor.equals(SituacaoDocumento.AUTORIZADO);
	}

	public boolean isCancelado() {
		return this.valor.equals(SituacaoDocumento.CANCELADO);
	}

}
