package com.totvs.sl.onboarding.core.documentocarga.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class DocumentoCargaId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1L;

	protected DocumentoCargaId(UUID id) {
		super(id);
	}

	public static DocumentoCargaId generate() {
		return new DocumentoCargaId(UUID.randomUUID());
	}

	@JsonCreator
	public static DocumentoCargaId from(String id) {
		return id != null ? new DocumentoCargaId(UUID.fromString(id)) : null;
	}

}
