package com.totvs.sl.onboarding.core.documentotransporte.application.command;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.Data;

@Data(staticConstructor = "of")
public final class AlterarDocumentoTransporteCommand {
    private final DocumentoTransporteId id;
    private  final CotacaoFreteId cotacaoFreteId;
    private  final ClienteId remetenteId;
    private  final ClienteId destinatarioId;
    private  final ClienteId pagadorFreteId;
}
