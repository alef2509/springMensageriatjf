package com.totvs.sl.onboarding.core.documentocarga.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.totvs.sl.onboarding.core.documentocarga.exception.ONBDocumentoCargaConstraintException;
import com.totvs.tjf.core.common.domain.ValueObject;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DocumentoCarga implements ValueObject {

	@NotNull(message = "DocumentoCarga.id.NotNull")
	private final DocumentoCargaId id;

	@NotNull(message = "DocumentoCarga.emissao.NotNull")
	private final LocalDate emissao;

	@NotBlank(message = "DocumentoCarga.numero.NotBlank")
	@Size(min = 1, max = 9, message = "DocumentoCarga.numero.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoCarga.numero.Pattern")
	private final String numero;

	@NotBlank(message = "DocumentoCarga.serie.NotBlank")
	@Size(min = 1, max = 3, message = "DocumentoCarga.serie.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoCarga.serie.Pattern")
	private final String serie;

	@NotBlank(message = "DocumentoCarga.modelo.NotBlank")
	@Size(min = 1, max = 2, message = "DocumentoCarga.modelo.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoCarga.modelo.Pattern")
	private final String modelo;

	@Size(min = 44, max = 44, message = "DocumentoCarga.chaveAcesso.Size")
	@Pattern(regexp = "[0-9]+", message = "DocumentoCarga.chaveAcesso.Pattern")
	private final String chaveAcesso;

	@Builder
	public DocumentoCarga(DocumentoCargaId id,
						  LocalDate emissao,
						  String numero,
						  String serie,
						  String modelo,
						  String chaveAcesso) {
		this.id = id;
		this.emissao = emissao;
		this.numero = numero;
		this.serie = serie;
		this.modelo = modelo;
		this.chaveAcesso = chaveAcesso;

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBDocumentoCargaConstraintException(violations);
		});
	}

}
