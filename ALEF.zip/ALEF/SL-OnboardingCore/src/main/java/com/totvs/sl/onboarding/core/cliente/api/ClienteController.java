package com.totvs.sl.onboarding.core.cliente.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.totvs.sl.onboarding.core.cliente.api.dto.AlterarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.api.dto.CriarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.application.ClienteApplicationService;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBAlterarClienteException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBCriarClienteException;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.core.validation.ValidatorService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.AllArgsConstructor;

@RestController
@RequestMapping(path = ClienteController.PATH, produces = APPLICATION_JSON_VALUE, consumes = APPLICATION_JSON_VALUE)
@ApiGuideline(ApiGuidelineVersion.V2)
@AllArgsConstructor
public class ClienteController {

	public static final String PATH = "/api/v1/clientes";

	private final ClienteApplicationService service;
	private final ValidatorService validator;

	@PostMapping
	@Operation(description = "Cadastrar um novo cliente.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "201", description = "Cliente cadastrado com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação para cadastramento do cliente inválida e cliente não cadastrado.") })
	public ResponseEntity<Void> criar(@RequestBody CriarClienteDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new ONBCriarClienteException(violations);
		});

		var cmd = CriarClienteCommand.of(dto.getNome(), DocumentoIdentificacao.from(dto.getDocumento()));

		var id = service.handle(cmd);

		var uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/").path(id.toString()).build().toUri();

		return ResponseEntity.created(uri).build();
	}

	@Operation(description = "Alterar um cliente.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Cliente alterado com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de alteração inválida e alteração não realizada."),
			@ApiResponse(responseCode = "404", description = "O cliente não foi encontrado.") })
	@PostMapping(path = "/{id}/alterar")
	public ResponseEntity<Void> alterar(@PathVariable String id, @RequestBody AlterarClienteDTO dto) {

		validator.validate(dto).ifPresent(violations -> {
			throw new ONBAlterarClienteException(violations);
		});

		var cmd = AlterarClienteCommand.of(ClienteId.from(id), dto.getNome());

		service.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@PostMapping(path = "/{id}/inativar", consumes = MediaType.ALL_VALUE)
	@Operation(description = "Inativar o cadastro de um cliente.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Cliente inativado com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de inativação inválida e inativação não realizada."),
			@ApiResponse(responseCode = "404", description = "O cliente não foi encontrado.") })
	public ResponseEntity<Void> inativar(@PathVariable String id) {

		var cmd = InativarClienteCommand.of(ClienteId.from(id));

		this.service.handle(cmd);

		return ResponseEntity.noContent().build();
	}

	@PostMapping(path = "/{id}/ativar", consumes = MediaType.ALL_VALUE)
	@Operation(description = "Ativar o cadastro de um cliente.", method = "POST")
	@ApiResponses(value = { @ApiResponse(responseCode = "204", description = "Cliente ativado com sucesso."),
			@ApiResponse(responseCode = "400", description = "Solicitação de ativação inválida e ativação não realizada."),
			@ApiResponse(responseCode = "404", description = "O cliente não foi encontrado.") })
	public ResponseEntity<Void> ativar(@PathVariable String id) {

		var cmd = AtivarClienteCommand.of(ClienteId.from(id));

		this.service.handle(cmd);

		return ResponseEntity.noContent().build();
	}
}