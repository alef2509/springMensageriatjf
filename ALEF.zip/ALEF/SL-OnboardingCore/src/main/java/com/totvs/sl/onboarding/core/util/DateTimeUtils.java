package com.totvs.sl.onboarding.core.util;

import java.time.ZoneId;
import java.time.ZonedDateTime;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DateTimeUtils {

	public static ZonedDateTime getNow() {
		return ZonedDateTime.now(ZoneId.of("UTC"));
	}
}
