package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoTransporteSituacaoNaoPermiteAnulacaoException extends RuntimeException {

	private static final long serialVersionUID = 7037622495438928482L;

}
