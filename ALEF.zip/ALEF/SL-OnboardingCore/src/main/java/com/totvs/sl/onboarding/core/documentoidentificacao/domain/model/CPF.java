package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import javax.validation.constraints.NotBlank;

import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCPFConstraintException;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public final class CPF implements DocumentoIdentificacao {

	@NotBlank(message = "{CPF.numero.NotBlank}")
	@br.com.caelum.stella.bean.validation.CPF(message = "{CPF.numero.CPF}")
	private final String numero;

	private CPF(String numero) {
		this.numero = numero;

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBCPFConstraintException(violations);
		});
	}

	public static CPF from(String numero) {
		return new CPF(numero);
	}

	@Override
	public TipoDocumentoIdentificacao getTipo() {
		return TipoDocumentoIdentificacao.CPF;
	}

	@Override
	public String getNumero() {
		return this.numero;
	}

	@Override
	public boolean isPessoaFisica() {
		return true;
	}

}
