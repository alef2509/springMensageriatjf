package com.totvs.sl.onboarding.core.documentoidentificacao.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoIdentificacaoInvalidoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	@ApiErrorParameter
	private final String numeroDocumento;

	public ONBDocumentoIdentificacaoInvalidoException(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

}