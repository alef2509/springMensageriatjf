package com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDate;

@Data
@AllArgsConstructor(staticName = "of")
public final class AdicionarDocumentoCargaCmd {
    public static final String NAME = "AdicionarDocumentoCargaCmd";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

    private final String id;
    private final LocalDate emissao;
    private final String numero;
    private final String serie;
    private final String modelo;
    private final String chaveAcesso;
}
