package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException extends RuntimeException {

	private static final long serialVersionUID = -1342414966374727136L;

}
