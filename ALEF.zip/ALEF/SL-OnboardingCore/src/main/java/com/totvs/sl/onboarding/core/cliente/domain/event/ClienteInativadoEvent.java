package com.totvs.sl.onboarding.core.cliente.domain.event;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class ClienteInativadoEvent implements DomainEvent {

	private final String id;
	private final String situacao;

	public static ClienteInativadoEvent from(final Cliente cliente) {
		return new ClienteInativadoEvent(cliente.getId().toString(), cliente.getSituacao().getValor().toString());
	}

}
