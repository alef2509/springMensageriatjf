package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class ONBDocumentoTransporteNaoEncontradoException extends RuntimeException {

    private static final long serialVersionUID = 9209612811427879572L;
}
