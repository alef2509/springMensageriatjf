package com.totvs.sl.onboarding.core.cliente.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteConstraintException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteSituacaoNaoPermiteAtivacaoException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteSituacaoNaoPermiteInativacaoException;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.tjf.core.stereotype.Aggregate;
import com.totvs.tjf.repository.aggregate.metadata.AggregateDomainMetadataInfo;

import lombok.AccessLevel;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@ToString
@Aggregate
@Table(name = "cliente")
@EqualsAndHashCode(onlyExplicitlyIncluded = true, callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public class Cliente extends AggregateDomainMetadataInfo<ClienteId> {

	@Getter
	@NotBlank(message = "Cliente.nome.NotBlank")
	private String nome;

	@Getter
	@NotNull(message = "Cliente.documento.NotNull")
	private DocumentoIdentificacao documento;

	@Getter(value = AccessLevel.PROTECTED)
	private List<SituacaoCliente> historicoSituacoes = new ArrayList<>();

	@Builder
	private Cliente(final ClienteId id, final DocumentoIdentificacao documento, final String nome) {

		super(id);
		this.documento = documento;
		this.nome = nome;
		this.historicoSituacoes.add(SituacaoCliente.ofAtivo());

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBClienteConstraintException(violations);
		});

		this.registerEvent(ClienteCriadoEvent.from(this));

	}

	public void alterar(final String nome) {

		this.nome = nome;

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBClienteConstraintException(violations);
		});

		this.registerEvent(ClienteAlteradoEvent.from(this));

	}

	public void ativar() {

		if (this.getSituacao().isAtivo())
			return;

		if (!this.getSituacao().isInativo())
			throw new ONBClienteSituacaoNaoPermiteAtivacaoException();

		this.historicoSituacoes.add(SituacaoCliente.ofAtivo());

		this.registerEvent(ClienteAtivadoEvent.from(this));

	}

	public void inativar() {

		if (this.getSituacao().isInativo())
			return;

		if (!this.getSituacao().isAtivo())
			throw new ONBClienteSituacaoNaoPermiteInativacaoException();

		this.historicoSituacoes.add(SituacaoCliente.ofInativo());

		this.registerEvent(ClienteInativadoEvent.from(this));

	}

	public SituacaoCliente getSituacao() {
		return this.historicoSituacoes.get(this.historicoSituacoes.size() - 1);
	}

}
