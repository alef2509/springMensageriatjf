package com.totvs.sl.onboarding.core.cliente.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBClienteSituacaoNaoPermiteInativacaoException extends RuntimeException {

	private static final long serialVersionUID = -7390253792804171276L;

}
