package com.totvs.sl.onboarding.core.config.swagger;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties(prefix = "swagger", ignoreUnknownFields = true, ignoreInvalidFields = true)
public class SwaggerProperties {

	private Oauth2Properties oauth2;

	@Data
	static class Oauth2Properties {

		private String authServer;
	}
}
