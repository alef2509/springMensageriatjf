package com.totvs.sl.onboarding.core.documentotransporte.repository;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteDomainRepository;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.tjf.core.aggregate.repository.AggregateCollectionResult;
import com.totvs.tjf.repository.aggregate.CrudAggregateRepository;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.SqlParameterValue;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.sql.Types;
import java.util.Optional;

@Repository
public class DocumentoTransporteRepository
        extends CrudAggregateRepository<DocumentoTransporte, DocumentoTransporteId>
        implements DocumentoTransporteDomainRepository {

    private static final String CONDICAO_ID = "id = ?";

    public DocumentoTransporteRepository(EntityManager em, ObjectMapper mapper) {
        super(em, mapper.copy());
    }

    @Override
    public Optional<DocumentoTransporte> findById(DocumentoTransporteId id) {

        return this.findOne(CONDICAO_ID, new SqlParameterValue(Types.VARCHAR, id));
    }



    @Override
    public DocumentoTransporte findByIdOrThrowNotFound(DocumentoTransporteId id) {
        return findById(id).orElseThrow(ONBDocumentoTransporteNaoEncontradoException::new);
    }

    @Override
    public AggregateCollectionResult<DocumentoTransporte> findAll(Pageable pageable, String clause, String orderby, SqlParameterValue... arguments) {
        return super.findAll(pageable, clause, orderby, arguments);
    }
}
