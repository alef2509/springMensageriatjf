package com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(staticName = "of")
public final class AnularDocumentoTransporteCmd {

    public static final String NAME = "AnularDocumentoTransporteCmd";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

    private final String id;
    private final String idAnula;
}
