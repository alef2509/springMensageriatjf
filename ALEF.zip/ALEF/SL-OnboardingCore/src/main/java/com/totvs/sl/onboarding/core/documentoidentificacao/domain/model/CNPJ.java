package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

import static com.totvs.tjf.autoconfigure.ValidationUtils.validateIntegrity;

import javax.validation.constraints.NotBlank;

import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCNPJConstraintException;
import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCNPJSomenteZerosException;

import lombok.AccessLevel;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(access = AccessLevel.PROTECTED, force = true)
public final class CNPJ implements DocumentoIdentificacao {

	@NotBlank(message = "{CNPJ.numero.NotBlank}")
	@br.com.caelum.stella.bean.validation.CNPJ(message = "{CNPJ.numero.CNPJ}")
	private String numero;

	private CNPJ(String numero) {
		this.numero = numero;

		validateIntegrity(this).ifPresent(violations -> {
			throw new ONBCNPJConstraintException(violations);
		});

		if (cnpjSomenteComZeros(numero))
			throw new ONBCNPJSomenteZerosException(numero);
	}

	public static CNPJ from(String numero) {
		return new CNPJ(numero);
	}

	@Override
	public TipoDocumentoIdentificacao getTipo() {
		return TipoDocumentoIdentificacao.CNPJ;
	}

	@Override
	public String getNumero() {
		return this.numero;
	}

	@Override
	public boolean isPessoaJuridica() {
		return true;
	}

	private boolean cnpjSomenteComZeros(String cnpj) {
		return cnpj.chars().allMatch(c -> c == (char) 48);
	}
}