package com.totvs.sl.onboarding.core.cliente.domain.event;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class ClienteAtivadoEvent implements DomainEvent {

	private final String id;
	private final String situacao;

	public static ClienteAtivadoEvent from(final Cliente cliente) {
		return new ClienteAtivadoEvent(cliente.getId().toString(), cliente.getSituacao().getValor().toString());
	}

}
