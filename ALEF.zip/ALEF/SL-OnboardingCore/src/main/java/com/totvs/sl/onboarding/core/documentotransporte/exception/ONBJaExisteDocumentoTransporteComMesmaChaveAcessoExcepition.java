package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.ApiErrorParameter;

public class ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition extends RuntimeException {

    private static final long serialVersionUID = 1L;

    @ApiErrorParameter
    private final String chaveAcesso;

    public ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition(String chaveAcesso) {
        this.chaveAcesso = chaveAcesso;
    }

}
