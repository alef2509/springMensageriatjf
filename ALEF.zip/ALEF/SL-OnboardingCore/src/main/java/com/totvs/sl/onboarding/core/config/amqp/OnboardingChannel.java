package com.totvs.sl.onboarding.core.config.amqp;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class OnboardingChannel {

	public static final String ONBOARDING_INPUT = "onboarding-input-events";
	public static final String ONBOARDING_OUTPUT = "onboarding-output-events";

	public interface OnboardingExchangeInput {
		@Input(OnboardingChannel.ONBOARDING_INPUT)
		SubscribableChannel input();
	}

	public interface OnboardingExchangeOutput {
		@Output(OnboardingChannel.ONBOARDING_OUTPUT)
		MessageChannel output();
	}

}
