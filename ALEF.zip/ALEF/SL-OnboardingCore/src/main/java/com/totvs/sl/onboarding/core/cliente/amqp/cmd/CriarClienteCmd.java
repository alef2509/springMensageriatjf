package com.totvs.sl.onboarding.core.cliente.amqp.cmd;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(staticName = "of")
public final class CriarClienteCmd {

	public static final String NAME = "CriarClienteCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String nome;
	private final String documento;
}
