package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import java.time.LocalDate;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(access = AccessLevel.PRIVATE)
public final class DocumentoTransporteDocumentoCargaAdicionadoEvent implements DomainEvent {


	private final String documentoTransporteId;
	private final String id;
	private final String numero;
	private final LocalDate emissao;
	private final String serie;
	private final String modelo;
	private final String chaveAcesso;

	public static DocumentoTransporteDocumentoCargaAdicionadoEvent from(final DocumentoTransporte documentoTransporte,
																		final DocumentoCarga documentoCarga) {

		return DocumentoTransporteDocumentoCargaAdicionadoEvent.builder()
															   .documentoTransporteId(documentoTransporte.getId().toString())
															   .id(documentoCarga.getId().toString())
															   .numero(documentoCarga.getNumero())
															   .emissao(documentoCarga.getEmissao())
															   .serie(documentoCarga.getSerie())
															   .modelo(documentoCarga.getModelo())
															   .chaveAcesso(documentoCarga.getChaveAcesso())
															   .build();
	}

}
