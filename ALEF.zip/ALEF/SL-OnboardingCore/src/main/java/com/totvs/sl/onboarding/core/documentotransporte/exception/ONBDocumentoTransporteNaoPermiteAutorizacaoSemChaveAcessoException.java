package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoTransporteNaoPermiteAutorizacaoSemChaveAcessoException extends RuntimeException {

	private static final long serialVersionUID = -5370884910611595450L;

}
