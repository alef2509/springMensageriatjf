package com.totvs.sl.onboarding.core.cotacaofrete.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class CotacaoFreteId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1L;

	protected CotacaoFreteId(UUID id) {
		super(id);
	}

	public static CotacaoFreteId generate() {
		return new CotacaoFreteId(UUID.randomUUID());
	}

	@JsonCreator
	public static CotacaoFreteId from(String id) {
		return id != null ? new CotacaoFreteId(UUID.fromString(id)) : null;
	}

}