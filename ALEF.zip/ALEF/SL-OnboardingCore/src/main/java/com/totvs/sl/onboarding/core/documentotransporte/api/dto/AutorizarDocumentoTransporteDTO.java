package com.totvs.sl.onboarding.core.documentotransporte.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para autorizar um documento de transporte.")

public final class AutorizarDocumentoTransporteDTO {
    @Schema(description = "cliente que autorizou o documento de transporte.", required = true)
    @NotBlank(message = "{AutorizarDocumentoTransporteDTO.usuarioId.NotBlank}")
    @Size(max = 60, message = "{AutorizarDocumentoTransporteDTO.usuarioId.Size}")
    private  final String usuarioId;

    @Schema(description = "chave de acesso do documento de transporte.", required = true)
    @NotBlank(message = "{AutorizarDocumentoTransporteDTO.chaveAcesso.NotBlank}")
    @Size(max = 60, message = "{AutorizarDocumentoTransporteDTO.chaveAcesso.Size}")
    private  final String chaveAcesso;
}
