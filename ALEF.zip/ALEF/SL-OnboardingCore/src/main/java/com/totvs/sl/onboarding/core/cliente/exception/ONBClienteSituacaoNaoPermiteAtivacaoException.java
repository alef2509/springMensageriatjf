package com.totvs.sl.onboarding.core.cliente.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBClienteSituacaoNaoPermiteAtivacaoException extends RuntimeException {

	private static final long serialVersionUID = 7221367770515606035L;

}
