package com.totvs.sl.onboarding.core.cliente.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class ONBClienteNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = 9209612811427879572L;

}
