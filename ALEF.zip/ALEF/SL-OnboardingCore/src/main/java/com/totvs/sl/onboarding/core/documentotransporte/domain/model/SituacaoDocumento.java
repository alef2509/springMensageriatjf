package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

public enum SituacaoDocumento {
	DIGITADO, AUTORIZADO, CANCELADO, ANULADO
}
