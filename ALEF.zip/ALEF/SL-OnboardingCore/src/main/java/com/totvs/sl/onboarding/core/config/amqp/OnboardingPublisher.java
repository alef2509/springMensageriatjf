package com.totvs.sl.onboarding.core.config.amqp;

import java.util.Collection;

import org.springframework.cloud.stream.annotation.EnableBinding;

import com.totvs.sl.onboarding.core.config.amqp.OnboardingChannel.OnboardingExchangeOutput;
import com.totvs.tjf.core.common.domain.DomainEvent;
import com.totvs.tjf.core.message.TOTVSMessage;
import com.totvs.tjf.core.message.TransactionInfo;
import com.totvs.tjf.messaging.TransactionContext;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeOutput.class)
public class OnboardingPublisher {

	private OnboardingExchangeOutput onboardingExchangeOutput;
	private final TransactionContext transactionContext;

	public void dispatch(Collection<? extends DomainEvent> events) {
		events.forEach(this::dispatch);
	}

	public void dispatch(final DomainEvent event) {
		this.dispatch(event, transactionContext.getTransactionInfo());

	}

	private <T> void dispatch(T contentToBeDispatched, TransactionInfo transactionInfo) {

		var contentToBeDispatchedType = contentToBeDispatched.getClass().getSimpleName();

		var message = new TOTVSMessage<T>(contentToBeDispatchedType, transactionInfo);
		message.setContent(contentToBeDispatched);
		message.sendTo(onboardingExchangeOutput.output());
	}
}
