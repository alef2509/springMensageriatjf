package com.totvs.sl.onboarding.core.cliente.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.onboarding.core.cliente.amqp.cmd.AlterarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.AtivarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.CriarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.InativarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.application.ClienteApplicationService;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBAlterarClienteException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBCriarClienteException;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.tjf.core.message.TOTVSMessage;
import com.totvs.tjf.core.validation.ValidatorService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeInput.class)
public class ClienteSubscriber {

	private final ClienteApplicationService service;
	private final ValidatorService validator;

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = CriarClienteCmd.CONDITIONAL_EXPRESSION)
	public void criarlLiente(TOTVSMessage<CriarClienteCmd> message) {

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new ONBCriarClienteException(violations);
		});

		var command = CriarClienteCommand.of(cmd.getNome(), DocumentoIdentificacao.from(cmd.getDocumento()));

		service.handle(command);
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AlterarClienteCmd.CONDITIONAL_EXPRESSION)
	public void alterarCliente(TOTVSMessage<AlterarClienteCmd> message) {

		var cmd = message.getContent();

		validator.validate(cmd).ifPresent(violations -> {
			throw new ONBAlterarClienteException(violations);
		});

		var command = AlterarClienteCommand.of(ClienteId.from(cmd.getId()), cmd.getNome());

		service.handle(command);
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = InativarClienteCmd.CONDITIONAL_EXPRESSION)
	public void inativarCliente(TOTVSMessage<InativarClienteCmd> message) {

		var cmd = message.getContent();

		var command = InativarClienteCommand.of(ClienteId.from(cmd.getId()));

		service.handle(command);
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = AtivarClienteCmd.CONDITIONAL_EXPRESSION)
	public void ativarCliente(TOTVSMessage<AtivarClienteCmd> message) {

		var cmd = message.getContent();

		var command = AtivarClienteCommand.of(ClienteId.from(cmd.getId()));

		service.handle(command);
	}

}
