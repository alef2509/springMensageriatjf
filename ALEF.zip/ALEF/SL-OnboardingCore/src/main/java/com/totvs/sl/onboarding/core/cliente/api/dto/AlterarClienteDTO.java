package com.totvs.sl.onboarding.core.cliente.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(force = true)
@Schema(description = "Alterar informações de um depositante")
public final class AlterarClienteDTO {

	@Schema(description = "Nome ou razão social do depositante.", required = true)
	@NotBlank(message = "{AlterarClienteDTO.nome.NotBlank}")
	@Size(max = 60, message = "AlterarClienteDTO.nome.Size")
	private final String nome;

}