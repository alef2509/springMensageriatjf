package com.totvs.sl.onboarding.core.cliente.amqp.cmd;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(staticName = "of")
public final class AlterarClienteCmd {

	public static final String NAME = "AlterarClienteCmd";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String id;
	private final String nome;

}