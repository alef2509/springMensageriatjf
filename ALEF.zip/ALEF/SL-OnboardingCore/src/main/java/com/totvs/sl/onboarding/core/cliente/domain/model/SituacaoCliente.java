package com.totvs.sl.onboarding.core.cliente.domain.model;

import java.time.ZonedDateTime;

import com.totvs.sl.onboarding.core.util.DateTimeUtils;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class SituacaoCliente {

	private final SituacaoClienteValor valor;
	private final ZonedDateTime quando;

	public static SituacaoCliente ofAtivo() {
		return new SituacaoCliente(SituacaoClienteValor.ATIVO, DateTimeUtils.getNow());
	}

	public static SituacaoCliente ofInativo() {
		return new SituacaoCliente(SituacaoClienteValor.INATIVO, DateTimeUtils.getNow());
	}

	public boolean isAtivo() {
		return this.valor.equals(SituacaoClienteValor.ATIVO);
	}

	public boolean isInativo() {
		return this.valor.equals(SituacaoClienteValor.INATIVO);
	}

}
