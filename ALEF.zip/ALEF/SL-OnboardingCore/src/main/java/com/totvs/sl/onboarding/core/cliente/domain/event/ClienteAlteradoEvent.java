package com.totvs.sl.onboarding.core.cliente.domain.event;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class ClienteAlteradoEvent implements DomainEvent {

	private final String id;
	private final String nome;

	public static ClienteAlteradoEvent from(final Cliente cliente) {
		return new ClienteAlteradoEvent(cliente.getId().toString(), cliente.getNome());
	}

}
