package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoTransporteSituacaoNaoPermiteCancelarException extends RuntimeException {

	private static final long serialVersionUID = -3460253159494740380L;

}
