package com.totvs.sl.onboarding.core.cliente.domain.model;


public enum SituacaoClienteValor {
	ATIVO, INATIVO;
}
