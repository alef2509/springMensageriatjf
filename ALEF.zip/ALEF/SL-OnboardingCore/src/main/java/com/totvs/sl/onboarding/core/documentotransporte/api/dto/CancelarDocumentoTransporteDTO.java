package com.totvs.sl.onboarding.core.documentotransporte.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para cancelar um documento de transporte.")
public final class CancelarDocumentoTransporteDTO {

    @Schema(description = "cliente que cancelou o documento de transporte.", required = true)
    @NotBlank(message = "{CancelarDocumentoTransporteDTO.usuarioId.NotBlank}")
    @Size(max = 60, message = "{CancelarDocumentoTransporteDTO.usuarioId.Size}")
    private  final String usuarioId;
}
