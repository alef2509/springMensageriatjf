package com.totvs.sl.onboarding.core.cliente.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("ONBConstraintException")
public class ONBClienteConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -6592696533675017143L;

	public ONBClienteConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
