package com.totvs.sl.onboarding.core.cliente.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest("ONBConstraintException")
public class ONBCriarClienteException extends ConstraintViolationException {

	private static final long serialVersionUID = 6545283407705945822L;

	public ONBCriarClienteException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
