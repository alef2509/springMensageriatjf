package com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.time.ZonedDateTime;

@Data
@AllArgsConstructor(staticName = "of")
public final class CriarDocumentoTransporteCmd {
    public static final String NAME = "CriarDocumentoTransporteCmd";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";


    private  final String numero;
    private  final ZonedDateTime emissao;
    private  final String serie;
    private  final String modelo;
    private  final String chaveAcesso;
    private  final String cotacaoFreteId;
    private  final String remetenteId;
    private  final String destinatarioId;
    private  final String pagadorFreteId;
}
