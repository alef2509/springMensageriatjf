package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

public enum TipoDocumentoIdentificacao {
	CPF, CNPJ
}
