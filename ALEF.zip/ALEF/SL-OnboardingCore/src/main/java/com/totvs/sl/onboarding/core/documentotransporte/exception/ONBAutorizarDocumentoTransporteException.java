package com.totvs.sl.onboarding.core.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.Set;

@ApiBadRequest("ONBConstraintException")
public class ONBAutorizarDocumentoTransporteException extends ConstraintViolationException {

    private static final long serialVersionUID = 6545283407705945822L;

    public ONBAutorizarDocumentoTransporteException(Set<? extends ConstraintViolation<?>> constraintViolations) {
        super(constraintViolations);
    }
}
