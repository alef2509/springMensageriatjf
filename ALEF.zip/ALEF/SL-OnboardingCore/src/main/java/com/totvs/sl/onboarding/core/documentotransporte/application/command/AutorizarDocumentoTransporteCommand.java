package com.totvs.sl.onboarding.core.documentotransporte.application.command;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import lombok.Data;

@Data(staticConstructor = "of")
public final class AutorizarDocumentoTransporteCommand {
    private final DocumentoTransporteId id;
    private final String idAutoriza;
    private final String chaveAcesso;
}
