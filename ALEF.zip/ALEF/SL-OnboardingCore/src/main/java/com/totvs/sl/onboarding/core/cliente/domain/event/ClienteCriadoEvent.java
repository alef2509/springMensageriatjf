package com.totvs.sl.onboarding.core.cliente.domain.event;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.tjf.core.common.domain.DomainEvent;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public final class ClienteCriadoEvent implements DomainEvent {

	private final String id;
	private final String nome;
	private final String documento;
	private final boolean pessoaFisica;
	private final String situacao;

	public static ClienteCriadoEvent from(final Cliente cliente) {
		return new ClienteCriadoEvent(cliente.getId().toString(),
									  cliente.getNome(),
									  cliente.getDocumento().getNumero(),
									  cliente.getDocumento().isPessoaFisica(),
									  cliente.getSituacao().getValor().toString());
	}

}
