package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.tjf.repository.aggregate.AggregateRepository;

import java.util.Optional;

public interface DocumentoTransporteDomainRepository extends AggregateRepository<DocumentoTransporte, DocumentoTransporteId> {

    public Optional<DocumentoTransporte> findById(final DocumentoTransporteId id);

    public DocumentoTransporte findByIdOrThrowNotFound(final DocumentoTransporteId  id);

    public DocumentoTransporte insert(final DocumentoTransporte documentoTransporte);

    public DocumentoTransporte update(final DocumentoTransporte documentoTransporte);
}
