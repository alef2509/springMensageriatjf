package com.totvs.sl.onboarding.core.documentotransporte.api.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para alterar um documento de transporte.")
public final class AlterarDocumentoTransporteDTO {

    @Schema(description = "cotacao do documento de transporte.", required = true)
    @NotBlank(message = "{AlterarDocumentoTransporteDTO.cotacaoFreteId.NotBlank}")
    @Size(max = 60, message = "{AlterarDocumentoTransporteDTO.cotacaoFreteId.Size}")
    private  final String cotacaoFreteId;

    @Schema(description = "remetente do documento de transporte.", required = true)
    @NotBlank(message = "{AlterarDocumentoTransporteDTO.remetenteId.NotBlank}")
    @Size(max = 60, message = "{AlterarDocumentoTransporteDTO.remetenteId.Size}")
    private  final String remetenteId;

    @Schema(description = "destinatario do documento de transporte.", required = true)
    @NotBlank(message = "{AlterarDocumentoTransporteDTO.destinatarioId.NotBlank}")
    @Size(max = 60, message = "{AlterarDocumentoTransporteDTO.destinatarioId.Size}")
    private  final String destinatarioId;

    @Schema(description = "pagador do frete do documento de transporte.", required = true)
    @NotBlank(message = "{AlterarDocumentoTransporteDTO.pagadorFreteId.NotBlank}")
    @Size(max = 60, message = "{AlterarDocumentoTransporteDTO.pagadorFreteId.Size}")
    private  final String pagadorFreteId;
}
