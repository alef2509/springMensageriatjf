package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.totvs.tjf.core.common.domain.DomainObjectId;

public final class DocumentoTransporteId extends DomainObjectId<UUID> {

	private static final long serialVersionUID = 1L;

	protected DocumentoTransporteId(UUID id) {
		super(id);
	}

	public static DocumentoTransporteId generate() {
		return new DocumentoTransporteId(UUID.randomUUID());
	}

	@JsonCreator
	public static DocumentoTransporteId from(String id) {
		return id != null ? new DocumentoTransporteId(UUID.fromString(id)) : null;
	}

}
