package com.totvs.sl.onboarding.core.cliente.application;

import javax.transaction.Transactional;

import org.springframework.orm.jpa.JpaSystemException;
import org.springframework.stereotype.Service;

import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteDomainRepository;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBJaExisteClienteComMesmoDocumentoExcepition;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingPublisher;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class ClienteApplicationService {

	private static final String CLIENTE_DOCUMENTO_IDX = "cliente_documento_idx";

	private final ClienteDomainRepository repository;
	private final OnboardingPublisher publisher;

	public ClienteId handle(final CriarClienteCommand cmd) {

		var cliente = Cliente.builder()
							 .id(ClienteId.generate())
							 .nome(cmd.getNome())
							 .documento(cmd.getDocumento())
							 .build();

		try {
			repository.insert(cliente);
		} catch (JpaSystemException exception) {
			throw this.tratarExceptionPersistencia(exception, cmd.getDocumento());
		}

		publisher.dispatch(cliente.getEvents());

		return cliente.getId();

	}

	public void handle(final AlterarClienteCommand cmd) {

		var cliente = repository.findByIdOrThrowNotFound(cmd.getId());

		cliente.alterar(cmd.getNome());

		repository.update(cliente);

		publisher.dispatch(cliente.getEvents());

	}

	public void handle(final InativarClienteCommand cmd) {

		var cliente = repository.findByIdOrThrowNotFound(cmd.getId());

		cliente.inativar();

		repository.update(cliente);

		publisher.dispatch(cliente.getEvents());
	}

	public void handle(final AtivarClienteCommand cmd) {

		var cliente = repository.findByIdOrThrowNotFound(cmd.getId());

		cliente.ativar();

		repository.update(cliente);

		publisher.dispatch(cliente.getEvents());
	}

	private RuntimeException tratarExceptionPersistencia(final JpaSystemException exception,
														 final DocumentoIdentificacao documento) {
		var cause = exception.getRootCause();

		if ((cause != null) && (cause.getMessage().contains(CLIENTE_DOCUMENTO_IDX)))
			return new ONBJaExisteClienteComMesmoDocumentoExcepition(documento.getNumero());

		return exception;
	}


}
