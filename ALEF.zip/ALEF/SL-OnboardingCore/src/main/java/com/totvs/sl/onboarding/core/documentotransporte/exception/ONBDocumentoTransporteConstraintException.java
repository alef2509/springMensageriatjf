package com.totvs.sl.onboarding.core.documentotransporte.exception;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;

@ApiBadRequest
public class ONBDocumentoTransporteConstraintException extends ConstraintViolationException {

	private static final long serialVersionUID = -421295098178919213L;

	public ONBDocumentoTransporteConstraintException(Set<? extends ConstraintViolation<?>> constraintViolations) {
		super(constraintViolations);
	}

}
