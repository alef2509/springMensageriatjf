package com.totvs.sl.onboarding.core.cliente.api.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor(force = true)
@AllArgsConstructor(staticName = "of")
@Schema(description = "Informações para cadastro de um novo cliente.")
public final class CriarClienteDTO {

	@Schema(description = "Nome ou razão social do cliente.", required = true)
	@NotBlank(message = "{CriarClienteDTO.nome.NotBlank}")
	@Size(max = 60, message = "{CriarClienteDTO.nome.Size}")
	private final String nome;

	@Schema(description = "Documento de identificação do cliente, CPF ou CNPJ.", required = true)
	@NotBlank(message = "{CriarClienteDTO.documento.NotBlank}")
	@Size(min = 11, max = 14, message = "{CriarClienteDTO.documento.Size}")
	private final String documento;

}