create table documento_transporte (
                                      id             varchar(36)     not null,
                                      data           Jsonb,
                                      metadata       Jsonb,
                                      primary key (id)
);


create unique index documentotransportechave_idx
    on documento_transporte (
        (COALESCE(data->>'chaveacesso','NULL'))
    );