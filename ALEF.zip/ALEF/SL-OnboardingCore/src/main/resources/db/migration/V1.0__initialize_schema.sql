
create table cliente (
    id             varchar(36)     not null,
    data           Jsonb,
    metadata       Jsonb,
    primary key (id)
);

create unique index cliente_documento_idx
    on cliente (
        (COALESCE(data->>'documento','NULL'))
    );



