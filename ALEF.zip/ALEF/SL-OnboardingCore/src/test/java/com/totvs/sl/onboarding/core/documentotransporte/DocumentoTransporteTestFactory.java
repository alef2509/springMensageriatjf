package com.totvs.sl.onboarding.core.documentotransporte;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteDomainRepository;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteDomainRepository;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;

public final class DocumentoTransporteTestFactory {

	public static DocumentoTransporte.DocumentoTransporteBuilder geradodeDocumentoTransporte() {

		return DocumentoTransporte.builder()
								  .id(DocumentoTransporteId.generate())
								  .numero("1234")
								  .serie("123")
								  .emissao(DateTimeUtils.getNow())
								  .modelo("12")
								  .chaveAcesso("30399462417772944246614321172896928750631741")
								  .cotacaoFreteId(CotacaoFreteId.generate())
								  .remetenteId(ClienteId.generate())
								  .destinatarioId(ClienteId.generate())
								  .pagadorFreteId(ClienteId.generate());

	}

	public static DocumentoTransporte umDocumentoTransporteDigitado() {

		var documentoTransporte = geradodeDocumentoTransporte().build();
		documentoTransporte.removeEvents();

		return documentoTransporte;
	}

	public static DocumentoTransporte umDocumentoTransporteAnulado(String usuarioId) {

		var documentoTransporte = geradodeDocumentoTransporte().build();
		documentoTransporte.anular(usuarioId);
		documentoTransporte.removeEvents();

		return documentoTransporte;
	}
	public static DocumentoTransporte persistir(DocumentoTransporteDomainRepository repository, DocumentoTransporte documentoTransporte) {
		return repository.insert(documentoTransporte);
	}

	public static DocumentoTransporte umDocumentoTransporteAutorizado(String usuarioId, String chaveAcesso) {

		var documentoTransporte = geradodeDocumentoTransporte().build();
		documentoTransporte.autorizar(usuarioId, chaveAcesso);
		documentoTransporte.removeEvents();

		return documentoTransporte;
	}

	public static DocumentoTransporte umDocumentoTransporteCancelado(String usuarioId) {

		var documentoTransporte = geradodeDocumentoTransporte().build();
		documentoTransporte.cancelar(usuarioId);
		documentoTransporte.removeEvents();

		return documentoTransporte;
	}

	public static DocumentoTransporte umDocumentoTransporteDigitadoComDocumentoCarga(DocumentoCarga documentoCarga) {
		var documentoTransporte = geradodeDocumentoTransporte().build();
		documentoTransporte.adicionarDocumentoCarga(documentoCarga);
		documentoTransporte.removeEvents();

		return documentoTransporte;

	}

}
