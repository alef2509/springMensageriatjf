package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;

public class DocumentoTransporteAutorizadoEventAssert
		extends AbstractAssert<DocumentoTransporteAutorizadoEventAssert, DocumentoTransporteAutorizadoEvent> {

	public DocumentoTransporteAutorizadoEventAssert(DocumentoTransporteAutorizadoEvent actual) {
		super(actual, DocumentoTransporteAutorizadoEventAssert.class);
	}

	public DocumentoTransporteAutorizadoEventAssert hasInformationAccordingTo(DocumentoTransporte documentoTransporte) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(documentoTransporte.getId().toString());
		assertThat(actual.getQuando()).isEqualTo(documentoTransporte.getSituacao().getQuando().toString());
		assertThat(actual.getUsuario()).isEqualTo(documentoTransporte.getSituacao().getUsuarioId());
		assertThat(actual.getChaveAcesso()).isEqualTo(documentoTransporte.getChaveAcesso());

		return this;
	}

	public static DocumentoTransporteAutorizadoEventAssert assertThatEvent(DocumentoTransporteAutorizadoEvent actual) {
		return new DocumentoTransporteAutorizadoEventAssert(actual);
	}
}