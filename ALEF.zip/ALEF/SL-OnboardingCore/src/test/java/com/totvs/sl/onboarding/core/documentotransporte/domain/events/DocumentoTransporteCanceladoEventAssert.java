package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;

public class DocumentoTransporteCanceladoEventAssert
		extends AbstractAssert<DocumentoTransporteCanceladoEventAssert, DocumentoTransporteCanceladoEvent> {

	public DocumentoTransporteCanceladoEventAssert(DocumentoTransporteCanceladoEvent actual) {
		super(actual, DocumentoTransporteCanceladoEventAssert.class);
	}

	public DocumentoTransporteCanceladoEventAssert hasInformationAccordingTo(DocumentoTransporte documentoTransporte) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(documentoTransporte.getId().toString());
		assertThat(actual.getQuando()).isEqualTo(documentoTransporte.getSituacao().getQuando().toString());
		assertThat(actual.getUsuario()).isEqualTo(documentoTransporte.getSituacao().getUsuarioId());

		return this;
	}

	public static DocumentoTransporteCanceladoEventAssert assertThatEvent(DocumentoTransporteCanceladoEvent actual) {
		return new DocumentoTransporteCanceladoEventAssert(actual);
	}
}