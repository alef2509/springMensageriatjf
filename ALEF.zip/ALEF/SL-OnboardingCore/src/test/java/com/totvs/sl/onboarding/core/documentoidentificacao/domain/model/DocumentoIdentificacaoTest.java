package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCNPJConstraintException;
import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCPFConstraintException;
import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBDocumentoIdentificacaoInvalidoException;
import com.totvs.tjf.core.validation.ValidatorService;

@DisplayName("DocumentoIdentificacao - Domínio")
class DocumentoIdentificacaoTest {

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	@Test
	void deveConstruirDocumentoIdentificacaoCPF() {

		// given
		var numeroCPF = "05351821982";

		// when
		var documento = DocumentoIdentificacao.from(numeroCPF);

		// then
		assertThat(documento.isPessoaFisica()).isTrue();
		assertThat(documento.isPessoaJuridica()).isFalse();
		assertThat(documento.getNumero()).isEqualTo(numeroCPF);
		assertThat(documento.getTipo()).isEqualTo(TipoDocumentoIdentificacao.CPF);
	}

	@Test
	void deveConstruirDocumentoIdentificacaoCNPJ() {

		// given
		var numeroCNPJ = "52574330000194";

		// when
		var documento = DocumentoIdentificacao.from(numeroCNPJ);

		// then
		assertThat(documento.isPessoaFisica()).isFalse();
		assertThat(documento.isPessoaJuridica()).isTrue();
		assertThat(documento.getNumero()).isEqualTo(numeroCNPJ);
		assertThat(documento.getTipo()).isEqualTo(TipoDocumentoIdentificacao.CNPJ);
	}

	@Test
	void documentosComMesmosNumerosDevemSerIguais() {

		// given
		var numeroCPF = "05351821982";
		var numeroCNPJ = "52574330000194";

		// when then
		assertThat(DocumentoIdentificacao.from(numeroCPF)).isEqualTo(DocumentoIdentificacao.from(numeroCPF));
		assertThat(DocumentoIdentificacao.from(numeroCNPJ)).isEqualTo(DocumentoIdentificacao.from(numeroCNPJ));
	}

	@Nested
	@DisplayName("Teste de falha")
	class CaminhoInfeliz {

		@Test
		void deveRetornarDocumentoInvalidoParaCPFInvalido() {

			// when then
			assertThatExceptionOfType(ONBCPFConstraintException.class).isThrownBy(() -> DocumentoIdentificacao.from("05351821983"));
		}

		@Test
		void deveRetornarDocumentoInvalidoParaCNPJInvalido() {

			// when then
			assertThatExceptionOfType(ONBCNPJConstraintException.class).isThrownBy(() -> DocumentoIdentificacao.from("79384026000131"));
		}

		@NullSource
		@ValueSource(strings = { "123456", "", " ", "A" })
		@ParameterizedTest
		void deveRetornarDocumentoInvalidoParaDocumentoDiferenteDeCNPJCPF(String documentoInvalido) {
			// when then
			assertThatExceptionOfType(ONBDocumentoIdentificacaoInvalidoException.class).isThrownBy(() -> DocumentoIdentificacao.from(documentoInvalido));
		}

	}
}