package com.totvs.sl.onboarding.core.cliente.amqp;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.totvs.sl.onboarding.core.cliente.amqp.cmd.AlterarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.AtivarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.CriarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.InativarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.util.AdapterConfigIT;
import com.totvs.sl.onboarding.core.util.TestUtils;
import com.totvs.tjf.core.message.TOTVSMessage;

@DisplayName("ClienteSubscriberIT - Teste de recebimento de mensagens")
class ClienteSubscriberIT extends AdapterConfigIT {

	@Autowired
	private OnboardingChannel.OnboardingExchangeInput exchange;

	private final ClienteId id = ClienteId.generate();
	private final String nome = "NOME CLIENTE";
	private final String cpf = "90817824014";
	private final String cnpj = "10999961000105";

	@BeforeAll
	public static void before() {
		TestUtils.setAuthenticationInfo();
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaCriarClientePessoaFisica() throws Exception {

		// given
		var cmd = CriarClienteCmd.of(nome, cpf);

		var commandEsperado = CriarClienteCommand.of(cmd.getNome(), DocumentoIdentificacao.from(cmd.getDocumento()));

		when(mockClienteAppService.handle(commandEsperado)).thenReturn(ClienteId.generate());

		var message = new TOTVSMessage<CriarClienteCmd>(CriarClienteCmd.NAME, cmd);

		// when
		message.sendTo(this.exchange.input());

		// then
		verify(mockClienteAppService).handle(commandEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaCriarClientePessoaJuridica() throws Exception {

		// given
		var cmd = CriarClienteCmd.of(nome, cnpj);

		var commandEsperado = CriarClienteCommand.of(cmd.getNome(), DocumentoIdentificacao.from(cmd.getDocumento()));

		when(mockClienteAppService.handle(commandEsperado)).thenReturn(ClienteId.generate());

		var message = new TOTVSMessage<CriarClienteCmd>(CriarClienteCmd.NAME, cmd);

		// when
		message.sendTo(this.exchange.input());

		// then
		verify(mockClienteAppService).handle(commandEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaAlterarCliente() throws Exception {

		// given

		var cmd = AlterarClienteCmd.of(id.toString(), nome);

		var commandEsperado = AlterarClienteCommand.of(id, cmd.getNome());

		var message = new TOTVSMessage<AlterarClienteCmd>(AlterarClienteCmd.NAME, cmd);

		// when
		message.sendTo(this.exchange.input());

		// then
		verify(mockClienteAppService).handle(commandEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaInativarCliente() throws Exception {

		// given
		var cmd = InativarClienteCmd.of(id.toString());

		var commandEsperado = InativarClienteCommand.of(id);

		var message = new TOTVSMessage<InativarClienteCmd>(InativarClienteCmd.NAME, cmd);

		// when
		message.sendTo(this.exchange.input());

		// then
		verify(mockClienteAppService).handle(commandEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaAtivarCliente() throws Exception {

		// give
		var cmd = AtivarClienteCmd.of(id.toString());

		var cmdEsperado = AtivarClienteCommand.of(id);

		var message = new TOTVSMessage<AtivarClienteCmd>(AtivarClienteCmd.NAME, cmd);

		// when
		message.sendTo(this.exchange.input());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}
}