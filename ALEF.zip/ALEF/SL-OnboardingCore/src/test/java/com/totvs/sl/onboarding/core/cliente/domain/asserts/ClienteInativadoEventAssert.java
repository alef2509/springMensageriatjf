package com.totvs.sl.onboarding.core.cliente.domain.asserts;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;

public class ClienteInativadoEventAssert extends AbstractAssert<ClienteInativadoEventAssert, ClienteInativadoEvent> {

	public ClienteInativadoEventAssert(ClienteInativadoEvent actual) {
		super(actual, ClienteInativadoEventAssert.class);
	}

	public ClienteInativadoEventAssert hasInformationAccordingTo(Cliente cliente) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(cliente.getId().toString());
		assertThat(actual.getSituacao()).isEqualTo(cliente.getSituacao().getValor().toString());

		return this;
	}

	public static ClienteInativadoEventAssert assertThatEvent(ClienteInativadoEvent actual) {
		return new ClienteInativadoEventAssert(actual);
	}
}