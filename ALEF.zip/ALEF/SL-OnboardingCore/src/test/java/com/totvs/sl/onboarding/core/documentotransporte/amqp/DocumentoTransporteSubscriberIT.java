package com.totvs.sl.onboarding.core.documentotransporte.amqp;

import com.totvs.sl.onboarding.core.cliente.amqp.cmd.AlterarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.CriarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.amqp.cmd.InativarClienteCmd;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd.*;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.util.AdapterConfigIT;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.sl.onboarding.core.util.TestUtils;
import com.totvs.tjf.core.message.TOTVSMessage;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDate;
import java.time.ZonedDateTime;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DisplayName("DocumentoTransporteSubscriberIT - Teste de recebimento de mensagens")
public class DocumentoTransporteSubscriberIT extends AdapterConfigIT {

    @Autowired
    private OnboardingChannel.OnboardingExchangeInput exchange;

    private final String id = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String idCarga = "11666b8e-53b0-4058-80a4-f1875b9447g6";
    private final ZonedDateTime emissao = DateTimeUtils.getNow();
    private final String numero = "1";
    private final String serie = "1";
    private final String modelo = "1";
    private final String chaveAcesso = "30399462417772944246614321172896928750631741";
    private final String remetenteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String cotacaoFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String destinatarioId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String pagadorFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";

    private final String remetenteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String cotacaoFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String destinatarioIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String pagadorFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";

    @BeforeAll
    public static void before() {
        TestUtils.setAuthenticationInfo();
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaCriarDocumentoTransporte() throws Exception {

        // given
        var cmd = CriarDocumentoTransporteCmd.of(numero, emissao ,
                serie,modelo,chaveAcesso, cotacaoFreteId, remetenteId,
                destinatarioId,pagadorFreteId);

        var commandEsperado = CriarDocumentoTransporteCommand.of(cmd.getNumero(), emissao ,
                cmd.getSerie(),cmd.getModelo(), cmd.getChaveAcesso(),CotacaoFreteId.from(cmd.getCotacaoFreteId()), ClienteId.from(cmd.getRemetenteId()),
                ClienteId.from(cmd.getDestinatarioId()),ClienteId.from(cmd.getPagadorFreteId()));

        //when(mockDocumentoTransporteAppService.handle(commandEsperado)).thenReturn(DocumentoTransporteId.generate());
        mockDocumentoTransporteAppService.handle(commandEsperado);

        var message = new TOTVSMessage<CriarDocumentoTransporteCmd>(CriarDocumentoTransporteCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAlterarDocumentoTransporte() throws Exception {

        // given

        var cmd = AlterarDocumentoTransporteCmd.of( "11666b8e-51b0-4058-80a4-f1875b9447e5",cotacaoFreteId,remetenteIdNew,
                destinatarioIdNew,pagadorFreteIdNew);

        var commandEsperado = AlterarDocumentoTransporteCommand.of(DocumentoTransporteId.from(cmd.getId()), CotacaoFreteId.from(cmd.getCotacaoFreteId()),ClienteId.from(cmd.getRemetenteId()),ClienteId.from(cmd.getDestinatarioId()), ClienteId.from(cmd.getPagadorFreteId()));

        var message = new TOTVSMessage<AlterarDocumentoTransporteCmd>(AlterarDocumentoTransporteCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAnularDocumentoTransporte() throws Exception {

        // given
        var cmd = AnularDocumentoTransporteCmd.of(id, cotacaoFreteId);

        var commandEsperado = AnularDocumentoTransporteCommand.of(DocumentoTransporteId.from(id), cotacaoFreteId);

        var message = new TOTVSMessage<AnularDocumentoTransporteCmd>(AnularDocumentoTransporteCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }


    @Test
    void deveReceberSolicitacaoEDispararComandoParaCancelarDocumentoTransporte() throws Exception {

        // given
        var cmd = CancelarDocumentoTransporteCmd.of(id, cotacaoFreteId);

        var commandEsperado = CancelarDocumentoTransporteCommand.of(DocumentoTransporteId.from(id), cotacaoFreteId);

        var message = new TOTVSMessage<CancelarDocumentoTransporteCmd>(CancelarDocumentoTransporteCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }



    @Test
    void deveReceberSolicitacaoEDispararComandoParaAutorizarDocumentoTransporte() throws Exception {

        // given
        var cmd = AutorizarDocumentoTransporteCmd.of(id, cotacaoFreteId, chaveAcesso) ;

        var commandEsperado = AutorizarDocumentoTransporteCommand.of(DocumentoTransporteId.from(id), cotacaoFreteId, chaveAcesso);

        var message = new TOTVSMessage<AutorizarDocumentoTransporteCmd>(AutorizarDocumentoTransporteCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAdicionarDocumentoCargaDocumentoTransporte() throws Exception {

        // given
        var cmd = AdicionarDocumentoCargaCmd.of(id, LocalDate.now(), numero, serie, modelo, chaveAcesso) ;

        var commandEsperado = AdicionarDocumentoCargaCommand.of(DocumentoTransporteId.from(cmd.getId()), cmd.getEmissao(), cmd.getNumero(), cmd.getSerie(), cmd.getModelo(), cmd.getChaveAcesso());

        var message = new TOTVSMessage<AdicionarDocumentoCargaCmd>(AdicionarDocumentoCargaCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaExcluirDocumentoCargaDocumentoTransporte() throws Exception {

        // given
        var cmd = ExcluirDocumentoCargaCmd.of(id, DocumentoCargaId.generate().toString()) ;

        var commandEsperado = ExcluirDocumentoCargaCommand.of(DocumentoTransporteId.from(cmd.getId()), DocumentoCargaId.from(cmd.getIdCarga()));

        var message = new TOTVSMessage<ExcluirDocumentoCargaCmd>(ExcluirDocumentoCargaCmd.NAME, cmd);

        // when
        message.sendTo(this.exchange.input());

        // then
        verify(mockDocumentoTransporteAppService).handle(commandEsperado);
    }


}
