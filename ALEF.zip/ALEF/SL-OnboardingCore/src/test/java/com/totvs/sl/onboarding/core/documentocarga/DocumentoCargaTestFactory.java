package com.totvs.sl.onboarding.core.documentocarga;

import java.time.LocalDate;
import java.time.ZoneOffset;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;

public class DocumentoCargaTestFactory {

	public static DocumentoCarga.DocumentoCargaBuilder umDocumentoCarga() {

		return DocumentoCarga.builder()
							 .id(DocumentoCargaId.generate())
							 .emissao(LocalDate.now(ZoneOffset.UTC))
							 .numero("1")
							 .modelo("2")
							 .serie("3")
							 .chaveAcesso("11111111111111111111111111111111111111111111");

	}

}
