package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;

public class DocumentoTransporteAlteradoEventAssert
		extends AbstractAssert<DocumentoTransporteAlteradoEventAssert, DocumentoTransporteAlteradoEvent> {

	public DocumentoTransporteAlteradoEventAssert(DocumentoTransporteAlteradoEvent actual) {
		super(actual, DocumentoTransporteAlteradoEventAssert.class);
	}

	public DocumentoTransporteAlteradoEventAssert hasInformationAccordingTo(DocumentoTransporte documentoTransporte) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(documentoTransporte.getId().toString());
		assertThat(actual.getCotacaoFreteId()).isEqualTo(documentoTransporte.getCotacaoFreteId()
																			.map(CotacaoFreteId::toString)
																			.orElse(null));
		assertThat(actual.getDestinatarioId()).isEqualTo(documentoTransporte.getDestinatarioId()
																			.map(ClienteId::toString)
																			.orElse(null));
		assertThat(actual.getRemetenteId()).isEqualTo(documentoTransporte.getRemetenteId()
																		 .map(ClienteId::toString)
																		 .orElse(null));
		assertThat(actual.getPagadorFreteId()).isEqualTo(documentoTransporte.getPagadorFreteId()
																			.map(ClienteId::toString)
																			.orElse(null));

		return this;
	}

	public static DocumentoTransporteAlteradoEventAssert assertThatEvent(DocumentoTransporteAlteradoEvent actual) {
		return new DocumentoTransporteAlteradoEventAssert(actual);
	}
}