package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCNPJConstraintException;
import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCNPJSomenteZerosException;
import com.totvs.tjf.core.validation.ValidatorService;

@DisplayName("CNPJ - Domínio")
class CNPJTest {

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	@ValueSource(strings = { "75822063000122", "47931259000110", "97542340000186", "18544914000189" })
	@ParameterizedTest
	void deveConstruirCNPJValido(String valor) {

		// when then
		assertThat(CNPJ.from(valor).getNumero()).isEqualTo(valor);
	}

	@ValueSource(strings = { "75822063000122", "47931259000110", "97542340000186" })
	@ParameterizedTest
	void deveCompararComoIguaisCNPJsComNumerosIguais(String valor) {

		// when then
		assertThat(CNPJ.from(valor)).isEqualTo(CNPJ.from(valor));
	}

	@Nested
	@DisplayName("Teste de falha")
	class CaminhoInfeliz {

		@NullSource
		@ValueSource(strings = { "75822063000124", "47931259000113", "", "¿ª¿£®Ü»ÆÂø┼ºº┼", "1234567890.123", "123" })
		@ParameterizedTest
		void deveRetornarCNPJInvalidoParaValoresInvalidos(String valor) {

			// when then
			assertThatExceptionOfType(ONBCNPJConstraintException.class).isThrownBy(() -> CNPJ.from(valor));
		}

		@ValueSource(strings = { "11111111111111", "22222222222222", "33333333333333", "44444444444444",
				"55555555555555", "66666666666666", "77777777777777", "88888888888888", "99999999999999" })
		@ParameterizedTest
		void deveRetonarCNPJInvalidoQuandoNumerosTodosIguaisExcetoZeros(String valor) {

			// when then
			assertThatExceptionOfType(ONBCNPJConstraintException.class).isThrownBy(() -> CNPJ.from(valor));
		}

		@Test
		void deveRetonarCNPJInvalidoQuandoSomenteZeros() {

			// when then
			assertThatExceptionOfType(ONBCNPJSomenteZerosException.class).isThrownBy(() -> CNPJ.from("00000000000000"));
		}
	}
}