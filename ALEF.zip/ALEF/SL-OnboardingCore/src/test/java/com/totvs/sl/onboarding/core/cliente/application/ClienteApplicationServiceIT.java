package com.totvs.sl.onboarding.core.cliente.application;

import static com.totvs.sl.onboarding.core.util.TestUtils.assertThatEventsHaveBeenDispatched;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.orm.jpa.JpaSystemException;

import com.totvs.sl.onboarding.core.cliente.ClienteTestFactory;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteNaoEncontradoException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBJaExisteClienteComMesmoDocumentoExcepition;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.util.ApplicationConfigIT;
import com.totvs.tjf.core.common.domain.DomainEvent;

@DisplayName("ClienteApplicationService - Teste de processamento dos comandos de aplicação")
class ClienteApplicationServiceIT extends ApplicationConfigIT {

	private final String nome = "NOME DEPOSITANTE";
	private final String novoNome = "NOVO NOME DEPOSITANTE";
	private final String cpf = "90817824014";
	private final String cnpj = "10999961000105";

	@Test
	void deveCriarClientePessoaFisicaPublicandoEvento() {

		// given
		var cmd = CriarClienteCommand.of(nome, DocumentoIdentificacao.from(cpf));

		// when
		var id = clienteAppService.handle(cmd);

		// then
		var cliente = clienteRepository.findByIdOrThrowNotFound(id);

		assertThat(cliente.getId()).isEqualTo(id);
		assertThat(cliente.getNome()).isEqualTo(cmd.getNome());
		assertThat(cliente.getDocumento()).isEqualTo(cmd.getDocumento());

		var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
		verify(publisher).dispatch(eventArgument.capture());
		assertThatEventsHaveBeenDispatched(eventArgument.getAllValues(), Map.of(ClienteCriadoEvent.class, 1));

	}

	@Test
	void deveCriarClientePessoaJuridicaPublicandoEvento() {

		// given
		var cmd = CriarClienteCommand.of(nome, DocumentoIdentificacao.from(cnpj));

		// when
		var id = clienteAppService.handle(cmd);

		// then
		var cliente = clienteRepository.findByIdOrThrowNotFound(id);

		assertThat(cliente.getId()).isEqualTo(id);
		assertThat(cliente.getNome()).isEqualTo(cmd.getNome());
		assertThat(cliente.getDocumento()).isEqualTo(cmd.getDocumento());

		var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
		verify(publisher).dispatch(eventArgument.capture());
		assertThat(eventArgument.getValue()).isInstanceOf(ClienteCriadoEvent.class);

	}

	@Test
	void deveAlterarClienteEmitindoEvento() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var cmd = AlterarClienteCommand.of(cliente.getId(), novoNome);

		// when
		clienteAppService.handle(cmd);

		// then
		var clienteAlterado = clienteRepository.findByIdOrThrowNotFound(cliente.getId());
		assertThat(clienteAlterado.getNome()).isEqualTo(novoNome);

		var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
		verify(publisher).dispatch(eventArgument.capture());
		assertThat(eventArgument.getValue()).isInstanceOf(ClienteAlteradoEvent.class);
	}

	@Test
	void deveInativarClienteEmitindoEvento() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var cmd = InativarClienteCommand.of(cliente.getId());

		// when
		clienteAppService.handle(cmd);

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId());
		assertThat(clienteAtualizado.getSituacao().isInativo()).isTrue();

		var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
		verify(publisher).dispatch(eventArgument.capture());
		assertThat(eventArgument.getValue()).isInstanceOf(ClienteInativadoEvent.class);
	}

	@Test
	void deveAtivarClienteEmitindoEvento() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteInativo());

		var cmd = AtivarClienteCommand.of(cliente.getId());

		// when
		clienteAppService.handle(cmd);

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId());
		assertThat(clienteAtualizado.getSituacao().isAtivo()).isTrue();

		var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
		verify(publisher).dispatch(eventArgument.capture());
		assertThat(eventArgument.getValue()).isInstanceOf(ClienteAtivadoEvent.class);
	}

	@Test
	void naoDeveCriarClienteComMesmoDocumento() {

		// given
		var clienteAtivo = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var cmd = CriarClienteCommand.of(nome, clienteAtivo.getDocumento());

		// when
		var thrown = catchThrowable(() -> clienteAppService.handle(cmd));

		// then
		assertThat(thrown).isInstanceOf(ONBJaExisteClienteComMesmoDocumentoExcepition.class);
	}

	@Test
	void naoDeveAlterarClienteComIdDeClienteNaoExistente() {

		// given
		var cmd = AlterarClienteCommand.of(ClienteId.generate(), nome);

		// when
		var thrown = catchThrowable(() -> clienteAppService.handle(cmd));

		// then
		assertThat(thrown).isInstanceOf(ONBClienteNaoEncontradoException.class);
	}

	@Test
	void naoDeveAlterarClienteQuandoOcorrerAlgumErroComBancoDeDados() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var cmd = AlterarClienteCommand.of(cliente.getId(), novoNome);

		doThrow(JpaSystemException.class).when(clienteRepository).update(Mockito.any());

		// when
		var thrown = catchThrowable(() -> clienteAppService.handle(cmd));

		// then
		assertThat(thrown).isInstanceOf(JpaSystemException.class);
	}
}