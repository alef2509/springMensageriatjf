package com.totvs.sl.onboarding.core.util;

import static java.util.Objects.isNull;

import javax.validation.Validator;

import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

public class ConstraintUtils {

	private static LocalValidatorFactoryBean validatorFactory;

	public static Validator getValidator() {

		if (isNull(validatorFactory)) {

			ReloadableResourceBundleMessageSource bundle = new ReloadableResourceBundleMessageSource();
			bundle.addBasenames("classpath:i18n/validation/messages");
			bundle.setDefaultEncoding("UTF-8");

			validatorFactory = new LocalValidatorFactoryBean();
			validatorFactory.setValidationMessageSource(bundle);
			validatorFactory.afterPropertiesSet();
		}

		return validatorFactory.getValidator();
	}

}
