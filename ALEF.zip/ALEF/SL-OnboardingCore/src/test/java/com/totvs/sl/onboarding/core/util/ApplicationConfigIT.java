package com.totvs.sl.onboarding.core.util;

import javax.transaction.Transactional;

import com.totvs.sl.onboarding.core.documentotransporte.application.DocumentoTransporteApplicationService;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteDomainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ActiveProfiles;

import com.totvs.sl.onboarding.core.cliente.application.ClienteApplicationService;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteDomainRepository;
import com.totvs.sl.onboarding.core.config.amqp.OnboardingPublisher;

@SpringBootTest
@ActiveProfiles(profiles = "test")
@Transactional
public abstract class ApplicationConfigIT {

	@SpyBean
	protected OnboardingPublisher publisher;

	@SpyBean
	@Autowired
	protected ClienteDomainRepository clienteRepository;

	@Autowired
	protected ClienteApplicationService clienteAppService;

	@SpyBean
	@Autowired
	protected DocumentoTransporteDomainRepository documentoTransporteRepository;

	@Autowired
	protected DocumentoTransporteApplicationService documentoTransporteAppService;

}
