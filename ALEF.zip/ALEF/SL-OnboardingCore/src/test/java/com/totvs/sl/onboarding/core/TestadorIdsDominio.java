package com.totvs.sl.onboarding.core;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.lang.reflect.InvocationTargetException;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;

class TestadorIdsDominio {

	/*
	 * TODO - Verificar possibilidade de utilização das anotações @ParameterizedTest
	 * e MethodSource.
	 */
	@Test
	void testarTodos()
			throws ClassNotFoundException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		var classes = new Class[] { ClienteId.class };

		for (var clazz : classes) {

			Class<?> cls = Class.forName(clazz.getName());

			for (var method : cls.getDeclaredMethods()) {

				switch (method.getName()) {

				case "from":
					var uuid = UUID.randomUUID().toString();
					var instance = method.invoke(method.getName(), uuid);
					assertEquals(uuid, instance.toString(), "Falha ao testar: " + clazz.getName());

					var instance2 = method.invoke(method.getName(), uuid);
					assertEquals(instance, instance2, "Falha ao testar: " + clazz.getName());

					break;
				case "generate":
					assertNotNull(method.invoke(method.getName()), "Falha ao testar: " + clazz.getName());
					break;
				}
			}
		}
	}
}
