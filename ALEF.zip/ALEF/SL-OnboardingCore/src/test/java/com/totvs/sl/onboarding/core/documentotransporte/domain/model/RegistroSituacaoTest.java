package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class RegistroSituacaoTest {

	private final String usuarioId = "12345";

	@Test
	void deveConstruirRegistroSituacaoDigitado() {

		// when
		var registroSituacao = RegistroSituacao.ofDigitado();

		// then
		assertThat(registroSituacao.getValor()).isEqualTo(SituacaoDocumento.DIGITADO);
		assertThat(registroSituacao.getQuando()).isNotNull();

	}

	@Test
	void deveConstruirRegistroSituacaoAutorizado() {

		// when
		var registroSituacao = RegistroSituacao.ofAutorizado(usuarioId);

		// then
		assertThat(registroSituacao.getUsuarioId()).isEqualTo(usuarioId);
		assertThat(registroSituacao.getValor()).isEqualTo(SituacaoDocumento.AUTORIZADO);
		assertThat(registroSituacao.getQuando()).isNotNull();

	}

	@Test
	void deveConstruirRegistroSituacaoCancelado() {

		// when
		var registroSituacao = RegistroSituacao.ofCancelado(usuarioId);

		// then
		assertThat(registroSituacao.getUsuarioId()).isEqualTo(usuarioId);
		assertThat(registroSituacao.getValor()).isEqualTo(SituacaoDocumento.CANCELADO);
		assertThat(registroSituacao.getQuando()).isNotNull();

	}

	@Test
	void deveConstruirRegistroSituacaoAnulado() {

		// when
		var registroSituacao = RegistroSituacao.ofAnulado(usuarioId);

		// then
		assertThat(registroSituacao.getUsuarioId()).isEqualTo(usuarioId);
		assertThat(registroSituacao.getValor()).isEqualTo(SituacaoDocumento.ANULADO);
		assertThat(registroSituacao.getQuando()).isNotNull();

	}

}
