package com.totvs.sl.onboarding.core.documentocarga.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import com.totvs.sl.onboarding.core.documentocarga.DocumentoCargaTestFactory;
import com.totvs.sl.onboarding.core.documentocarga.exception.ONBDocumentoCargaConstraintException;
import com.totvs.sl.onboarding.core.util.TestUtils;
import com.totvs.tjf.core.validation.ValidatorService;

@DisplayName("DocumentoCargaTest - Teste de comportamento do agregado")
class DocumentoCargaTest {

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	@Test
	void deveConstruirDocumentoCargaComTodosAtributos() {

		// given
		var id = DocumentoCargaId.generate();
		var emissao = LocalDate.now(ZoneOffset.UTC);
		var numero = "123456789";
		var serie = "123";
		var modelo = "12";
		var chaveAcesso = "30399462417772944246614321172896928750631741";

		// when
		var documentoCarga = DocumentoCarga.builder()
										   .id(id)
										   .emissao(emissao)
										   .numero(numero)
										   .serie(serie)
										   .modelo(modelo)
										   .chaveAcesso(chaveAcesso)
										   .build();

		// then
		assertThat(documentoCarga.getId()).isEqualTo(id);
		assertThat(documentoCarga.getEmissao()).isEqualTo(emissao);
		assertThat(documentoCarga.getNumero()).isEqualTo(numero);
		assertThat(documentoCarga.getSerie()).isEqualTo(serie);
		assertThat(documentoCarga.getModelo()).isEqualTo(modelo);
		assertThat(documentoCarga.getChaveAcesso()).isEqualTo(chaveAcesso);

	}

	@Test
	void deveConstruirDocumentoCargaComAtributosObrigatorios() {

		// given
		var id = DocumentoCargaId.generate();
		var emissao = LocalDate.now(ZoneOffset.UTC);
		var numero = "123456789";
		var serie = "123";
		var modelo = "12";

		// when
		var documentoCarga = DocumentoCarga.builder()
										   .id(id)
										   .emissao(emissao)
										   .numero(numero)
										   .serie(serie)
										   .modelo(modelo)
										   .build();

		// then
		assertThat(documentoCarga.getId()).isEqualTo(id);
		assertThat(documentoCarga.getEmissao()).isEqualTo(emissao);
		assertThat(documentoCarga.getNumero()).isEqualTo(numero);
		assertThat(documentoCarga.getSerie()).isEqualTo(serie);
		assertThat(documentoCarga.getModelo()).isEqualTo(modelo);
		assertThat(documentoCarga.getChaveAcesso()).isNull();

	}

	@Nested
	@DisplayName("Teste de falha")
	class CaminhoInfeliz {

		@Test
		void naoDeveConstruirDocumentoCargaSemAtributosObrigatorios() {

			// given
			var validations = Set.of("DocumentoCarga.id.NotNull",
									 "DocumentoCarga.emissao.NotNull",
									 "DocumentoCarga.numero.NotBlank",
									 "DocumentoCarga.serie.NotBlank",
									 "DocumentoCarga.modelo.NotBlank");

			var builder = DocumentoCarga.builder();

			// when
			var exception = catchThrowableOfType(() -> builder.build(), ONBDocumentoCargaConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoCargaComAtributosDeTamanhosMaioresQueEsperado() {

			// given
			var numero = "1234567890";
			var serie = "1234567890";
			var modelo = "1234567890";
			var chaveAcesso = "1111111111111111111111111111111111111111111111";

			var validations = Set.of("DocumentoCarga.numero.Size",
									 "DocumentoCarga.serie.Size",
									 "DocumentoCarga.modelo.Size",
									 "DocumentoCarga.chaveAcesso.Size");

			var builder = DocumentoCargaTestFactory.umDocumentoCarga()
												   .numero(numero)
												   .serie(serie)
												   .modelo(modelo)
												   .chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(), ONBDocumentoCargaConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoCargaComAtributosDeTamanhosMenoresQueEsperado() {

			// given
			var chaveAcesso = "11111111";

			var validations = Set.of("DocumentoCarga.chaveAcesso.Size");

			var builder = DocumentoCargaTestFactory.umDocumentoCarga().chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(), ONBDocumentoCargaConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoCargaQuandoAtributosNaoPossuiremSomenteNumeros() {

			// given
			var numero = "1234a";
			var serie = "12a";
			var modelo = "1a";
			var chaveAcesso = "1111111111111111111111111111111111111111111a";

			var validations = Set.of("DocumentoCarga.numero.Pattern",
									 "DocumentoCarga.serie.Pattern",
									 "DocumentoCarga.modelo.Pattern",
									 "DocumentoCarga.chaveAcesso.Pattern");

			var builder = DocumentoCargaTestFactory.umDocumentoCarga()
												   .numero(numero)
												   .serie(serie)
												   .modelo(modelo)
												   .chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(), ONBDocumentoCargaConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

	}

}
