package com.totvs.sl.onboarding.core.cliente.domain.asserts;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;

public class ClienteAlteradoEventAssert extends AbstractAssert<ClienteAlteradoEventAssert, ClienteAlteradoEvent> {

	public ClienteAlteradoEventAssert(ClienteAlteradoEvent actual) {
		super(actual, ClienteAlteradoEventAssert.class);
	}

	public ClienteAlteradoEventAssert hasInformationAccordingTo(Cliente cliente) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(cliente.getId().toString());
		assertThat(actual.getNome()).isEqualTo(cliente.getNome().toString());

		return this;
	}

	public static ClienteAlteradoEventAssert assertThatEvent(ClienteAlteradoEvent actual) {
		return new ClienteAlteradoEventAssert(actual);
	}
}