package com.totvs.sl.onboarding.core.cliente;

import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteDomainRepository;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;

public final class ClienteTestFactory {

	public static Cliente umClienteAtivo() {
		var cliente = Cliente.builder()
							 .id(ClienteId.generate())
							 .nome("EMPRESA X")
							 .documento(DocumentoIdentificacao.from("04946125000160"))
							 .build();
		cliente.removeEvents();
		return cliente;
	}

	public static Cliente umClienteInativo() {
		var cliente = umClienteAtivo();
		cliente.inativar();
		cliente.removeEvents();
		return cliente;
	}

	public static Cliente persistir(ClienteDomainRepository repository, Cliente cliente) {
		return repository.insert(cliente);
	}
}
