package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;

public class DocumentoTransporteDocumentoCargaExcluidoEventAssert extends
		AbstractAssert<DocumentoTransporteDocumentoCargaExcluidoEventAssert, DocumentoTransporteDocumentoCargaExcluidoEvent> {

	public DocumentoTransporteDocumentoCargaExcluidoEventAssert(DocumentoTransporteDocumentoCargaExcluidoEvent actual) {
		super(actual, DocumentoTransporteDocumentoCargaExcluidoEventAssert.class);
	}

	public DocumentoTransporteDocumentoCargaExcluidoEventAssert hasInformationAccordingTo(DocumentoTransporte documentoTransporte,
																						  DocumentoCargaId documentoCargaId) {
		isNotNull();

		assertThat(actual.getDocumentoTransporteId()).isEqualTo(documentoTransporte.getId().toString());
		assertThat(actual.getId()).isEqualTo(documentoCargaId.getId().toString());

		return this;
	}

	public static DocumentoTransporteDocumentoCargaExcluidoEventAssert assertThatEvent(DocumentoTransporteDocumentoCargaExcluidoEvent actual) {
		return new DocumentoTransporteDocumentoCargaExcluidoEventAssert(actual);
	}
}