package com.totvs.sl.onboarding.core.cliente.domain.asserts;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;

public class ClienteAtivadoEventAssert extends AbstractAssert<ClienteAtivadoEventAssert, ClienteAtivadoEvent> {

	public ClienteAtivadoEventAssert(ClienteAtivadoEvent actual) {
		super(actual, ClienteAtivadoEventAssert.class);
	}

	public ClienteAtivadoEventAssert hasInformationAccordingTo(Cliente cliente) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(cliente.getId().toString());
		assertThat(actual.getSituacao()).isEqualTo(cliente.getSituacao().getValor().toString());

		return this;
	}

	public static ClienteAtivadoEventAssert assertThatEvent(ClienteAtivadoEvent actual) {
		return new ClienteAtivadoEventAssert(actual);
	}
}