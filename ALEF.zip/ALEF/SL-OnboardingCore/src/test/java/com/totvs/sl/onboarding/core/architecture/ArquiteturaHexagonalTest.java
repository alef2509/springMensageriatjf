package com.totvs.sl.onboarding.core.architecture;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

import com.tngtech.archunit.base.DescribedPredicate;
import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeJars;
import com.tngtech.archunit.core.importer.ImportOption.DoNotIncludeTests;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchRule;
import com.totvs.tjf.api.context.stereotype.ApiError;
import com.totvs.tjf.api.context.stereotype.error.ApiBadRequest;
import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@AnalyzeClasses(packages = "com.totvs.sl.onboarding.core", importOptions = { DoNotIncludeTests.class,
        DoNotIncludeJars.class })
public class ArquiteturaHexagonalTest {

	@ArchTest
	public static final ArchRule model_nao_deve_depender_da_application = noClasses().that()
	                                                                                 .resideInAPackage("..domain.model..")
	                                                                                 .should()
	                                                                                 .dependOnClassesThat()
	                                                                                 .resideInAPackage("..application..");

	@ArchTest
	public static final ArchRule model_nao_deve_depender_do_repository = noClasses().that()
	                                                                                .resideInAPackage("..model..")
	                                                                                .and(isNotDomainRepository())
	                                                                                .should()
	                                                                                .dependOnClassesThat()
	                                                                                .resideInAPackage("com.totvs.sl.wms..repository..");

	@ArchTest
	public static final ArchRule model_nao_deve_depender_da_ui = noClasses().that()
	                                                                        .resideInAPackage("..model..")
	                                                                        .should()
	                                                                        .dependOnClassesThat()
	                                                                        .resideInAPackage("..api..");

	@ArchTest
	public static final ArchRule application_nao_deve_depender_do_repository = noClasses().that()
	                                                                                      .resideInAPackage("..application..")
	                                                                                      .should()
	                                                                                      .dependOnClassesThat()
	                                                                                      .resideInAPackage("..repository..");

	@ArchTest
	public static final ArchRule application_nao_deve_depender_da_ui = noClasses().that()
	                                                                              .resideInAPackage("..application..")
	                                                                              .should()
	                                                                              .dependOnClassesThat()
	                                                                              .resideInAPackage("..api..");

	@ArchTest
	public static final ArchRule ui_nao_deve_depender_do_repository = noClasses().that()
	                                                                             .resideInAPackage("..api..")
	                                                                             .should()
	                                                                             .dependOnClassesThat()
	                                                                             .resideInAPackage("..repository..");

	private static DescribedPredicate<JavaClass> isNotDomainRepository() {

		return new DescribedPredicate<JavaClass>("is not DomainRepository") {
			@Override
			public boolean apply(JavaClass input) {

				if (input.getSource().isPresent()
				        && input.getSource().get().getUri().toString().contains("DomainRepository")) {
					return false;
				}

				return true;
			}
		};
	}

	@ArchTest
	public static final ArchRule exceptions_devem_ser_anotadas_com_tjf_api_stereotype = classes().that()
	                                                                                             .areAssignableTo(RuntimeException.class)
	                                                                                             .should()
	                                                                                             .beAnnotatedWith(ApiError.class)
	                                                                                             .orShould()
	                                                                                             .beAnnotatedWith(ApiBadRequest.class)
	                                                                                             .orShould()
	                                                                                             .beAnnotatedWith(ApiNotFound.class);

}
