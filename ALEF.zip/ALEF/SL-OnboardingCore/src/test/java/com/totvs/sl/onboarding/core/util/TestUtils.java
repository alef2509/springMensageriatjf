package com.totvs.sl.onboarding.core.util;

import static com.totvs.tjf.mock.test.JWTTestProvider.oauth2JWT;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.request.RequestPostProcessor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.totvs.tjf.core.common.domain.DomainEvent;
import com.totvs.tjf.core.common.security.SecurityPrincipal;

public class TestUtils {

	public static String tenantId = "public";
	public static String userId = "1";
	public static RequestPostProcessor userToken = oauth2JWT(userId);

	private static ObjectMapper mapper = new ObjectMapper();

	static {
		mapper.registerModule(new JavaTimeModule());
	}

	public static String objectToJson(Object value) throws Exception {
		return mapper.writeValueAsString(value);
	}

	public static void setAuthenticationInfo() {

		SecurityPrincipal principal = new SecurityPrincipal(String.valueOf(userId), "", tenantId, tenantId);
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(principal, null);
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}

	public static void assertThatEventsHaveBeenDispatched(List<? extends DomainEvent> dispatchedEvents,
														  Map<Class<? extends DomainEvent>, Integer> expectedEvents) {
		expectedEvents.forEach((clazz, value) -> {
			assertThat(dispatchedEvents.stream()
									   .filter(event -> event.getClass() == clazz)
									   .count()).isEqualTo(value.intValue());
		});
		var sum = expectedEvents.values().stream().mapToLong(Integer::longValue).sum();
		var message = "Nem todos os eventos disparados foram avaliados. Eventos disparados: %s. Eventos avaliados: %s.";
		assertThat(dispatchedEvents.size()).withFailMessage(message, dispatchedEvents.size(), sum).isEqualTo(sum);
	}

	public static void assertThrowableContainsViolations(ConstraintViolationException exception,
														 Set<String> validations) {

		var violations = exception.getConstraintViolations()
								  .stream()
								  .map(ConstraintViolation::getMessageTemplate)
								  .collect(Collectors.toSet());

		assertThat(violations).containsExactlyInAnyOrderElementsOf(validations);
	}

	@SuppressWarnings("unchecked")
	public static <T extends DomainEvent> T getEvent(Collection<DomainEvent> events, Class<T> clazz) {
		if (events.size() != 1) {
			var message = "Lista contém mais de um evento registrado: Eventos registrados: %s.";
			assertThat(events).withFailMessage(message, events.size()).hasSize(1);
		}

		return (T) events.stream().filter(event -> event.getClass() == clazz).findFirst().get();
	}

	public static void assertResponseContainsViolations(MockHttpServletResponse response, Set<String> validations) {
		var violations = new HashSet<String>();
		ObjectMapper mapper = new ObjectMapper();
		try {
			JsonNode root = mapper.readTree(response.getContentAsByteArray());
			if (root.has("details")) {
				root = root.get("details");
				var nodes = root.elements();
				while (nodes.hasNext()) {
					var node = nodes.next();
					if (node.has("code"))
						violations.add(node.get("code").asText());
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		assertThat(validations).containsExactlyInAnyOrderElementsOf(violations);
	}

}
