package com.totvs.sl.onboarding.core.documentotransporte.api;

import com.totvs.sl.onboarding.core.cliente.api.ClienteController;
import com.totvs.sl.onboarding.core.cliente.api.dto.AlterarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.api.dto.CriarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.documentotransporte.api.dto.*;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.util.AdapterConfigIT;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.sl.onboarding.core.util.TestUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Set;

import static com.totvs.sl.onboarding.core.util.TestUtils.objectToJson;
import static com.totvs.sl.onboarding.core.util.TestUtils.userToken;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DisplayName("Documento Transporte - Solicitação REST API.")
public class DocumentoTransporteControllerIT extends AdapterConfigIT {

    @Autowired
    private MockMvc mock;

    private final DocumentoTransporteId id = DocumentoTransporteId.generate();
    private final ZonedDateTime emissao = DateTimeUtils.getNow();
    private final String numero = "2";
    private final String serie = "2";
    private final String modelo = "2";
    private final String chaveAcesso = "12399462417772944246614321172896928750631742";
    private final String remetenteId = "0d4ede58-7ce1-4393-be64-ee8740243f1e";
    private final String cotacaoFreteId = "0d4ede58-7ce1-4393-be64-ee8740243f1e";
    private final String destinatarioId = "0d4ede58-7ce1-4393-be64-ee8740243f1e";
    private final String pagadorFreteId = "0d4ede58-7ce1-4393-be64-ee8740243f1e";

    private final String remetenteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String cotacaoFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String destinatarioIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String pagadorFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";

    @Test
    void deveReceberSolicitacaoEDispararComandoParaCriarDocumentoTransporte() throws Exception {

        // given
        var dto = CriarDocumentoTransporteDTO.of(numero, serie, modelo, chaveAcesso,cotacaoFreteId, remetenteId, destinatarioId, pagadorFreteId );

        var cmdEsperado = CriarDocumentoTransporteCommand.of(dto.getNumero(), DateTimeUtils.getNow(),
                dto.getSerie(),dto.getModelo(),dto.getChaveAcesso(), CotacaoFreteId.from(dto.getCotacaoFreteId()),ClienteId.from(dto.getRemetenteId()),
                ClienteId.from(dto.getDestinatarioId()),ClienteId.from(dto.getPagadorFreteId()));



        assertThat(dto.getChaveAcesso()).isEqualTo(cmdEsperado.getChaveAcesso());
    }


    @Nested
    @DisplayName("Teste de falha de criação de documento de transporte")
    class CaminhoInfelizCriacaoDocumentoTransporte {

        @Test
        void naoDeveReceberCriarDocumentoTransporteSemCamposObrigatorios() throws Exception {

            // given
            var dto = CriarDocumentoTransporteDTO.of(null, null, modelo, chaveAcesso,cotacaoFreteId, remetenteId, destinatarioId, pagadorFreteId );

            var violations = Set.of("CriarDocumentoTransporteDTO.numero.NotBlank", "CriarDocumentoTransporteDTO.serie.NotBlank");

            // when
            var result = mock.perform(request(HttpMethod.POST,
                            DocumentoTransporteController.PATH).with(userToken)
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectToJson(dto)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.details.length()", is(2)))
                    .andReturn();

            // then
            TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
        }

        @Test
        void naoDeveReceberCriarDocumentoTransporteComInformacoesDeTamanhoInvalido() throws Exception {

            // given
            var dto = CriarDocumentoTransporteDTO.of("1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111",
                                                                             serie, "nomeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", chaveAcesso,cotacaoFreteId, remetenteId, destinatarioId, pagadorFreteId );
            var violations = Set.of("CriarDocumentoTransporteDTO.modelo.Size", "CriarDocumentoTransporteDTO.numero.Size");

            // when
            var result = mock.perform(request(HttpMethod.POST,
                            DocumentoTransporteController.PATH).with(userToken)
                            .contentType(MediaType.APPLICATION_JSON_VALUE)
                            .content(objectToJson(dto)))
                    .andExpect(status().isBadRequest())
                    .andExpect(jsonPath("$.details.length()", is(2)))
                    .andReturn();

            // then
            TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
        }
    }


    @Test
    void deveReceberSolicitacaoEDispararComandoParaAnularDocumentoTransporte() throws Exception {

        var dto = AnularDocumentoTransporteDTO.of(remetenteId);
        // given
        var cmdEsperado = AnularDocumentoTransporteCommand.of(id, remetenteId);

        // when

        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/anular").with(userToken)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectToJson(dto)))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaCancelarDocumentoTransporte() throws Exception {

        var dto = CancelarDocumentoTransporteDTO.of(remetenteId);
        // given
        var cmdEsperado = CancelarDocumentoTransporteCommand.of(id, remetenteId);

        // when
        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/cancelar").with(userToken)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectToJson(dto)))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAutorizarDocumentoTransporte() throws Exception {

        var dto = AutorizarDocumentoTransporteDTO.of(remetenteId, chaveAcesso);
        var cmdEsperado = AutorizarDocumentoTransporteCommand.of(id, remetenteId, chaveAcesso);


        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/autorizar").with(userToken)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectToJson(dto)))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAlterarDocumentoTransporte() throws Exception {

        var dto = AlterarDocumentoTransporteDTO.of(cotacaoFreteId, remetenteIdNew, destinatarioIdNew, pagadorFreteId);
        // given
        var cmdEsperado = AlterarDocumentoTransporteCommand.of(id, CotacaoFreteId.from(dto.getCotacaoFreteId()), ClienteId.from(dto.getRemetenteId()), ClienteId.from(dto.getDestinatarioId()), ClienteId.from(dto.getPagadorFreteId()));

        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/alterar").with(userToken)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectToJson(dto)))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }

    @Test
    void deveReceberSolicitacaoEDispararComandoParaAdicionarCargaDocumentoTransporte() throws Exception {

        var dto = AdicionarDocumentoCargaDTO.of(LocalDate.now(), numero, serie, modelo, chaveAcesso);
        // given
        var cmdEsperado = AdicionarDocumentoCargaCommand.of( id,
                dto.getEmissao(), dto.getNumero(),
                dto.getSerie(), dto.getModelo(),
                dto.getChaveAcesso());

        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/adicionarDocumentoCarga").with(userToken)
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(objectToJson(dto)))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }


    @Test
    void deveReceberSolicitacaoEDispararComandoParaExcluirCargaDocumentoTransporte() throws Exception {

        
        var cmdEsperado = ExcluirDocumentoCargaCommand.of( id,
                DocumentoCargaId.generate());

        mock.perform(request(HttpMethod.POST,
                        DocumentoTransporteController.PATH + "/" + id.toString() + "/documentoCarga" + "/" + cmdEsperado.getIdCarga().toString() +"/excluir").with(userToken))
                .andExpect(status().is2xxSuccessful());

        // then
        verify(mockDocumentoTransporteAppService).handle(cmdEsperado);
    }

    }
