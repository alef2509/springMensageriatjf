package com.totvs.sl.onboarding.core.documentotransporte.application;

import com.totvs.sl.onboarding.core.cliente.ClienteTestFactory;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteNaoEncontradoException;
import com.totvs.sl.onboarding.core.cliente.exception.ONBJaExisteClienteComMesmoDocumentoExcepition;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.DocumentoCargaTestFactory;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.documentotransporte.DocumentoTransporteTestFactory;
import com.totvs.sl.onboarding.core.documentotransporte.application.command.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.*;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporteId;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.sl.onboarding.core.documentotransporte.exception.ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition;
import com.totvs.sl.onboarding.core.util.ApplicationConfigIT;
import com.totvs.sl.onboarding.core.util.DateTimeUtils;
import com.totvs.tjf.core.common.domain.DomainEvent;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.orm.jpa.JpaSystemException;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.Map;

import static com.totvs.sl.onboarding.core.util.TestUtils.assertThatEventsHaveBeenDispatched;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowable;
import static org.assertj.core.api.InstanceOfAssertFactories.OPTIONAL;
import static org.mockito.Mockito.verify;

@DisplayName("DocumentoTransporteApplicationService - Teste de processamento dos comandos de aplicação")
public class DocumentoTransporteApplicationServiceIT extends ApplicationConfigIT {

    private final String idoriginal = "11666b8e-51b0-4058-80a4-f1875b9447e5";

    private final ZonedDateTime emissao = DateTimeUtils.getNow();
    private final String numero = "1";
    private final String serie = "1";
    private final String modelo = "1";
    private final String chaveAcesso = "30399462417772944246614321172896928750631741";
    private final String remetenteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String cotacaoFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String destinatarioId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String pagadorFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";

    private final String remetenteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String cotacaoFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String destinatarioIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";
    private final String pagadorFreteIdNew = "11666b8e-51b0-4058-80a4-f1875b9447e6";

    @Test
    void deveCriarDocumentoTransportePublicandoEvento() {

        // given
        var cmd = CriarDocumentoTransporteCommand.of(numero, emissao ,
                serie,modelo,chaveAcesso, CotacaoFreteId.from(cotacaoFreteId), ClienteId.from(remetenteId),
                ClienteId.from(destinatarioId),ClienteId.from(pagadorFreteId));

        // when
        var id = documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporte = documentoTransporteRepository.findByIdOrThrowNotFound(id);

        assertThat(documentoTransporte.getId()).isEqualTo(id);
        assertThat(documentoTransporte.getNumero()).isEqualTo(cmd.getNumero());
        assertThat(documentoTransporte.getEmissao()).isEqualTo(cmd.getEmissao());
        assertThat(documentoTransporte.getSerie()).isEqualTo(cmd.getSerie());
        assertThat(documentoTransporte.getModelo()).isEqualTo(cmd.getModelo());
        assertThat(documentoTransporte.getChaveAcesso()).isEqualTo(cmd.getChaveAcesso());


        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThatEventsHaveBeenDispatched(eventArgument.getAllValues(), Map.of(DocumentoTransporteCriadoEvent.class, 1));

    }

    @Test
    void deveAlterarDocumentoTransporteEmitindoEvento() {
        var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);
        // given
        var cmd = AlterarDocumentoTransporteCommand.of( documentoTransporte.getId(),CotacaoFreteId.from(cotacaoFreteIdNew),ClienteId.from(remetenteIdNew),
                ClienteId.from(destinatarioIdNew),ClienteId.from(pagadorFreteIdNew));

        // when
        documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporteAlterado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId());
        assertThat(documentoTransporteAlterado.getId()).isEqualTo(documentoTransporte.getId());


        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThat(eventArgument.getValue()).isInstanceOf(DocumentoTransporteAlteradoEvent.class);
    }

    @Test
    void deveAnularDocumentoTransporteEmitindoEvento() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);
        var cmd = AnularDocumentoTransporteCommand.of(documentoTransporte.getId(), destinatarioIdNew);

        // when
        documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId());
        assertThat(documentoTransporteAtualizado.getSituacao().isAnulado()).isTrue();

        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThat(eventArgument.getValue()).isInstanceOf(DocumentoTransporteAnuladoEvent.class);
    }

    @Test
    void deveCancelarDocumentoTransporteEmitindoEvento() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);
        var cmd = CancelarDocumentoTransporteCommand.of(documentoTransporte.getId(), destinatarioIdNew);

        // when
        documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId());
        assertThat(documentoTransporteAtualizado.getSituacao().isCancelado()).isTrue();

        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThat(eventArgument.getValue()).isInstanceOf(DocumentoTransporteCanceladoEvent.class);
    }

    @Test
    void deveAutorizarDocumentoTransporteEmitindoEvento() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);

        var cmd = AutorizarDocumentoTransporteCommand.of(documentoTransporte.getId(), destinatarioIdNew, documentoTransporte.getChaveAcesso());

        // when
        documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId());
        assertThat(documentoTransporteAtualizado.getSituacao().isAutorizado()).isTrue();

        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThat(eventArgument.getValue()).isInstanceOf(DocumentoTransporteAutorizadoEvent.class);
    }

    @Test
    void deveAdicionarDocumentoCargaDocumentoTransporteEmitindoEvento() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);

        var cmd = AdicionarDocumentoCargaCommand.of(documentoTransporte.getId(),
                LocalDate.now(), documentoTransporte.getNumero(), documentoTransporte.getSerie(),
                documentoTransporte.getModelo(), documentoTransporte.getChaveAcesso());

        // when
        documentoTransporteAppService.handle(cmd);

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId());
        assertThat(documentoTransporteAtualizado.getDocumentosCarga().isEmpty()).isFalse();

        var eventArgument = ArgumentCaptor.forClass(DomainEvent.class);
        verify(publisher).dispatch(eventArgument.capture());
        assertThat(eventArgument.getValue()).isInstanceOf(DocumentoTransporteDocumentoCargaAdicionadoEvent.class);
    }


    @Test
    void naoDeveCriarDocumentoTransporteComMesmaChaveAcesso() {

        // given
        var documentoTransporteAtivo = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporteDigitado());

        var cmd = CriarDocumentoTransporteCommand.of(numero, emissao ,
                serie,modelo,documentoTransporteAtivo.getChaveAcesso(), CotacaoFreteId.from(cotacaoFreteId), ClienteId.from(remetenteId),
                ClienteId.from(destinatarioId),ClienteId.from(pagadorFreteId));

        // when
        var thrown = catchThrowable(() -> documentoTransporteAppService.handle(cmd));

        // then
        assertThat(thrown).isInstanceOf(ONBJaExisteDocumentoTransporteComMesmaChaveAcessoExcepition.class);
    }

    @Test
    void naoDeveAlterarDocumentoTransportecomIdNaoExistente() {

        var cmd = AlterarDocumentoTransporteCommand.of( DocumentoTransporteId.generate(),CotacaoFreteId.from(cotacaoFreteIdNew),ClienteId.from(remetenteIdNew),
                ClienteId.from(destinatarioIdNew),ClienteId.from(pagadorFreteIdNew));
        // when
        var thrown = catchThrowable(() -> documentoTransporteAppService.handle(cmd));

        // then
        assertThat(thrown).isInstanceOf(ONBDocumentoTransporteNaoEncontradoException.class);
    }
}
