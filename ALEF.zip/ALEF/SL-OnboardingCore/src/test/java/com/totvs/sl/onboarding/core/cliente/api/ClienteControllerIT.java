package com.totvs.sl.onboarding.core.cliente.api;

import static com.totvs.sl.onboarding.core.util.TestUtils.objectToJson;
import static com.totvs.sl.onboarding.core.util.TestUtils.userToken;
import static org.hamcrest.CoreMatchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.request;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Set;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.totvs.sl.onboarding.core.cliente.api.dto.AlterarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.api.dto.CriarClienteDTO;
import com.totvs.sl.onboarding.core.cliente.application.command.AlterarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.AtivarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.CriarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.application.command.InativarClienteCommand;
import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.util.AdapterConfigIT;
import com.totvs.sl.onboarding.core.util.TestUtils;

@DisplayName("Cliente - Solicitação REST API.")
class ClienteControllerIT extends AdapterConfigIT {

	@Autowired
	private MockMvc mock;

	private final ClienteId id = ClienteId.generate();
	private final String nome = "NOME CLIENTE";
	private final String cpf = "90817824014";
	private final String cnpj = "10999961000105";

	@Test
	void deveReceberSolicitacaoEDispararComandoParaCriarClientePessoaFisica() throws Exception {

		// given
		var dto = CriarClienteDTO.of(nome, cpf);

		var cmdEsperado = CriarClienteCommand.of(dto.getNome(), DocumentoIdentificacao.from(dto.getDocumento()));

		when(mockClienteAppService.handle(cmdEsperado)).thenReturn(ClienteId.generate());

		// when
		mock.perform(request(HttpMethod.POST, ClienteController.PATH).with(userToken)
																	 .contentType(MediaType.APPLICATION_JSON_VALUE)
																	 .content(objectToJson(dto)))
			.andExpect(status().is2xxSuccessful());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaCriarClientePessoaJuridica() throws Exception {

		// given
		var dto = CriarClienteDTO.of(nome, cnpj);

		var cmdEsperado = CriarClienteCommand.of(dto.getNome(), DocumentoIdentificacao.from(dto.getDocumento()));

		when(mockClienteAppService.handle(cmdEsperado)).thenReturn(ClienteId.generate());

		// when
		mock.perform(request(HttpMethod.POST, ClienteController.PATH).with(userToken)
																	 .contentType(MediaType.APPLICATION_JSON_VALUE)
																	 .content(objectToJson(dto)))
			.andExpect(status().is2xxSuccessful());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}

	@Nested
	@DisplayName("Teste de falha de criação de cliente")
	class CaminhoInfelizCriacaoCliente {

		@Test
		void naoDeveReceberCriarClienteSemCamposObrigatorios() throws Exception {

			// given
			var dto = new CriarClienteDTO();

			var violations = Set.of("CriarClienteDTO.nome.NotBlank", "CriarClienteDTO.documento.NotBlank");

			// when
			var result = mock.perform(request(HttpMethod.POST,
											  ClienteController.PATH).with(userToken)
																	 .contentType(MediaType.APPLICATION_JSON_VALUE)
																	 .content(objectToJson(dto)))
							 .andExpect(status().isBadRequest())
							 .andExpect(jsonPath("$.details.length()", is(2)))
							 .andReturn();

			// then
			TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
		}

		@Test
		void naoDeveReceberCriarClienteComInformacoesDeTamanhoInvalido() throws Exception {

			// given
			var dto = CriarClienteDTO.of("nomeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee", "1");

			var violations = Set.of("CriarClienteDTO.nome.Size", "CriarClienteDTO.documento.Size");

			// when
			var result = mock.perform(request(HttpMethod.POST,
											  ClienteController.PATH).with(userToken)
																	 .contentType(MediaType.APPLICATION_JSON_VALUE)
																	 .content(objectToJson(dto)))
							 .andExpect(status().isBadRequest())
							 .andExpect(jsonPath("$.details.length()", is(2)))
							 .andReturn();

			// then
			TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
		}
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaAlterarCliente() throws Exception {

		// given
		var dto = AlterarClienteDTO.of(nome);

		var cmdEsperado = AlterarClienteCommand.of(id, dto.getNome());

		// when
		mock.perform(request(HttpMethod.POST,
							 ClienteController.PATH + "/" + id + "/alterar").with(userToken)
																			.contentType(MediaType.APPLICATION_JSON_VALUE)
																			.content(objectToJson(dto)))
			.andExpect(status().is2xxSuccessful());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaInativarCliente() throws Exception {

		// given
		var cmdEsperado = InativarClienteCommand.of(id);

		// when
		mock.perform(request(HttpMethod.POST,
							 ClienteController.PATH + "/" + id.toString() + "/inativar").with(userToken)
																						.contentType(MediaType.APPLICATION_JSON_VALUE))
			.andExpect(status().is2xxSuccessful());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}

	@Test
	void deveReceberSolicitacaoEDispararComandoParaAtivarCliente() throws Exception {

		// give
		var cmdEsperado = AtivarClienteCommand.of(id);

		// when
		mock.perform(request(HttpMethod.POST,
							 ClienteController.PATH + "/" + id.toString() + "/ativar").with(userToken)
																					  .contentType(MediaType.APPLICATION_JSON_VALUE))
			.andExpect(status().is2xxSuccessful());

		// then
		verify(mockClienteAppService).handle(cmdEsperado);
	}

	@Nested
	@DisplayName("Teste de falha de alteração de cliente")
	class CaminhoInfelizAlteracaoCliente {

		@Test
		void naoDeveReceberAlterarClienteSemCamposObrigatorios() throws Exception {

			// given
			var dto = new AlterarClienteDTO();

			var violations = Set.of("AlterarClienteDTO.nome.NotBlank");

			// when
			var result = mock.perform(request(HttpMethod.POST,
											  ClienteController.PATH + "/" + id.toString() + "/alterar").with(userToken)
																										.contentType(MediaType.APPLICATION_JSON_VALUE)
																										.content(objectToJson(dto)))
							 .andExpect(status().isBadRequest())
							 .andExpect(jsonPath("$.details.length()", is(1)))
							 .andReturn();

			// then
			TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
		}

		@Test
		void naoDeveReceberAlterarClienteComInformacoesDeTamanhoInvalido() throws Exception {

			// given
			var dto = AlterarClienteDTO.of("nomeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee");

			var violations = Set.of("AlterarClienteDTO.nome.Size");

			// when
			var result = mock.perform(request(HttpMethod.POST,
											  ClienteController.PATH + "/" + id.toString() + "/alterar").with(userToken)
																										.contentType(MediaType.APPLICATION_JSON_VALUE)
																										.content(objectToJson(dto)))
							 .andExpect(status().isBadRequest())
							 .andExpect(jsonPath("$.details.length()", is(1)))
							 .andReturn();

			// then
			TestUtils.assertResponseContainsViolations(result.getResponse(), violations);
		}

	}
}