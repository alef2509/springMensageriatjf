package com.totvs.sl.onboarding.core.util;

import com.totvs.sl.onboarding.core.documentotransporte.application.DocumentoTransporteApplicationService;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import com.totvs.sl.onboarding.core.cliente.application.ClienteApplicationService;

@SpringBootTest
@ActiveProfiles(profiles = "test")
@AutoConfigureMockMvc
public abstract class AdapterConfigIT {

	@MockBean
	protected ClienteApplicationService mockClienteAppService;
	@MockBean
	protected DocumentoTransporteApplicationService mockDocumentoTransporteAppService;

}
