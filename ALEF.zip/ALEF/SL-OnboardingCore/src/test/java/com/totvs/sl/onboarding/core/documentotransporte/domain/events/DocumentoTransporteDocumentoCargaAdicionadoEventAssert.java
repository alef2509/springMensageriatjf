package com.totvs.sl.onboarding.core.documentotransporte.domain.events;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCarga;
import com.totvs.sl.onboarding.core.documentotransporte.domain.model.DocumentoTransporte;

public class DocumentoTransporteDocumentoCargaAdicionadoEventAssert extends
		AbstractAssert<DocumentoTransporteDocumentoCargaAdicionadoEventAssert, DocumentoTransporteDocumentoCargaAdicionadoEvent> {

	public DocumentoTransporteDocumentoCargaAdicionadoEventAssert(DocumentoTransporteDocumentoCargaAdicionadoEvent actual) {
		super(actual, DocumentoTransporteDocumentoCargaAdicionadoEventAssert.class);
	}

	public DocumentoTransporteDocumentoCargaAdicionadoEventAssert hasInformationAccordingTo(DocumentoTransporte documentoTransporte,
																							DocumentoCarga documentoCarga) {
		isNotNull();

		//assertThat(actual.getDocumentoTransporte().getId()).isEqualTo(documentoTransporte.getId().toString());
		assertThat(actual.getId()).isEqualTo(documentoCarga.getId().toString());
		assertThat(actual.getNumero()).isEqualTo(documentoCarga.getNumero());
		assertThat(actual.getSerie()).isEqualTo(documentoCarga.getSerie());
		assertThat(actual.getEmissao()).isEqualTo(documentoCarga.getEmissao());
		assertThat(actual.getModelo()).isEqualTo(documentoCarga.getModelo());
		assertThat(actual.getChaveAcesso()).isEqualTo(documentoCarga.getChaveAcesso());

		return this;
	}

	public static DocumentoTransporteDocumentoCargaAdicionadoEventAssert assertThatEvent(DocumentoTransporteDocumentoCargaAdicionadoEvent actual) {
		return new DocumentoTransporteDocumentoCargaAdicionadoEventAssert(actual);
	}
}