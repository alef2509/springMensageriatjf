package com.totvs.sl.onboarding.core.documentotransporte.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.sl.onboarding.core.util.TestUtils.getEvent;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.net.ContentHandler;
import java.time.ZonedDateTime;
import java.util.Set;
import java.util.concurrent.locks.StampedLock;

import com.totvs.sl.onboarding.core.documentotransporte.amqp.cmd.AdicionarDocumentoCargaCmd;
import com.totvs.sl.onboarding.core.documentotransporte.exception.*;
import com.totvs.tjf.core.message.TOTVSMessage;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import com.totvs.sl.onboarding.core.cliente.domain.model.ClienteId;
import com.totvs.sl.onboarding.core.cotacaofrete.domain.model.CotacaoFreteId;
import com.totvs.sl.onboarding.core.documentocarga.DocumentoCargaTestFactory;
import com.totvs.sl.onboarding.core.documentocarga.domain.model.DocumentoCargaId;
import com.totvs.sl.onboarding.core.documentotransporte.DocumentoTransporteTestFactory;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAlteradoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAnuladoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAutorizadoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCanceladoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCriadoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaAdicionadoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaExcluidoEventAssert;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAlteradoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAnuladoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteAutorizadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCanceladoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteCriadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaAdicionadoEvent;
import com.totvs.sl.onboarding.core.documentotransporte.domain.events.DocumentoTransporteDocumentoCargaExcluidoEvent;
import com.totvs.sl.onboarding.core.util.TestUtils;
import com.totvs.tjf.core.validation.ValidatorService;

import javax.validation.ConstraintViolation;

@DisplayName("DocumentoTransporteTest - Teste da classe DocumentoTransporte")
class DocumentoTransporteTest {

	private final DocumentoTransporteId id = DocumentoTransporteId.generate();
	private final String numero = "01";
	private final String serie = "02";
	private final ZonedDateTime emissao = ZonedDateTime.now();
	private final String modelo = "03";
	private final String chaveAcesso = "30399462417772944246614321172896928750631741";
	private final String usuarioId = "usuarioId@totvs.com.br";

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	@Test
	void deveConstruirDocumentoTransporteComCamposObrigatorios() {


		var documentoTransporte = DocumentoTransporte.builder()
													 .id(id)
													 .numero(numero)
													 .serie(serie)
													 .emissao(emissao)
													 .modelo(modelo)
													 .build();


		assertThat(documentoTransporte.getId()).isEqualTo(id);
		assertThat(documentoTransporte.getNumero()).isEqualTo(numero);
		assertThat(documentoTransporte.getSerie()).isEqualTo(serie);
		assertThat(documentoTransporte.getEmissao()).isEqualTo(emissao);
		assertThat(documentoTransporte.getModelo()).isEqualTo(modelo);
		assertThat(documentoTransporte.getChaveAcesso()).isNull();

		assertTrue(documentoTransporte.getSituacao().isDigitado());
		assertThat(documentoTransporte.getHistoricoSituacao()).hasSize(1);
		assertThat(documentoTransporte.getDocumentosCarga()).isEmpty();

		assertThat(documentoTransporte.getCotacaoFreteId()).isEmpty();
		assertThat(documentoTransporte.getRemetenteId()).isEmpty();
		assertThat(documentoTransporte.getDestinatarioId()).isEmpty();
		assertThat(documentoTransporte.getPagadorFreteId()).isEmpty();

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteCriadoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteCriadoEvent.class);
		DocumentoTransporteCriadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(documentoTransporte);

	}

	@Test
	void deveCriarDocumentoTransporteComTodosCampos() {


		var cotacaoFreteId = CotacaoFreteId.generate();
		var remetenteId = ClienteId.generate();
		var destinatarioId = ClienteId.generate();
		var pagadorFreteId = ClienteId.generate();


		var documentoTransporte = DocumentoTransporte.builder()
													 .id(id)
													 .numero(numero)
													 .serie(serie)
													 .emissao(emissao)
													 .modelo(modelo)
													 .chaveAcesso(chaveAcesso)
													 .cotacaoFreteId(cotacaoFreteId)
													 .remetenteId(remetenteId)
													 .destinatarioId(destinatarioId)
													 .pagadorFreteId(pagadorFreteId)
													 .build();


		assertThat(documentoTransporte.getId()).isEqualTo(id);
		assertThat(documentoTransporte.getNumero()).isEqualTo(numero);
		assertThat(documentoTransporte.getSerie()).isEqualTo(serie);
		assertThat(documentoTransporte.getEmissao()).isEqualTo(emissao);
		assertThat(documentoTransporte.getModelo()).isEqualTo(modelo);
		assertThat(documentoTransporte.getChaveAcesso()).isEqualTo(chaveAcesso);

		assertTrue(documentoTransporte.getSituacao().isDigitado());
		assertThat(documentoTransporte.getHistoricoSituacao()).hasSize(1);
		assertThat(documentoTransporte.getDocumentosCarga()).isEmpty();

		assertThat(documentoTransporte.getCotacaoFreteId().orElseThrow()).isEqualTo(cotacaoFreteId);
		assertThat(documentoTransporte.getRemetenteId().orElseThrow()).isEqualTo(remetenteId);
		assertThat(documentoTransporte.getDestinatarioId().orElseThrow()).isEqualTo(destinatarioId);
		assertThat(documentoTransporte.getPagadorFreteId().orElseThrow()).isEqualTo(pagadorFreteId);

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteCriadoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteCriadoEvent.class);
		DocumentoTransporteCriadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(documentoTransporte);

	}

	@Test
	void deveAlterarDocumentoTransporteDigitado() {


		var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
		var cotacaoFreteId = CotacaoFreteId.generate();
		var remetenteId = ClienteId.generate();
		var destinatarioId = ClienteId.generate();
		var pagadorFreteId = ClienteId.generate();


		documentoTransporte.alterar(cotacaoFreteId, remetenteId, destinatarioId, pagadorFreteId);


		assertThat(documentoTransporte.getCotacaoFreteId().orElseThrow()).isEqualTo(cotacaoFreteId);
		assertThat(documentoTransporte.getRemetenteId().orElseThrow()).isEqualTo(remetenteId);
		assertThat(documentoTransporte.getDestinatarioId().orElseThrow()).isEqualTo(destinatarioId);
		assertThat(documentoTransporte.getPagadorFreteId().orElseThrow()).isEqualTo(pagadorFreteId);

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteAlteradoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteAlteradoEvent.class);
		DocumentoTransporteAlteradoEventAssert.assertThatEvent(event).hasInformationAccordingTo(documentoTransporte);

	}

	@Test
	void deveAlterarDocumentoTransporteDigitadoComValoresNulos() {


		var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();


		documentoTransporte.alterar(null, null, null, null);


		assertThat(documentoTransporte.getCotacaoFreteId()).isEmpty();
		assertThat(documentoTransporte.getRemetenteId()).isEmpty();
		assertThat(documentoTransporte.getDestinatarioId()).isEmpty();
		assertThat(documentoTransporte.getPagadorFreteId()).isEmpty();

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteAlteradoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteAlteradoEvent.class);
		DocumentoTransporteAlteradoEventAssert.assertThatEvent(event).hasInformationAccordingTo(documentoTransporte);

	}

	@Test
	void deveAnularDocumentoTransporteDigitado() {

		// given
		var documentoTransporteDigitado = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();

		// when
		documentoTransporteDigitado.anular(usuarioId);

		// then
		assertTrue(documentoTransporteDigitado.getSituacao().isAnulado());
		assertThat(documentoTransporteDigitado.getSituacao().getUsuarioId()).isEqualTo(usuarioId);

		assertThat(documentoTransporteDigitado.getEvents()).hasSize(1);
		assertThat(documentoTransporteDigitado.getEvents()).hasOnlyElementsOfType(DocumentoTransporteAnuladoEvent.class);

		var event = getEvent(documentoTransporteDigitado.getEvents(), DocumentoTransporteAnuladoEvent.class);
		DocumentoTransporteAnuladoEventAssert.assertThatEvent(event)
											 .hasInformationAccordingTo(documentoTransporteDigitado);

	}

	@Test
	void deveAnularDocumentoTransporteAutorizado() {

		// given
		var documentoTransporteAutorizado = DocumentoTransporteTestFactory.umDocumentoTransporteAutorizado(usuarioId,
																										   chaveAcesso);

		// when
		documentoTransporteAutorizado.anular(usuarioId);

		// then
		assertTrue(documentoTransporteAutorizado.getSituacao().isAnulado());
		assertThat(documentoTransporteAutorizado.getSituacao().getUsuarioId()).isEqualTo(usuarioId);

		assertThat(documentoTransporteAutorizado.getEvents()).hasSize(1);
		assertThat(documentoTransporteAutorizado.getEvents()).hasOnlyElementsOfType(DocumentoTransporteAnuladoEvent.class);

		var event = getEvent(documentoTransporteAutorizado.getEvents(), DocumentoTransporteAnuladoEvent.class);
		DocumentoTransporteAnuladoEventAssert.assertThatEvent(event)
											 .hasInformationAccordingTo(documentoTransporteAutorizado);

	}

	@Test
	void deveAutorizarDocumentoTransporteDigitado() {

		// given
		var documentoTransporteDigitado = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();

		// when
		documentoTransporteDigitado.autorizar(usuarioId, chaveAcesso);

		// then
		assertTrue(documentoTransporteDigitado.getSituacao().isAutorizado());
		assertThat(documentoTransporteDigitado.getSituacao().getUsuarioId()).isEqualTo(usuarioId);

		assertThat(documentoTransporteDigitado.getEvents()).hasSize(1);
		assertThat(documentoTransporteDigitado.getEvents()).hasOnlyElementsOfType(DocumentoTransporteAutorizadoEvent.class);

		var event = getEvent(documentoTransporteDigitado.getEvents(), DocumentoTransporteAutorizadoEvent.class);
		DocumentoTransporteAutorizadoEventAssert.assertThatEvent(event)
												.hasInformationAccordingTo(documentoTransporteDigitado);

	}

	@Test
	void deveCancelarDocumentoTransporteDigitado() {

		// given
		var documentoTransporteDigitado = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();

		// when
		documentoTransporteDigitado.cancelar(usuarioId);

		// then
		assertTrue(documentoTransporteDigitado.getSituacao().isCancelado());
		assertThat(documentoTransporteDigitado.getSituacao().getUsuarioId()).isEqualTo(usuarioId);

		assertThat(documentoTransporteDigitado.getEvents()).hasSize(1);
		assertThat(documentoTransporteDigitado.getEvents()).hasOnlyElementsOfType(DocumentoTransporteCanceladoEvent.class);

		var event = getEvent(documentoTransporteDigitado.getEvents(), DocumentoTransporteCanceladoEvent.class);
		DocumentoTransporteCanceladoEventAssert.assertThatEvent(event)
											   .hasInformationAccordingTo(documentoTransporteDigitado);

	}

	@Test
	void deveCancelarDocumentoTransporteAutorizado() {

		// given
		var documentoTransporteAutorizado = DocumentoTransporteTestFactory.umDocumentoTransporteAutorizado(usuarioId,
																										   chaveAcesso);

		// when
		documentoTransporteAutorizado.cancelar(usuarioId);

		// then
		assertTrue(documentoTransporteAutorizado.getSituacao().isCancelado());
		assertThat(documentoTransporteAutorizado.getSituacao().getUsuarioId()).isEqualTo(usuarioId);

		assertThat(documentoTransporteAutorizado.getEvents()).hasSize(1);
		assertThat(documentoTransporteAutorizado.getEvents()).hasOnlyElementsOfType(DocumentoTransporteCanceladoEvent.class);

		var event = getEvent(documentoTransporteAutorizado.getEvents(), DocumentoTransporteCanceladoEvent.class);
		DocumentoTransporteCanceladoEventAssert.assertThatEvent(event)
											   .hasInformationAccordingTo(documentoTransporteAutorizado);

	}

	@Test
	void deveAdicionarDocumentoCargaAoDocumentoTransporte() {

		// given
		var documentoCarga = DocumentoCargaTestFactory.umDocumentoCarga().build();

		// when
		var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitado();
		documentoTransporte.adicionarDocumentoCarga(documentoCarga);

		// then
		var documentoCargaAdicionado = documentoTransporte.getDocumentosCarga().get(0);

		assertThat(documentoCargaAdicionado.getChaveAcesso()).isEqualTo(documentoCarga.getChaveAcesso());
		assertThat(documentoCargaAdicionado.getEmissao()).isEqualTo(documentoCarga.getEmissao());
		assertThat(documentoCargaAdicionado.getId()).isEqualTo(documentoCarga.getId());
		assertThat(documentoCargaAdicionado.getModelo()).isEqualTo(documentoCarga.getModelo());
		assertThat(documentoCargaAdicionado.getNumero()).isEqualTo(documentoCarga.getNumero());
		assertThat(documentoCargaAdicionado.getSerie()).isEqualTo(documentoCarga.getSerie());

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteDocumentoCargaAdicionadoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteDocumentoCargaAdicionadoEvent.class);
		DocumentoTransporteDocumentoCargaAdicionadoEventAssert.assertThatEvent(event)
															  .hasInformationAccordingTo(documentoTransporte,
																						 documentoCarga);

	}

	@Test
	void deveExcluirDocumentoCargaDoDocumentoTransporte() {

		// given
		var documentoCarga = DocumentoCargaTestFactory.umDocumentoCarga().build();

		// when
		var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitadoComDocumentoCarga(documentoCarga);
		documentoTransporte.excluirDocumentoCarga(documentoCarga.getId());

		// then
		assertThat(documentoTransporte.getDocumentosCarga()).isEmpty();

		assertThat(documentoTransporte.getEvents()).hasSize(1);
		assertThat(documentoTransporte.getEvents()).hasOnlyElementsOfType(DocumentoTransporteDocumentoCargaExcluidoEvent.class);

		var event = getEvent(documentoTransporte.getEvents(), DocumentoTransporteDocumentoCargaExcluidoEvent.class);
		DocumentoTransporteDocumentoCargaExcluidoEventAssert.assertThatEvent(event)
															.hasInformationAccordingTo(documentoTransporte,
																					   documentoCarga.getId());

	}

	@Nested
	@DisplayName("Testes de falha")
	class CaminhoInfeliz {

		@Test
		void naoDeveCriarDocumentoTransporteSemId() {

			// when
			Executable action = () -> DocumentoTransporte.builder().build();

			// then
			assertThrows(NullPointerException.class, action);

		}

		@Test
		void naoDeveConstruirDocumentoTransporteSemCamposObrigatorios() {

			// given
			var validations = Set.of("DocumentoTransporte.numero.NotBlank",
									 "DocumentoTransporte.serie.NotBlank",
									 "DocumentoTransporte.emissao.NotNull",
									 "DocumentoTransporte.modelo.NotBlank");

			var builder = DocumentoTransporte.builder().id(DocumentoTransporteId.generate());

			// when
			var exception = catchThrowableOfType(() -> builder.build(),
												 ONBDocumentoTransporteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoTransporteComAtributosComTamanhosMaioresQueEsperado() {

			// given
			var numero = "1234567890";
			var serie = "1234";
			var modelo = "123";
			var chaveAcesso = "303994624177729442466143211728969287506317411";

			var validations = Set.of("DocumentoTransporte.numero.Size",
									 "DocumentoTransporte.serie.Size",
									 "DocumentoTransporte.modelo.Size",
									 "DocumentoTransporte.chaveAcesso.Size");

			var builder = DocumentoTransporteTestFactory.geradodeDocumentoTransporte()
														.numero(numero)
														.serie(serie)
														.modelo(modelo)
														.chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(),
												 ONBDocumentoTransporteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoTransporteComAtributosComTamanhosMenoresQueEsperado() {

			// given
			var chaveAcesso = "3039946241777294424661432117289692875063174";

			var validations = Set.of("DocumentoTransporte.chaveAcesso.Size");

			var builder = DocumentoTransporteTestFactory.geradodeDocumentoTransporte().chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(),
												 ONBDocumentoTransporteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveConstruirDocumentoTransporteQuandoAtributosPossuiremCaracteresDiferentesDeNumeros() {

			// given
			var numero = "1234a7890";
			var serie = "1a4";
			var modelo = "a3";
			var chaveAcesso = "3039946241777294424661432117289692875063174a";

			var validations = Set.of("DocumentoTransporte.numero.Pattern",
									 "DocumentoTransporte.serie.Pattern",
									 "DocumentoTransporte.modelo.Pattern",
									 "DocumentoTransporte.chaveAcesso.Pattern");

			var builder = DocumentoTransporteTestFactory.geradodeDocumentoTransporte()
														.numero(numero)
														.serie(serie)
														.modelo(modelo)
														.chaveAcesso(chaveAcesso);

			// when
			var exception = catchThrowableOfType(() -> builder.build(),
												 ONBDocumentoTransporteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);

		}

		@Test
		void naoDeveExcluirDocumentoCargaDoDocumentoTransporte() {

			// given
			var documentoCargaId = DocumentoCargaId.generate();
			var documentoCarga = DocumentoCargaTestFactory.umDocumentoCarga().build();

			// when
			var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteDigitadoComDocumentoCarga(documentoCarga);
			documentoTransporte.excluirDocumentoCarga(documentoCargaId);

			// then
			assertThat(documentoTransporte.getDocumentosCarga()).isNotEmpty();

		}

	}

	@Nested
	@DisplayName("Testes de falha para alterar DocumentoTrasnporte")
	class CaminhoInfelizAlterar {
		@Test
		void naoDeveAlterarDocumentoTransporteAnulado() {

			// given
			var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteAnulado(usuarioId);

			// when
			Executable action = () -> documentoTransporte.alterar(null, null, null, null);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException.class, action);

		}

		@Test
		void naoDeveAlterarDocumentoTransporteAutorizado() {

			// given
			var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteAutorizado(usuarioId,
																									 chaveAcesso);

			// when
			Executable action = () -> documentoTransporte.alterar(null, null, null, null);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException.class, action);

		}

		@Test
		void naoDeveAlterarDocumentoTransporteCancelado() {

			// given
			var documentoTransporte = DocumentoTransporteTestFactory.umDocumentoTransporteCancelado(usuarioId);

			// when
			Executable action = () -> documentoTransporte.alterar(null, null, null, null);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAlteracaoException.class, action);

		}
	}

	@Nested
	@DisplayName("Testes de falha para anular DocumentoTrasnporte")
	class CaminhoInfelizAnular {
		@Test
		void naoDeveAnularDocumentoTransporteCancelado() {

			// given
			var documentoTransporteCancelado = DocumentoTransporteTestFactory.umDocumentoTransporteCancelado(usuarioId);

			// when
			Executable action = () -> documentoTransporteCancelado.anular(usuarioId);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAnulacaoException.class, action);

		}

	}

	@Nested
	@DisplayName("Testes de falha para autorizar DocumentoTrasnporte")
	class CaminhoInfelizAutorizar {
		@Test
		void naoDeveAutorizarDocumentoTransporteAnulado() {

			// given
			var documentoTransporteAnulado = DocumentoTransporteTestFactory.umDocumentoTransporteAnulado(usuarioId);

			// when
			Executable action = () -> documentoTransporteAnulado.autorizar(usuarioId, chaveAcesso);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAutorizacaoException.class, action);

		}

		@Test
		void naoDeveAutorizarDocumentoTransporteCancelado() {

			// given
			var documentoTransporteCancelado = DocumentoTransporteTestFactory.umDocumentoTransporteCancelado(usuarioId);

			// when
			Executable action = () -> documentoTransporteCancelado.autorizar(usuarioId, chaveAcesso);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteAutorizacaoException.class, action);

		}

		@Test
		void naoDeveAutorizarDocumentoTransporteSemChaveAcesso() {

			// given
			var documentoTransporte = DocumentoTransporteTestFactory.geradodeDocumentoTransporte()
																	.chaveAcesso(null)
																	.build();

			// when
			Executable action = () -> documentoTransporte.autorizar(usuarioId, null);

			// then
			assertThrows(ONBDocumentoTransporteNaoPermiteAutorizacaoSemChaveAcessoException.class, action);

		}
	}

	@Nested
	@DisplayName("Testes de falha para cancelar DocumentoTrasnporte")
	class CaminhoInfelizCancelar {
		@Test
		void naoDeveCancelarDocumentoTransporteAnulado() {

			// given
			var documentoTransporteAnulado = DocumentoTransporteTestFactory.umDocumentoTransporteAnulado(usuarioId);

			// when
			Executable action = () -> documentoTransporteAnulado.cancelar(usuarioId);

			// then
			assertThrows(ONBDocumentoTransporteSituacaoNaoPermiteCancelarException.class, action);

		}
	}



}
