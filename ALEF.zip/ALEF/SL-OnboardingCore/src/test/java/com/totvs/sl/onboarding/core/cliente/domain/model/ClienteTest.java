package com.totvs.sl.onboarding.core.cliente.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.sl.onboarding.core.util.TestUtils.getEvent;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.catchThrowableOfType;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import com.totvs.sl.onboarding.core.cliente.ClienteTestFactory;
import com.totvs.sl.onboarding.core.cliente.domain.asserts.ClienteAlteradoEventAssert;
import com.totvs.sl.onboarding.core.cliente.domain.asserts.ClienteAtivadoEventAssert;
import com.totvs.sl.onboarding.core.cliente.domain.asserts.ClienteCriadoEventAssert;
import com.totvs.sl.onboarding.core.cliente.domain.asserts.ClienteInativadoEventAssert;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.core.cliente.exception.ONBClienteConstraintException;
import com.totvs.sl.onboarding.core.documentoidentificacao.domain.model.DocumentoIdentificacao;
import com.totvs.sl.onboarding.core.util.TestUtils;
import com.totvs.tjf.core.validation.ValidatorService;

@DisplayName("ClienteTest - Teste de comportamento do agregado")
class ClienteTest {

	private final ClienteId id = ClienteId.generate();
	private final String nome = "NOME DEPOSITANTE";
	private final String novoNome = "NOVO NOME DEPOSITANTE";
	private final String cpf = "90817824014";
	private final String cnpj = "10999961000105";

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	@Test
	void deveConstruirClientePessoaFisica() {

		// when
		var cliente = Cliente.builder().id(id).nome(nome).documento(DocumentoIdentificacao.from(cpf)).build();

		// then
		assertThat(cliente.getId()).isEqualTo(id);
		assertThat(cliente.getNome()).isEqualTo(nome);
		assertThat(cliente.getDocumento()).isEqualTo(DocumentoIdentificacao.from(cpf));
		assertThat(cliente.getEvents()).hasSize(1);
		assertThat(cliente.getEvents()).hasOnlyElementsOfType(ClienteCriadoEvent.class);

		var event = getEvent(cliente.getEvents(), ClienteCriadoEvent.class);
		ClienteCriadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(cliente);
	}

	@Test
	void deveConstruirClientePessoaJuridica() {

		// when
		var cliente = Cliente.builder().id(id).nome(nome).documento(DocumentoIdentificacao.from(cnpj)).build();

		// then
		assertThat(cliente.getId()).isEqualTo(id);
		assertThat(cliente.getNome()).isEqualTo(nome);
		assertThat(cliente.getDocumento()).isEqualTo(DocumentoIdentificacao.from(cnpj));

		var event = getEvent(cliente.getEvents(), ClienteCriadoEvent.class);
		ClienteCriadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(cliente);
	}

	@Test
	void doisClientesComMesmoNomeEDocumentoComIdsDiferentesDevemSerDiferente() {

		var cliente01 = Cliente.builder().id(id).nome(nome).documento(DocumentoIdentificacao.from(cpf)).build();
		var cliente02 = Cliente.builder()
							   .id(ClienteId.generate())
							   .nome(nome)
							   .documento(DocumentoIdentificacao.from(cpf))
							   .build();

		assertThat(cliente01).isNotEqualTo(cliente02);
	}

	@Test
	void doisClientesComNomeEDocumentoDiferentesComMesmoIdDevemSerIguais() {

		var cliente01 = Cliente.builder().id(id).nome(nome).documento(DocumentoIdentificacao.from(cpf)).build();
		var cliente02 = Cliente.builder()
							   .id(id)
							   .nome("PEDRINHO")
							   .documento(DocumentoIdentificacao.from("11933026090"))
							   .build();

		assertThat(cliente01).isEqualTo(cliente02);
	}

	@Test
	void deveAlterarInformacoesDoCliente() {

		// given
		var cliente = ClienteTestFactory.umClienteAtivo();

		// when
		cliente.alterar(novoNome);

		// then
		assertThat(cliente.getNome()).isEqualTo(novoNome);

		var event = getEvent(cliente.getEvents(), ClienteAlteradoEvent.class);
		ClienteAlteradoEventAssert.assertThatEvent(event).hasInformationAccordingTo(cliente);
	}

	@Test
	void deveInativarCliente() {

		// given
		var cliente = ClienteTestFactory.umClienteAtivo();
		assertEquals(1, cliente.getHistoricoSituacoes().size());

		// when
		cliente.inativar();

		// then
		assertThat(cliente.getSituacao().isInativo()).isTrue();
		assertEquals(2, cliente.getHistoricoSituacoes().size());

		var event = getEvent(cliente.getEvents(), ClienteInativadoEvent.class);
		ClienteInativadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(cliente);
	}

	@Test
	void aoInativarClienteInativoSeuEstadoNaoDeveSerAlterado() {

		// given
		var cliente = ClienteTestFactory.umClienteInativo();
		assertEquals(2, cliente.getHistoricoSituacoes().size());

		// when
		cliente.inativar();

		// then
		assertEquals(2, cliente.getHistoricoSituacoes().size());
		assertThat(cliente.getSituacao().isInativo()).isTrue();

		assertThat(cliente.getEvents()).isEmpty();
	}

	@Test
	void deveAtivarCliente() {

		// given
		var cliente = ClienteTestFactory.umClienteInativo();
		assertEquals(2, cliente.getHistoricoSituacoes().size());

		// when
		cliente.ativar();

		// then
		assertEquals(3, cliente.getHistoricoSituacoes().size());
		assertThat(cliente.getSituacao().isAtivo()).isTrue();

		var event = getEvent(cliente.getEvents(), ClienteAtivadoEvent.class);
		ClienteAtivadoEventAssert.assertThatEvent(event).hasInformationAccordingTo(cliente);
	}

	@Test
	void aoAtivarClienteAtivoSeuEstadoNaoDeveSerAlterado() {

		// given
		var cliente = ClienteTestFactory.umClienteAtivo();
		assertEquals(1, cliente.getHistoricoSituacoes().size());

		// when
		cliente.ativar();

		// then
		assertEquals(1, cliente.getHistoricoSituacoes().size());
		assertThat(cliente.getSituacao().isAtivo()).isTrue();

		assertThat(cliente.getEvents()).isEmpty();
	}

	@Nested
	@DisplayName("Teste de falha")
	class CaminhoInfeliz {

		@Test
		@DisplayName("Não deve criar uma instância quando id não informado.")
		void naoDeveCriarClienteSemId() {

			// when
			Executable action = () -> Cliente.builder().build();

			// then
			assertThrows(NullPointerException.class, action);
		}

		@Test
		void naoDeveConstruirClienteSemInformacoesObrigatorias() {

			// given
			var validations = Set.of("Cliente.nome.NotBlank", "Cliente.documento.NotNull");

			var builder = Cliente.builder().id(ClienteId.generate());

			// when
			var exception = catchThrowableOfType(() -> builder.build(), ONBClienteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);
		}

		@Test
		void naoDeveAlterarSemInformarInformacoesObrigatorias() {

			// given
			var validations = Set.of("Cliente.nome.NotBlank");

			var cliente = ClienteTestFactory.umClienteAtivo();

			// when
			var exception = catchThrowableOfType(() -> cliente.alterar(null), ONBClienteConstraintException.class);

			// then
			TestUtils.assertThrowableContainsViolations(exception, validations);
		}

	}
}
