package com.totvs.sl.onboarding.core.cliente.domain.asserts;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.AbstractAssert;

import com.totvs.sl.onboarding.core.cliente.domain.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.core.cliente.domain.model.Cliente;

public class ClienteCriadoEventAssert extends AbstractAssert<ClienteCriadoEventAssert, ClienteCriadoEvent> {

	public ClienteCriadoEventAssert(ClienteCriadoEvent actual) {
		super(actual, ClienteCriadoEventAssert.class);
	}

	public ClienteCriadoEventAssert hasInformationAccordingTo(Cliente cliente) {
		isNotNull();

		assertThat(actual.getId()).isEqualTo(cliente.getId().toString());
		assertThat(actual.getNome()).isEqualTo(cliente.getNome().toString());
		assertThat(actual.getDocumento()).isEqualTo(cliente.getDocumento().getNumero().toString());
		assertThat(actual.isPessoaFisica()).isEqualTo(cliente.getDocumento().isPessoaFisica());
		assertThat(actual.getSituacao()).isEqualTo(cliente.getSituacao().getValor().toString());

		return this;
	}

	public static ClienteCriadoEventAssert assertThatEvent(ClienteCriadoEvent actual) {
		return new ClienteCriadoEventAssert(actual);
	}
}