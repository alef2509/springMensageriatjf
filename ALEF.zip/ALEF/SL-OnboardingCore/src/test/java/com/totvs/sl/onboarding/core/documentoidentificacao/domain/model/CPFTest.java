package com.totvs.sl.onboarding.core.documentoidentificacao.domain.model;

import static com.totvs.sl.onboarding.core.util.ConstraintUtils.getValidator;
import static com.totvs.tjf.autoconfigure.ValidationUtils.init;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import java.util.Map;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;

import com.totvs.sl.onboarding.core.documentoidentificacao.exception.ONBCPFConstraintException;
import com.totvs.tjf.core.validation.ValidatorService;

@DisplayName("CPF - Domínio")
class CPFTest {

	@BeforeAll
	static void beforeAll() {
		init(new ValidatorService(getValidator()));
	}

	private static Stream<Arguments> cpfPorEstado() {
		return Stream.of(Arguments.of(Map.entry("AC", "01253770298")),
						 Arguments.of(Map.entry("AL", "25597796410")),
						 Arguments.of(Map.entry("AM", "01630203297")),
						 Arguments.of(Map.entry("AP", "29045406284")),
						 Arguments.of(Map.entry("BA", "01630203297")),
						 Arguments.of(Map.entry("CE", "49401131325")),
						 Arguments.of(Map.entry("DF", "29045406284")),
						 Arguments.of(Map.entry("ES", "01586753711")),
						 Arguments.of(Map.entry("GO", "75816009125")),
						 Arguments.of(Map.entry("MA", "75816009125")),
						 Arguments.of(Map.entry("MG", "89306089651")),
						 Arguments.of(Map.entry("MS", "05976438148")),
						 Arguments.of(Map.entry("MT", "84464181180")),
						 Arguments.of(Map.entry("PA", "73716359491")),
						 Arguments.of(Map.entry("PB", "93900530483")),
						 Arguments.of(Map.entry("PE", "20205154409")),
						 Arguments.of(Map.entry("PI", "74046435380")),
						 Arguments.of(Map.entry("PR", "12948293944")),
						 Arguments.of(Map.entry("PJ", "14377532723")),
						 Arguments.of(Map.entry("RN", "80038609460")),
						 Arguments.of(Map.entry("RS", "71897486014")),
						 Arguments.of(Map.entry("RO", "72651167207")),
						 Arguments.of(Map.entry("RR", "81229055282")),
						 Arguments.of(Map.entry("SC", "88057727985")),
						 Arguments.of(Map.entry("SE", "47364391576")),
						 Arguments.of(Map.entry("SP", "80590540823")),
						 Arguments.of(Map.entry("TO", "82176169140")));

	}

	@MethodSource("cpfPorEstado")
	@ParameterizedTest
	void deveConstruirCPFValidoParaCadaUnidadeFederativa(Map.Entry<String, String> cpfPorEstado) {

		// when then
		assertThat(CPF.from(cpfPorEstado.getValue()).getNumero()).isEqualTo(cpfPorEstado.getValue());
	}

	@ValueSource(strings = { "05351821982", "88057727985", "82176169140" })
	@ParameterizedTest
	void deveCompararComoIguaisCPFsComNumerosIguais(String valor) {

		// when then
		assertThat(CPF.from(valor)).isEqualTo(CPF.from(valor));
	}

	@Nested
	@DisplayName("Teste de falha")
	class CaminhoInfeliz {

		@NullSource
		@ValueSource(strings = { "12345678901", "10987654321", "ª¿£®Ü»ÆÂø┼º", "12345678,12", "123", "" })
		@ParameterizedTest
		void deveRetonarCPFInvalidoParaValoresInvalidos(String valor) {

			// when then
			assertThatExceptionOfType(ONBCPFConstraintException.class).isThrownBy(() -> CPF.from(valor));
		}

		@ValueSource(strings = { "00000000000", "11111111111", "22222222222", "33333333333", "44444444444",
				"55555555555", "66666666666", "77777777777", "88888888888", "99999999999" })
		@ParameterizedTest
		void deveRetonarCPFInvalidoParaNumerosIguais(String valor) {

			// when then
			assertThatExceptionOfType(ONBCPFConstraintException.class).isThrownBy(() -> CPF.from(valor));
		}

	}
}