CREATE TABLE cliente
(
	id             VARCHAR(36)  NOT NULL,
	nome           VARCHAR(255) NOT NULL,
	documento      VARCHAR(24),
	situacao       VARCHAR(20)   NOT NULL,
	pessoa_fisica  boolean      NOT NULL DEFAULT false,
    metadata       JsonB NOT NULL DEFAULT '[]',
	CONSTRAINT cliente_pkey PRIMARY KEY (id)
);

    CREATE INDEX cliente_documento_idx   ON cliente (documento);
    CREATE INDEX cliente_situacao_idx    ON cliente (situacao);
    CREATE INDEX cliente_nome_idx        ON cliente (nome);
