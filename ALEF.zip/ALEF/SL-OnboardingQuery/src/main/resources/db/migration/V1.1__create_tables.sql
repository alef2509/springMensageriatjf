create table documento_transporte (
id     varchar(36)     not null,
numero VARCHAR(9)  NOT NULL,
serie VARCHAR(9)  NOT NULL,
emissao timestamp  NOT NULL,
modelo VARCHAR(9)  NOT NULL,
chave_Acesso VARCHAR(49)  NOT NULL,
situacao VARCHAR(20)   NOT NULL,
cotacao_Frete_Id VARCHAR(36)  NOT NULL,
remetente_Id VARCHAR(36)  NOT NULL,
destinatario_Id VARCHAR(36)  NOT NULL,
pagador_Frete_Id VARCHAR(36)  NOT NULL,
metadata       Jsonb,
CONSTRAINT documento_transporte_pkey PRIMARY KEY (id)
);


create table documento_carga (
                                 id     varchar(36)     not null,
                                 documento_Transporte_Id varchar(36)     not null,
                                 numero VARCHAR(9)  NOT NULL,
                                 serie VARCHAR(9)  NOT NULL,
                                 emissao timestamp  NOT NULL,
                                 modelo VARCHAR(9)  NOT NULL,
                                 chave_Acesso VARCHAR(49)  NOT NULL,
                                 CONSTRAINT documento_carga_pkey PRIMARY KEY (id)
);

create table registro_situacao (      id     varchar(36)     not null,
                                      documento_Transporte_Id     varchar(36)     not null,
                                      quando timestamp  NOT NULL,
                                      valor VARCHAR(20)   NOT NULL,
                                      usuario VARCHAR(36)  NOT NULL,
                                    CONSTRAINT registro_situacao_pkey PRIMARY KEY (id)

);