package com.totvs.sl.onboarding.query.cliente.api.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "id", "nome", "documento", "pessoaFisica", "situacao" })
public interface ClienteGetByIdDTO {

	String getId();

	String getNome();

	String getDocumento();

	boolean isPessoaFisica();

	String getSituacao();
}
