package com.totvs.sl.onboarding.query.documentotransporte.amqp.event;

import lombok.*;

import java.time.ZonedDateTime;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DocumentoTransporteAnuladoEvent {

    public static final String NAME = "DocumentoTransporteAnuladoEvent";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

    private final String id;
    private final ZonedDateTime quando;
    private final String usuario;
}
