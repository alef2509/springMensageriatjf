package com.totvs.sl.onboarding.query.documentotransporte.repository;

import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.time.ZonedDateTime;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DocumentoTransporteSpecification {

    public static Specification<DocumentoTransporteModel> where() {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -2698727909021438396L;

            @Override
            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return null;
            }
        };


    }

    public static Specification<DocumentoTransporteModel> comId(String id) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.like(root.get("id"), id);
            }
        };
    }


    public static Specification<DocumentoTransporteModel> comremetenteId(String id) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.like(root.get("remetenteId"), id);
            }
        };
    }


    public static Specification<DocumentoTransporteModel> compagadorFreteId(String id) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.like(root.get("pagadorFreteId"), id);
            }
        };
    }

    public static Specification<DocumentoTransporteModel> naSituacao(String situacao) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = 6650137451340001714L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.equal(root.get("situacao"), situacao);
            }
        };
    }


    public static Specification<DocumentoTransporteModel> comChaveAcesso(String chaveAcesso) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.equal(root.get("chaveAcesso"), chaveAcesso);
            }
        };
    }

    public static Specification<DocumentoTransporteModel> comNumero(String id) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.equal(root.get("numero"), id);
            }
        };
    }


    public static Specification<DocumentoTransporteModel> comEmissao(ZonedDateTime emissao) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.equal(root.get("emissao"), emissao);
            }
        };
    }

    public static Specification<DocumentoTransporteModel> comEmissaoAte(ZonedDateTime emissao) {
        return new Specification<DocumentoTransporteModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoTransporteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.lessThanOrEqualTo(root.get("emissao"), emissao);
            }
        };
    }


}
