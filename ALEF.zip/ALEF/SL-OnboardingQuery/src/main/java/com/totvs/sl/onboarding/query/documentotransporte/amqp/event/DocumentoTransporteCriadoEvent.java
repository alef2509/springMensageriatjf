package com.totvs.sl.onboarding.query.documentotransporte.amqp.event;

import java.time.ZonedDateTime;

import lombok.*;

@Data
@Builder
public final class DocumentoTransporteCriadoEvent {

	public static final String NAME = "DocumentoTransporteCriadoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String id;
	private final String numero;
	private final ZonedDateTime emissao;
	private final String serie;
	private final String modelo;
	private final String chaveAcesso;
	private final String situacao;
	private final String cotacaoFreteId;
	private final String remetenteId;
	private final String destinatarioId;
	private final String pagadorFreteId;

}
