package com.totvs.sl.onboarding.query.documentotransporte.repository;

import java.util.Optional;

import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.onboarding.query.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.tjf.api.jpa.repository.ApiJpaRepository;
import com.totvs.tjf.api.jpa.repository.JpaSpecificationExecutorWithProjection;

@Repository
@Transactional(readOnly = true)
public interface DocumentoTransporteRepository extends JpaRepository<DocumentoTransporteModel, String>,
		ApiJpaRepository<DocumentoTransporteModel>, JpaSpecificationExecutorWithProjection<DocumentoTransporteModel> {

	@Override
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	Optional<DocumentoTransporteModel> findById(String id);

	@Lock(LockModeType.PESSIMISTIC_WRITE)
	default DocumentoTransporteModel findByIdOrThrowNotFound(String id) {
		return findById(id).orElseThrow(ONBDocumentoTransporteNaoEncontradoException::new);
	}
}
