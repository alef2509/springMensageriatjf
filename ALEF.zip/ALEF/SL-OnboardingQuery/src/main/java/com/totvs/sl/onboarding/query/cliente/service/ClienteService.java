package com.totvs.sl.onboarding.query.cliente.service;

import java.time.ZonedDateTime;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class ClienteService {

	private final ClienteRepository repository;

	public void on(final ClienteCriadoEvent event) {

		var cliente = ClienteModel.builder()
								  .id(event.getId())
								  .nome(event.getNome())
								  .documento(event.getDocumento())
								  .pessoaFisica(event.isPessoaFisica())
								  .situacao(event.getSituacao())
								  .build();

		repository.saveAndFlush(cliente);
	}

	public void on(final ClienteAlteradoEvent event, final ZonedDateTime dataHoraEvento) {
		var cliente = repository.findByIdOrThrowNotFound(event.getId());

		cliente.setNome(event.getNome(), dataHoraEvento);

		repository.saveAndFlush(cliente);
	}

	public void on(final ClienteAtivadoEvent event, final ZonedDateTime dataHoraEvento) {
		var cliente = repository.findByIdOrThrowNotFound(event.getId());

		cliente.setSituacao(event.getSituacao(), dataHoraEvento);

		repository.saveAndFlush(cliente);
	}

	public void on(final ClienteInativadoEvent event, final ZonedDateTime dataHoraEvento) {
		var cliente = repository.findByIdOrThrowNotFound(event.getId());

		cliente.setSituacao(event.getSituacao(), dataHoraEvento);

		repository.saveAndFlush(cliente);
	}

}