package com.totvs.sl.onboarding.query.documentocarga.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class ONBDocumentoCargaNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = 6967556765385022423L;

}
