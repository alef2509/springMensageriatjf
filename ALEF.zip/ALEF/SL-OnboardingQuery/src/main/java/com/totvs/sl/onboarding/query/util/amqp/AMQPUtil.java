package com.totvs.sl.onboarding.query.util.amqp;

import org.springframework.util.ClassUtils;

import com.totvs.tjf.core.message.TOTVSMessage;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AMQPUtil {

	private AMQPUtil() {}

	public static void gerarLog(Class<?> clazz, TOTVSMessage<?> message, String conditionalExpression) {

		var content = message.getContent();

		String transactionId = null;
		String generatedBy = null;

		if (message.getHeader().getTransactionInfo() != null) {
			transactionId = message.getHeader().getTransactionInfo().getTransactionId();
			generatedBy = message.getHeader().getTransactionInfo().getGeneratedBy();
		}

		log.info("{} - Listener for {} | CONDITIONAL_EXPRESSION: {} | Header.TransactionId: {} | "
				+ "Header.GeneratedBy: {} | Content: {}",
				 ClassUtils.getUserClass(clazz).getSimpleName(),
				 content.getClass().getSimpleName(),
				 conditionalExpression,
				 transactionId,
				 generatedBy,
				 content);
	}
}
