package com.totvs.sl.onboarding.query.documentocarga.repository;

import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DocumentoCargaSpecification {
    public static Specification<DocumentoCargaModel> where() {

    return new Specification<DocumentoCargaModel>() {

        private static final long serialVersionUID = -2698727909021438396L;

        @Override
        public Predicate toPredicate(Root<DocumentoCargaModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
            return null;
        }
    };
}

    public static Specification<DocumentoCargaModel> comdocumentoTransporteId (String documentoTransporteId) {
        return new Specification<DocumentoCargaModel>() {

            private static final long serialVersionUID = -6212313111651450257L;

            public Predicate toPredicate(Root<DocumentoCargaModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
                return builder.equal(root.get("documentoTransporteId"), documentoTransporteId);
            }
        };
    }




}
