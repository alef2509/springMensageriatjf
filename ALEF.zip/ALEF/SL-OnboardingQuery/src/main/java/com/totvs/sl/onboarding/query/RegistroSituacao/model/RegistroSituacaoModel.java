package com.totvs.sl.onboarding.query.RegistroSituacao.model;

import java.time.ZonedDateTime;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import com.totvs.sl.onboarding.query.documentotransporte.model.SituacaoDocumento;

import lombok.*;
import org.hibernate.annotations.DynamicUpdate;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "registro_situacao")
public class RegistroSituacaoModel {

	@Id
	@NotNull
	private String id;

	@NotNull
	private String documentoTransporteId;

	@NotNull
	private ZonedDateTime quando;

	@NotNull
	@Enumerated(EnumType.STRING)
	private SituacaoDocumento valor;

	@NotNull
	private String usuario;

}
