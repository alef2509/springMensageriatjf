package com.totvs.sl.onboarding.query.cliente.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class ONBClienteNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = -6237420991197291008L;

}
