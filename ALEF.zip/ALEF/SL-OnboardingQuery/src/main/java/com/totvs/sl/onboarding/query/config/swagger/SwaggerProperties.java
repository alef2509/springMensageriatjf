package com.totvs.sl.onboarding.query.config.swagger;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

@Data
@ConfigurationProperties(prefix = "swagger", ignoreUnknownFields = true, ignoreInvalidFields = true)
public class SwaggerProperties {

	private Oauth2Properties oauth2;

	@Data
	public static class Oauth2Properties {
		private String authServer;
	}
}
