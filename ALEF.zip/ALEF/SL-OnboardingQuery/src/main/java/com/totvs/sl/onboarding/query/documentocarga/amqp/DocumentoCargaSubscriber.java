package com.totvs.sl.onboarding.query.documentocarga.amqp;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.onboarding.query.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.query.documentocarga.amqp.event.DocumentoTransporteDocumentoCargaAdicionadoEvent;
import com.totvs.sl.onboarding.query.documentocarga.amqp.event.DocumentoTransporteDocumentoCargaExcluidoEvent;
import com.totvs.sl.onboarding.query.documentocarga.service.DocumentoCargaService;
import com.totvs.sl.onboarding.query.util.amqp.AMQPUtil;
import com.totvs.tjf.core.message.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeInput.class)
public class DocumentoCargaSubscriber {



}
