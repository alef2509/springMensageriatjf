package com.totvs.sl.onboarding.query.cliente.api.request;

import static java.util.Objects.nonNull;
import static org.springframework.util.StringUtils.hasText;

import org.springframework.data.jpa.domain.Specification;

import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteSpecification;

import lombok.Data;

@Data
public class GetAllClienteRequest {

	private String nome;
	private String documento;
	private String situacao;
	private String searchTerm;

	public Specification<ClienteModel> buildSpecification() {
		Specification<ClienteModel> specs = ClienteSpecification.where();

		if (hasText(this.searchTerm)) {
			specs = specs.and(ClienteSpecification.comDocumento(this.searchTerm));
			specs = specs.or(ClienteSpecification.queContenhaNomeCom(this.searchTerm));

		} else {
			if (hasText(this.documento))
				specs = specs.and(ClienteSpecification.comDocumento(this.documento));

			if (hasText(this.nome))
				specs = specs.and(ClienteSpecification.queContenhaNomeCom(nome));

			if (nonNull(this.situacao))
				specs = specs.and(ClienteSpecification.naSituacao(situacao));
		}

		return specs;
	}
}