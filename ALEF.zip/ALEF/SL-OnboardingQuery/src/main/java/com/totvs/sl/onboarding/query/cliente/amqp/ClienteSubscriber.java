package com.totvs.sl.onboarding.query.cliente.amqp;

import java.time.ZonedDateTime;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.query.cliente.service.ClienteService;
import com.totvs.sl.onboarding.query.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.query.util.amqp.AMQPUtil;
import com.totvs.tjf.core.message.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeInput.class)
public class ClienteSubscriber {

	private final ClienteService service;

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = ClienteCriadoEvent.CONDITIONAL_EXPRESSION)
	public void clienteCriado(TOTVSMessage<ClienteCriadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, ClienteCriadoEvent.CONDITIONAL_EXPRESSION);

		service.on(message.getContent());
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = ClienteAlteradoEvent.CONDITIONAL_EXPRESSION)
	public void clienteAlterado(TOTVSMessage<ClienteAlteradoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, ClienteCriadoEvent.CONDITIONAL_EXPRESSION);

		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());

		service.on(message.getContent(), dataHoraEvento);
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = ClienteAtivadoEvent.CONDITIONAL_EXPRESSION)
	public void clienteAtivado(TOTVSMessage<ClienteAtivadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, ClienteCriadoEvent.CONDITIONAL_EXPRESSION);

		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());

		service.on(message.getContent(), dataHoraEvento);
	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = ClienteInativadoEvent.CONDITIONAL_EXPRESSION)
	public void clienteInativado(TOTVSMessage<ClienteInativadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, ClienteCriadoEvent.CONDITIONAL_EXPRESSION);

		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());

		service.on(message.getContent(), dataHoraEvento);
	}

}
