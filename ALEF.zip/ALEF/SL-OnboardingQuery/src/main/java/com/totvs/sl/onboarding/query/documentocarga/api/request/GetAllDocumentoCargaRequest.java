package com.totvs.sl.onboarding.query.documentocarga.api.request;

import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaSpecification;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteSpecification;
import org.springframework.data.jpa.domain.Specification;

import java.time.ZonedDateTime;

import static java.util.Objects.nonNull;
import static org.springframework.util.StringUtils.hasText;

public class GetAllDocumentoCargaRequest {

    private String id;
    private String documentoTransporteId;
    private String numero;
    private ZonedDateTime emissao;
    private String serie;
    private String modelo;
    private String chaveAcesso;
    private String searchTerm;

    public Specification<DocumentoCargaModel> buildSpecification() {
        Specification<DocumentoCargaModel> specs = DocumentoCargaSpecification.where();

        if (hasText(this.searchTerm))
            specs = specs.and(DocumentoCargaSpecification.comdocumentoTransporteId(this.searchTerm));

        return specs;
    }
}
