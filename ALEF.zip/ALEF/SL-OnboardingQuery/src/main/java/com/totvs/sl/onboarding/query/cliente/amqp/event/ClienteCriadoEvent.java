package com.totvs.sl.onboarding.query.cliente.amqp.event;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public final class ClienteCriadoEvent {

	public static final String NAME = "ClienteCriadoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String id;
	private final String nome;
	private final String documento;
	private final boolean pessoaFisica;
	private final String situacao;

}
