package com.totvs.sl.onboarding.query.documentotransporte.api;

import com.totvs.sl.onboarding.query.RegistroSituacao.repository.RegistroSituacaoRepository;
import com.totvs.sl.onboarding.query.documentocarga.api.dto.DocumentoCargaGetByIdDocumentoTransporteDTO;
import com.totvs.sl.onboarding.query.documentocarga.api.request.GetAllDocumentoCargaRequest;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaRepository;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaSpecification;
import com.totvs.sl.onboarding.query.documentotransporte.api.dto.DocumentoTransporteGetAllDTO;
import com.totvs.sl.onboarding.query.documentotransporte.api.dto.DocumentoTransporteGetByIdDTO;
import com.totvs.sl.onboarding.query.documentotransporte.api.request.GetAllDocumentoTransporteRequest;
import com.totvs.sl.onboarding.query.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteRepository;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteSpecification;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.v2.request.ApiFieldRequest;
import com.totvs.tjf.api.context.v2.request.ApiPageRequest;
import com.totvs.tjf.api.context.v2.request.ApiSortRequest;
import com.totvs.tjf.api.context.v2.response.ApiCollectionResponse;
import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;
import org.springdoc.api.annotations.ParameterObject;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping(path = DocumentoTransporteController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
@ApiGuideline(ApiGuideline.ApiGuidelineVersion.V2)
public class DocumentoTransporteController {

    public static final String PATH = "api/v1/documentosTransporte";

    private final DocumentoTransporteRepository repository;
    private final DocumentoCargaRepository repositoryDocumentoCarga;
    private final RegistroSituacaoRepository repositoryRegistroSituacao;

    @GetMapping
    @Operation(description = "Retorna uma lista de documento de transporte com base em um filtro informado.", method = "GET")
    public ApiCollectionResponse<DocumentoTransporteGetAllDTO> getAll(@ParameterObject ApiPageRequest pageRequest,
                                                                      @ParameterObject ApiSortRequest sortRequest,
                                                                      @ParameterObject GetAllDocumentoTransporteRequest filterRequest) {

        return ApiCollectionResponse.from(this.repository.findAllProjected(DocumentoTransporteGetAllDTO.class,
                pageRequest,
                sortRequest,
                filterRequest.buildSpecification()));
    }


    @GetMapping(path = "/{id}")
    @Operation(description = "Retorna um documento de transporte a partir de seu Id.", method = "GET")
    public DocumentoTransporteGetByIdDTO getById(@PathVariable("id") String id, @ParameterObject ApiFieldRequest fieldRequest) {

        return this.repository.findOneProjected(DocumentoTransporteSpecification.comId(id), DocumentoTransporteGetByIdDTO.class, fieldRequest)
                .orElseThrow(ONBDocumentoTransporteNaoEncontradoException::new);
    }

    @GetMapping(path = "/{id}/documentoCarga")
    @Operation(description = "Retorna uma lista de documento de transporte com base em um filtro informado.", method = "GET")
    public ApiCollectionResponse<DocumentoCargaGetByIdDocumentoTransporteDTO> getDocumentoCargaByIdDocumentoTransporte2(@PathVariable("id") String id) {

        var collection = this.repositoryDocumentoCarga.findBydocumentoTransporteId(id);
        return ApiCollectionResponse.from(collection);
    }



}
