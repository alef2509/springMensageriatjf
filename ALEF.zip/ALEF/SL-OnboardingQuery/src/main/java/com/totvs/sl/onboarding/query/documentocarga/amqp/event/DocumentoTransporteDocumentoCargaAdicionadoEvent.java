package com.totvs.sl.onboarding.query.documentocarga.amqp.event;

import java.time.LocalDate;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
public final class DocumentoTransporteDocumentoCargaAdicionadoEvent {

	public static final String NAME = "DocumentoTransporteDocumentoCargaAdicionadoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	@Data
	@AllArgsConstructor
	@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
	public static final class DocumentoTransporteEvent {
		private final String id;
	}

	private final DocumentoTransporteEvent documentoTransporte;
	private final String id;
	private final String numero;
	private final LocalDate emissao;
	private final String serie;
	private final String modelo;
	private final String chaveAcesso;

}
