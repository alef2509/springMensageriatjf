package com.totvs.sl.onboarding.query.cliente.repository;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ClienteSpecification {

	public static Specification<ClienteModel> where() {
		return new Specification<ClienteModel>() {

			private static final long serialVersionUID = -2698727909021438396L;

			@Override
			public Predicate toPredicate(Root<ClienteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
				return null;
			}
		};
	}

	public static Specification<ClienteModel> comId(String id) {
		return new Specification<ClienteModel>() {

			private static final long serialVersionUID = -6212313111651450257L;

			public Predicate toPredicate(Root<ClienteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
				return builder.like(root.get("id"), id);
			}
		};
	}

	public static Specification<ClienteModel> comDocumento(String documento) {
		return new Specification<ClienteModel>() {

			private static final long serialVersionUID = -6212313111651450257L;

			public Predicate toPredicate(Root<ClienteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
				return builder.like(root.get("documento"), removeFormatacaoDocumento(documento.trim()));
			}
		};
	}

	public static Specification<ClienteModel> queContenhaNomeCom(String nome) {
		return new Specification<ClienteModel>() {

			private static final long serialVersionUID = 3816117507467541290L;

			public Predicate toPredicate(Root<ClienteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
				return builder.like(builder.upper(root.get("nome")), likeTerm(nome.trim().toUpperCase()));
			}
		};
	}

	public static Specification<ClienteModel> naSituacao(String situacao) {
		return new Specification<ClienteModel>() {

			private static final long serialVersionUID = 6650137451340001714L;

			public Predicate toPredicate(Root<ClienteModel> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
				return builder.equal(root.get("situacao"), situacao);
			}
		};
	}

	private static String likeTerm(String term) {
		return new StringBuilder().append('%').append(term).append('%').toString();
	}

	private static String removeFormatacaoDocumento(String documento) {
		var documentoNaoFormatado = documento.trim();
		documentoNaoFormatado = documentoNaoFormatado.replaceAll("[.]", "");
		documentoNaoFormatado = documentoNaoFormatado.replaceAll("[/]", "");
		documentoNaoFormatado = documentoNaoFormatado.replaceAll("[-]", "");
		return documentoNaoFormatado;
	}
}