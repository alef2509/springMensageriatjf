package com.totvs.sl.onboarding.query.documentotransporte.api.request;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteSpecification;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteSpecification;
import org.springframework.data.jpa.domain.Specification;

import java.time.ZonedDateTime;

import static java.util.Objects.nonNull;
import static org.springframework.util.StringUtils.hasText;

public class GetAllDocumentoTransporteRequest {
    private String id;
    private String numero;
    private ZonedDateTime emissao;
    private String serie;
    private String modelo;
    private String chaveAcesso;
    private String cotacaoFreteId;
    private String situacao;
    private String remetenteId;
    private String destinatarioId;
    private String pagadorFreteId;
    private String searchTerm;

    public Specification<DocumentoTransporteModel> buildSpecification() {
        Specification<DocumentoTransporteModel> specs = DocumentoTransporteSpecification.where();

        if (hasText(this.searchTerm)) {
            specs = specs.and(DocumentoTransporteSpecification.comId(this.searchTerm));
            //specs = specs.or(DocumentoTransporteSpecification.comChaveAcesso(this.searchTerm));

        } else {
            if (hasText(this.remetenteId))
                specs = specs.and(DocumentoTransporteSpecification.comremetenteId(this.remetenteId));

            if (hasText(this.pagadorFreteId))
                specs = specs.and(DocumentoTransporteSpecification.compagadorFreteId(this.pagadorFreteId));

            if (nonNull(this.situacao))
                specs = specs.and(DocumentoTransporteSpecification.naSituacao(situacao));

            if (hasText(this.numero))
                specs = specs.and(DocumentoTransporteSpecification.comNumero(this.numero));

            if (hasText(this.chaveAcesso))
                specs = specs.and(DocumentoTransporteSpecification.comChaveAcesso(this.chaveAcesso));

            if (nonNull(this.emissao))
                specs = specs.and(DocumentoTransporteSpecification.comEmissao(this.emissao));
        }

        return specs;
    }
}
