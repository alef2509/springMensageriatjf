package com.totvs.sl.onboarding.query.documentotransporte.amqp.event;

import lombok.*;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DocumentoTransporteAlteradoEvent {

	public static final String NAME = "DocumentoTransporteAlteradoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String id;
	private final String cotacaoFreteId;
	private final String remetenteId;
	private final String destinatarioId;
	private final String pagadorFreteId;

}
