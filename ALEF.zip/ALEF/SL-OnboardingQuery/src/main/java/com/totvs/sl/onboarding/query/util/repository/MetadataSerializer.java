package com.totvs.sl.onboarding.query.util.repository;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class MetadataSerializer extends JsonSerializer<Metadata> {

	private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'")
	                                                                    .withZone(ZoneId.of("UTC"));

	@Override
	public void serialize(Metadata metadata, JsonGenerator jgen, SerializerProvider provider) throws IOException {
		jgen.writeStartArray();
		metadata.getMetadatas().forEach(info -> {
			try {
				jgen.writeStartObject();
				jgen.writeStringField("propertyName", info.getpropertyName());
				jgen.writeStringField("generatedOn", info.getGeneratedOn().format(formatter));
				jgen.writeEndObject();
			} catch (IOException ex) {
				throw new UncheckedIOException(ex);
			}
		});
		jgen.writeEndArray();
	}

}
