package com.totvs.sl.onboarding.query.documentotransporte.exception;

import com.totvs.tjf.api.context.stereotype.error.ApiNotFound;

@ApiNotFound
public class ONBDocumentoTransporteNaoEncontradoException extends RuntimeException {

	private static final long serialVersionUID = -7639739533544935026L;

}
