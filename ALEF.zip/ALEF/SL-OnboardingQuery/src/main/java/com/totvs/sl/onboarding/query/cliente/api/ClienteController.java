package com.totvs.sl.onboarding.query.cliente.api;

import org.springdoc.api.annotations.ParameterObject;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.totvs.sl.onboarding.query.cliente.api.dto.ClienteGetAllDTO;
import com.totvs.sl.onboarding.query.cliente.api.dto.ClienteGetByIdDTO;
import com.totvs.sl.onboarding.query.cliente.api.request.GetAllClienteRequest;
import com.totvs.sl.onboarding.query.cliente.exception.ONBClienteNaoEncontradoException;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteRepository;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteSpecification;
import com.totvs.tjf.api.context.stereotype.ApiGuideline;
import com.totvs.tjf.api.context.stereotype.ApiGuideline.ApiGuidelineVersion;
import com.totvs.tjf.api.context.v2.request.ApiFieldRequest;
import com.totvs.tjf.api.context.v2.request.ApiPageRequest;
import com.totvs.tjf.api.context.v2.request.ApiSortRequest;
import com.totvs.tjf.api.context.v2.response.ApiCollectionResponse;

import io.swagger.v3.oas.annotations.Operation;
import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
@RequestMapping(path = ClienteController.PATH, produces = { MediaType.APPLICATION_JSON_VALUE })
@ApiGuideline(ApiGuidelineVersion.V2)
public class ClienteController {

	public static final String PATH = "api/v1/clientes";

	private final ClienteRepository repository;

	@GetMapping
	@Operation(description = "Retorna uma lista de clientes com base em um filtro informado.", method = "GET")
	public ApiCollectionResponse<ClienteGetAllDTO> getAll(@ParameterObject ApiPageRequest pageRequest,
														  @ParameterObject ApiSortRequest sortRequest,
														  @ParameterObject GetAllClienteRequest filterRequest) {

		return ApiCollectionResponse.from(this.repository.findAllProjected(ClienteGetAllDTO.class,
																		   pageRequest,
																		   sortRequest,
																		   filterRequest.buildSpecification()));
	}

	@GetMapping(path = "/{id}")
	@Operation(description = "Retorna um cliente a partir de seu Id.", method = "GET")
	public ClienteGetByIdDTO getById(@PathVariable("id") String id, @ParameterObject ApiFieldRequest fieldRequest) {

		return this.repository.findOneProjected(ClienteSpecification.comId(id), ClienteGetByIdDTO.class, fieldRequest)
							  .orElseThrow(ONBClienteNaoEncontradoException::new);
	}

}
