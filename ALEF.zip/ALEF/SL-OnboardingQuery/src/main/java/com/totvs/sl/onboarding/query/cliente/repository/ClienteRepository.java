package com.totvs.sl.onboarding.query.cliente.repository;

import java.util.Optional;

import javax.persistence.LockModeType;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.onboarding.query.cliente.exception.ONBClienteNaoEncontradoException;
import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.tjf.api.jpa.repository.ApiJpaRepository;
import com.totvs.tjf.api.jpa.repository.JpaSpecificationExecutorWithProjection;

@Repository
@Transactional(readOnly = true)
public interface ClienteRepository extends JpaRepository<ClienteModel, String>, ApiJpaRepository<ClienteModel>,
		JpaSpecificationExecutorWithProjection<ClienteModel> {

	@Override
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	Optional<ClienteModel> findById(String id);

	@Lock(LockModeType.PESSIMISTIC_WRITE)
	default ClienteModel findByIdOrThrowNotFound(String id) {
		return findById(id).orElseThrow(ONBClienteNaoEncontradoException::new);
	}
}
