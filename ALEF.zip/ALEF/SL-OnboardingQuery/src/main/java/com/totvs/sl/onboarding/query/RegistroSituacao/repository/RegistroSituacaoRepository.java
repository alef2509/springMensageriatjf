package com.totvs.sl.onboarding.query.RegistroSituacao.repository;

import com.totvs.sl.onboarding.query.RegistroSituacao.exception.ONBRegistroSituacaoNaoEncontradoException;
import com.totvs.sl.onboarding.query.RegistroSituacao.model.RegistroSituacaoModel;
import com.totvs.tjf.api.jpa.repository.ApiJpaRepository;
import com.totvs.tjf.api.jpa.repository.JpaSpecificationExecutorWithProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.LockModeType;
import java.util.Optional;

@Repository
@Transactional(readOnly = true)
public interface RegistroSituacaoRepository extends JpaRepository<RegistroSituacaoModel, String>,
        ApiJpaRepository<RegistroSituacaoModel>, JpaSpecificationExecutorWithProjection<RegistroSituacaoModel> {

    @Override
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    Optional<RegistroSituacaoModel> findById(String id);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    default RegistroSituacaoModel findByIdOrThrowNotFound(String id) {
        return findById(id).orElseThrow(ONBRegistroSituacaoNaoEncontradoException::new);
    }
}
