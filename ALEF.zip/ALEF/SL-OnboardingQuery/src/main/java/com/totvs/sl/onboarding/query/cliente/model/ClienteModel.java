package com.totvs.sl.onboarding.query.cliente.model;

import java.time.ZonedDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.totvs.sl.onboarding.query.util.repository.Metadata;
import com.totvs.sl.onboarding.query.util.repository.Metadata.MetadataInfo;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "cliente")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class ClienteModel {

	@Id
	private String id;
	private String nome;
	private String documento;
	private String situacao;
	private boolean pessoaFisica;

	@JsonIgnore
	@Type(type = "jsonb")
	@Column(columnDefinition = "jsonb")
	@Builder.Default
	private Metadata metadata = Metadata.empty();

	public MetadataInfo getMetadataInfo(String propertyName) {
		return this.metadata.getMetadataInfo(propertyName);
	}

	public void setNome(String nome, ZonedDateTime dataHoraEvento) {
		var metadataInfoNome = this.getMetadataInfo("nome");
		if (metadataInfoNome.isBefore(dataHoraEvento)) {
			this.setNome(nome);
			metadataInfoNome.setGeneratedOn(dataHoraEvento);
		}
	}

	public void setSituacao(String situacao, ZonedDateTime dataHoraEvento) {
		var metadataInfoSituacao = this.getMetadataInfo("situacao");
		if (metadataInfoSituacao.isBefore(dataHoraEvento)) {
			this.setSituacao(situacao);
			metadataInfoSituacao.setGeneratedOn(dataHoraEvento);
		}
	}
}