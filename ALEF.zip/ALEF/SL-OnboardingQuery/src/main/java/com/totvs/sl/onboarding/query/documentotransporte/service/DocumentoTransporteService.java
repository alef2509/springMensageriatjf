package com.totvs.sl.onboarding.query.documentotransporte.service;

import java.time.ZonedDateTime;
import java.util.UUID;

import javax.transaction.Transactional;

import com.totvs.sl.onboarding.query.RegistroSituacao.model.RegistroSituacaoModel;
import com.totvs.sl.onboarding.query.RegistroSituacao.repository.RegistroSituacaoRepository;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaRepository;
import com.totvs.sl.onboarding.query.documentotransporte.amqp.event.*;
import org.springframework.stereotype.Service;

import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.sl.onboarding.query.documentotransporte.model.SituacaoDocumento;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteRepository;
import com.totvs.sl.onboarding.query.util.repository.Metadata;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class DocumentoTransporteService {

	private final DocumentoTransporteRepository repository;
	private final DocumentoCargaRepository repositoryCarga;
	private final RegistroSituacaoRepository repositoryRegistroSituacao;

	private void registrarSituacao(String documentoTransporteId, ZonedDateTime quando, SituacaoDocumento situacao, String usuario) {

		var registroSituacao = RegistroSituacaoModel.builder()
				.id(UUID.randomUUID().toString())
				.documentoTransporteId(documentoTransporteId)
				.quando(quando)
				.usuario(usuario)
				.valor(situacao)
				.build();

		repositoryRegistroSituacao.saveAndFlush(registroSituacao);

	}


	public void on(final DocumentoTransporteCriadoEvent event) {

		var documentoTransporte = DocumentoTransporteModel.builder()
														  .id(event.getId())
														  .numero(event.getNumero())
														  .emissao(event.getEmissao())
														  .serie(event.getSerie())
														  .modelo(event.getModelo())
														  .chaveAcesso(event.getChaveAcesso())
				                                          .situacao(event.getSituacao())
														  .cotacaoFreteId(event.getCotacaoFreteId())
														  .remetenteId(event.getRemetenteId())
														  .destinatarioId(event.getDestinatarioId())
														  .pagadorFreteId(event.getPagadorFreteId())
														  .build();

		repository.saveAndFlush(documentoTransporte);
		registrarSituacao(event.getId(), event.getEmissao(), SituacaoDocumento.DIGITADO, event.getRemetenteId());

	}

	public void on(final DocumentoTransporteAlteradoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoTransporte = repository.findByIdOrThrowNotFound(event.getId());

		documentoTransporte.setCotacaoFreteId(event.getCotacaoFreteId(), dataHoraEvento);
		documentoTransporte.setRemetenteId(event.getRemetenteId(), dataHoraEvento);
		documentoTransporte.setDestinatarioId(event.getDestinatarioId(), dataHoraEvento);
		documentoTransporte.setPagadorFreteId(event.getPagadorFreteId(), dataHoraEvento);

		repository.saveAndFlush(documentoTransporte);

	}

	public void on(final DocumentoTransporteAnuladoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoTransporte = repository.findByIdOrThrowNotFound(event.getId());

		documentoTransporte.setSituacao(String.valueOf(SituacaoDocumento.ANULADO), dataHoraEvento);
		repository.saveAndFlush(documentoTransporte);
		registrarSituacao(event.getId(), dataHoraEvento, SituacaoDocumento.ANULADO, event.getUsuario());

	}

	public void on(final DocumentoTransporteAutorizadoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoTransporte = repository.findByIdOrThrowNotFound(event.getId());

		documentoTransporte.setSituacao(String.valueOf(SituacaoDocumento.AUTORIZADO), dataHoraEvento);
		repository.saveAndFlush(documentoTransporte);
		registrarSituacao(event.getId(), dataHoraEvento, SituacaoDocumento.AUTORIZADO, event.getUsuario());

	}

	public void on(final DocumentoTransporteCanceladoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoTransporte = repository.findByIdOrThrowNotFound(event.getId());

		documentoTransporte.setSituacao(String.valueOf(SituacaoDocumento.CANCELADO), dataHoraEvento);
		repository.saveAndFlush(documentoTransporte);
		registrarSituacao(event.getId(), dataHoraEvento, SituacaoDocumento.CANCELADO, event.getUsuario());

	}

	public void on(final DocumentoTransporteDocumentoCargaAdicionadoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoCarga = DocumentoCargaModel.builder()
				.id(event.getId())
				.documentoTransporteId(event.getDocumentoTransporteId())
				.emissao(event.getEmissao())
				.serie(event.getSerie())
				.modelo(event.getModelo())
				.numero(event.getNumero())
				.chaveAcesso(event.getChaveAcesso())
				.build();

		repositoryCarga.saveAndFlush(documentoCarga);

	}

	public void on(final DocumentoTransporteDocumentoCargaExcluidoEvent event, final ZonedDateTime dataHoraEvento) {

		var documentoCarga = repositoryCarga.findByIdOrThrowNotFound(event.getId());

		repositoryCarga.delete(documentoCarga);

	}



}
