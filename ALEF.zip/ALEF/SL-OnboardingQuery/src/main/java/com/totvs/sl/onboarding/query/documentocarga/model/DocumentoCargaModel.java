package com.totvs.sl.onboarding.query.documentocarga.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.DynamicUpdate;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "documento_carga")
public class DocumentoCargaModel {

	@Id
	private String id;

	@NotNull
	private String documentoTransporteId;

	@NotNull
	private LocalDate emissao;

	@NotNull
	private String numero;

	@NotNull
	private String serie;

	@NotNull
	private String modelo;

	private String chaveAcesso;

}
