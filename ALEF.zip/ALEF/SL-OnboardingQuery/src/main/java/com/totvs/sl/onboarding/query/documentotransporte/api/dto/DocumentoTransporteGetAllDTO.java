package com.totvs.sl.onboarding.query.documentotransporte.api.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.ZonedDateTime;

@JsonPropertyOrder({ "id", "numero", "emissao", "serie", "modelo",
        "chaveAcesso", "situacao", "cotacaoFreteId",
        "remetenteId", "destinatarioId", "pagadorFreteId"  })
public interface DocumentoTransporteGetAllDTO {

    String getId();
    String getNumero();
    ZonedDateTime getEmissao();
    String getSerie();
    String getModelo();
    String getChaveAcesso();
    String getSituacao();
    String getCotacaoFreteId();
    String getRemetenteId();
    String getDestinatarioId();
    String getPagadorFreteId();
}
