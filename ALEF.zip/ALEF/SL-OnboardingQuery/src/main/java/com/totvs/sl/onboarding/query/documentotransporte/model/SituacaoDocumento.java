package com.totvs.sl.onboarding.query.documentotransporte.model;

public enum SituacaoDocumento {
	DIGITADO, AUTORIZADO, ANULADO, CANCELADO;
}
