package com.totvs.sl.onboarding.query.documentotransporte.amqp.event;

import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import lombok.*;

import java.time.LocalDate;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DocumentoTransporteDocumentoCargaAdicionadoEvent {

    public static final String NAME = "DocumentoTransporteDocumentoCargaAdicionadoEvent";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";


    private final String documentoTransporteId;
    private final String id;
    private final String numero;
    private final LocalDate emissao;
    private final String serie;
    private final String modelo;
    private final String chaveAcesso;

}
