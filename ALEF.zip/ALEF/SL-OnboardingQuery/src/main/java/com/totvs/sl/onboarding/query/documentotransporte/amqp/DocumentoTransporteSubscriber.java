package com.totvs.sl.onboarding.query.documentotransporte.amqp;

import java.time.ZonedDateTime;

import com.totvs.sl.onboarding.query.documentotransporte.amqp.event.*;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;

import com.totvs.sl.onboarding.query.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.query.documentotransporte.service.DocumentoTransporteService;
import com.totvs.sl.onboarding.query.util.amqp.AMQPUtil;
import com.totvs.tjf.core.message.TOTVSMessage;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@EnableBinding(OnboardingChannel.OnboardingExchangeInput.class)
public class DocumentoTransporteSubscriber {

	private final DocumentoTransporteService service;

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteCriadoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteCriado(TOTVSMessage<DocumentoTransporteCriadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteCriadoEvent.CONDITIONAL_EXPRESSION);

		service.on(message.getContent());

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteAlteradoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteAlterado(TOTVSMessage<DocumentoTransporteAlteradoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteAlteradoEvent.CONDITIONAL_EXPRESSION);

		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());

		service.on(message.getContent(), dataHoraEvento);

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteAnuladoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteAnulado(TOTVSMessage<DocumentoTransporteAnuladoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteAnuladoEvent.CONDITIONAL_EXPRESSION);
		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());
		service.on(message.getContent(),dataHoraEvento);

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteAutorizadoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteAutorizado(TOTVSMessage<DocumentoTransporteAutorizadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteAutorizadoEvent.CONDITIONAL_EXPRESSION);
		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());
		service.on(message.getContent(),dataHoraEvento);

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteCanceladoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteCancelado(TOTVSMessage<DocumentoTransporteCanceladoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteCanceladoEvent.CONDITIONAL_EXPRESSION);
		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());
		service.on(message.getContent(),dataHoraEvento);

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteDocumentoCargaAdicionadoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteCargaAdicionada(TOTVSMessage<DocumentoTransporteDocumentoCargaAdicionadoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteDocumentoCargaAdicionadoEvent.CONDITIONAL_EXPRESSION);
		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());
		service.on(message.getContent(),dataHoraEvento);

	}

	@StreamListener(target = OnboardingChannel.ONBOARDING_INPUT, condition = DocumentoTransporteDocumentoCargaExcluidoEvent.CONDITIONAL_EXPRESSION)
	public void documentoTransporteCargaExcluido(TOTVSMessage<DocumentoTransporteDocumentoCargaExcluidoEvent> message) {

		AMQPUtil.gerarLog(this.getClass(), message, DocumentoTransporteDocumentoCargaExcluidoEvent.CONDITIONAL_EXPRESSION);
		ZonedDateTime dataHoraEvento = ZonedDateTime.parse(message.getHeader().getGeneratedOn());
		service.on(message.getContent(),dataHoraEvento);

	}

}
