package com.totvs.sl.onboarding.query.util.repository;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@JsonSerialize(using = MetadataSerializer.class)
@NoArgsConstructor(staticName = "empty")
public class Metadata implements Serializable {

	private static final long serialVersionUID = 1L;

	private List<MetadataInfo> metadatas = new ArrayList<>();

	List<MetadataInfo> getMetadatas() {
		return this.metadatas;
	}

	void addMetadataInfo(final MetadataInfo metadataInfo) {
		this.metadatas.add(metadataInfo);
	}

	@NoArgsConstructor(access = AccessLevel.PRIVATE)
	@AllArgsConstructor(access = AccessLevel.PRIVATE)
	public static class MetadataInfo implements Serializable {

		private static final long serialVersionUID = 1L;

		private String propertyName;

		@Getter
		@Setter
		private ZonedDateTime generatedOn;

		String getpropertyName() {
			return this.propertyName;
		}

		public static MetadataInfo of(String propertyName, ZonedDateTime generatedOn) {
			return new MetadataInfo(propertyName, generatedOn);
		}

		public boolean isBefore(ZonedDateTime generatedOn) {
			return this.generatedOn == null || this.generatedOn.isBefore(generatedOn);
		}
	}

	public MetadataInfo getMetadataInfo(final String propertyName) {
		var metadataInfo = this.metadatas.stream()
										 .filter(info -> info.propertyName.equals(propertyName))
										 .findFirst()
										 .orElse(null);
		if (metadataInfo == null) {
			metadataInfo = MetadataInfo.of(propertyName, null);
			this.metadatas.add(metadataInfo);
		}
		return metadataInfo;
	}
}
