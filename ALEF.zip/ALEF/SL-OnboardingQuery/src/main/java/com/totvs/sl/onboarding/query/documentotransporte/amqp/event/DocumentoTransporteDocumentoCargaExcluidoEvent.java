package com.totvs.sl.onboarding.query.documentotransporte.amqp.event;

import lombok.*;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class DocumentoTransporteDocumentoCargaExcluidoEvent {

    public static final String NAME = "DocumentoTransporteDocumentoCargaExcluidoEvent";
    public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";


    private final String documentoTransporteId;
    private final String id;
}
