package com.totvs.sl.onboarding.query.documentocarga.service;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.totvs.sl.onboarding.query.documentocarga.amqp.event.DocumentoTransporteDocumentoCargaAdicionadoEvent;
import com.totvs.sl.onboarding.query.documentocarga.amqp.event.DocumentoTransporteDocumentoCargaExcluidoEvent;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaRepository;

import lombok.AllArgsConstructor;

@Service
@Transactional
@AllArgsConstructor
public class DocumentoCargaService {

	private final DocumentoCargaRepository repository;



}
