package com.totvs.sl.onboarding.query.cliente.amqp.event;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor(access = AccessLevel.PRIVATE, force = true)
public final class ClienteAlteradoEvent {

	public static final String NAME = "ClienteAlteradoEvent";
	public static final String CONDITIONAL_EXPRESSION = "headers['type']=='" + NAME + "'";

	private final String id;
	private final String nome;

}
