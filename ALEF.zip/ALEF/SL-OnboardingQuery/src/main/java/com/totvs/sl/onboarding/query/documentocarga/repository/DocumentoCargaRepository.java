package com.totvs.sl.onboarding.query.documentocarga.repository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import javax.persistence.LockModeType;

import com.totvs.sl.onboarding.query.documentocarga.api.dto.DocumentoCargaGetByIdDocumentoTransporteDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.totvs.sl.onboarding.query.documentocarga.exception.ONBDocumentoCargaNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.tjf.api.jpa.repository.ApiJpaRepository;
import com.totvs.tjf.api.jpa.repository.JpaSpecificationExecutorWithProjection;

@Repository
@Transactional(readOnly = true)
public interface DocumentoCargaRepository extends JpaRepository<DocumentoCargaModel, String>,
		ApiJpaRepository<DocumentoCargaModel>, JpaSpecificationExecutorWithProjection<DocumentoCargaModel> {

	@Override
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	Optional<DocumentoCargaModel> findById(String id);



	@Lock(LockModeType.PESSIMISTIC_WRITE)
	default DocumentoCargaModel findByIdOrThrowNotFound(String id) {
		return findById(id).orElseThrow(ONBDocumentoCargaNaoEncontradoException::new);
	}


	Collection<DocumentoCargaGetByIdDocumentoTransporteDTO> findBydocumentoTransporteId(String id);




}
