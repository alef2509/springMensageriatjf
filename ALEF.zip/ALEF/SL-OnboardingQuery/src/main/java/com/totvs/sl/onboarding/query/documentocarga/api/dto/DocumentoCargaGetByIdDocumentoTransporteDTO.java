package com.totvs.sl.onboarding.query.documentocarga.api.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.time.LocalDate;

@JsonPropertyOrder({ "id", "numero", "emissao", "serie", "modelo", "chaveAcesso"  })
public interface DocumentoCargaGetByIdDocumentoTransporteDTO {

    String getId();
    String getNumero();
    LocalDate getEmissao();
    String getSerie();
    String getModelo();
    String getChaveAcesso();
}
