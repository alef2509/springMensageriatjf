package com.totvs.sl.onboarding.query.documentotransporte.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.util.repository.Metadata;
import com.totvs.sl.onboarding.query.util.repository.Metadata.MetadataInfo;
import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

@Data
@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@DynamicUpdate
@Table(name = "documento_transporte")
@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class)
public class DocumentoTransporteModel {

	@Id
	private String id;

	@NotNull
	private String numero;

	@NotNull
	private String serie;

	@NotNull
	private ZonedDateTime emissao;

	@NotNull
	private String modelo;

	private String chaveAcesso;

	//@NotNull
	//@Enumerated(EnumType.STRING)
	//private SituacaoDocumento situacao;
	private String situacao;



	private String cotacaoFreteId;
	private String remetenteId;
	private String destinatarioId;
	private String pagadorFreteId;


	public void setChaveAcesso(String chaveAcesso, ZonedDateTime dataHoraEvento) {
		this.chaveAcesso = chaveAcesso;
	}

	public void setSituacao(String situacao, ZonedDateTime dataHoraEvento) {
		this.situacao = situacao;
	}

	public void setCotacaoFreteId(String cotacaoFreteId, ZonedDateTime dataHoraEvento) {
		this.cotacaoFreteId = cotacaoFreteId;
	}

	public void setRemetenteId(String remetenteId, ZonedDateTime dataHoraEvento) {
		this.remetenteId = remetenteId;
	}

	public void setDestinatarioId(String destinatarioId, ZonedDateTime dataHoraEvento) {
		this.destinatarioId = destinatarioId;
	}

	public void setPagadorFreteId(String pagadorFreteId, ZonedDateTime dataHoraEvento) {
		this.pagadorFreteId = pagadorFreteId;
	}

}
