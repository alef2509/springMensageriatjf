package com.totvs.sl.onboarding.query.documentotransporte.amqp;

import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.query.cliente.util.ClienteTestFactory;
import com.totvs.sl.onboarding.query.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.query.documentocarga.exception.ONBDocumentoCargaNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentotransporte.amqp.event.*;
import com.totvs.sl.onboarding.query.documentotransporte.api.dto.DocumentoTransporteGetByIdDTO;
import com.totvs.sl.onboarding.query.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.sl.onboarding.query.documentotransporte.model.SituacaoDocumento;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteRepository;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteSpecification;
import com.totvs.sl.onboarding.query.documentotransporte.util.DocumentoTransporteTestFactory;
import com.totvs.sl.onboarding.query.util.TestUtils;
import com.totvs.tjf.core.api.context.request.ApiFieldRequest;
import com.totvs.tjf.core.message.TOTVSMessage;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import com.totvs.sl.onboarding.query.util.ConfigIT;
import org.springframework.data.jpa.domain.Specification;


import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

@DisplayName("DocumentoTransporteSubscriberIT - Teste das APIs de consulta")
class DocumentoTransporteSubscriberIT extends ConfigIT {

    @Autowired
    private OnboardingChannel.OnboardingExchangeInput exchange;

    private final String id = UUID.randomUUID().toString();
    private final String numero = "1";
    private final String serie = "1";
    private final String modelo = "1";
    private final String chaveAcesso = "30399462417772944246614321172896928750631741";
    private final String remetenteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String cotacaoFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String destinatarioId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private final String pagadorFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private static final String situacao = "DIGITADO";
    private static final ZonedDateTime emissao = ZonedDateTime.now(ZoneId.of("UTC"));

    @BeforeAll
    static void beforeAll() {
        TestUtils.setAuthenticationInfo();
    }


    @Test
    void deveInserirUmNovoDocumentoTransporte() {

        // given
        var event = DocumentoTransporteCriadoEvent.builder()
                .id(id)
                .numero(numero)
                .serie(serie)
                .modelo(modelo)
                .chaveAcesso(chaveAcesso)
                .remetenteId(remetenteId)
                .situacao(situacao)
                .emissao(emissao)
                .cotacaoFreteId(cotacaoFreteId)
                .destinatarioId(destinatarioId)
                .pagadorFreteId(pagadorFreteId)
                .build();

        var message = new TOTVSMessage<DocumentoTransporteCriadoEvent>(DocumentoTransporteCriadoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporte = documentoTransporteRepository.findByIdOrThrowNotFound(id);

        assertThat(documentoTransporte.getId()).isEqualTo(event.getId());
        assertThat(documentoTransporte.getChaveAcesso()).isEqualTo(event.getChaveAcesso());
        assertThat(documentoTransporte.getSituacao()).isEqualTo(event.getSituacao());

    }

    @Test
    void deveAlterarInformacoesDeUmDocumentoTransporte() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var event = DocumentoTransporteAlteradoEvent.of(documentoTransporte.getId(), documentoTransporte.getCotacaoFreteId(),documentoTransporte.getRemetenteId(),
                                                                                   documentoTransporte.getDestinatarioId(), documentoTransporte.getPagadorFreteId());

        var message = new TOTVSMessage<DocumentoTransporteAlteradoEvent>(DocumentoTransporteAlteradoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAlterado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAlterado.getCotacaoFreteId()).isEqualTo(event.getCotacaoFreteId());
    }

    @Test
    void naoDeveAlterarInformacoesDeUmDocumentoTransporteQuandoEventoAtrasado() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        documentoTransporte.setCotacaoFreteId("11666b8e-51b0-4058-80a4-f1875b9442t4", ZonedDateTime.now().plusSeconds(5));
        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, documentoTransporte);

        var event = DocumentoTransporteAlteradoEvent.of(documentoTransporte.getId(), documentoTransporte.getCotacaoFreteId(),documentoTransporte.getRemetenteId(),
                documentoTransporte.getDestinatarioId(), documentoTransporte.getPagadorFreteId());

        var message = new TOTVSMessage<DocumentoTransporteAlteradoEvent>(DocumentoTransporteAlteradoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAlterado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAlterado.getCotacaoFreteId()).isEqualTo(documentoTransporte.getCotacaoFreteId());
    }

    @Test
    void deveAnularDocumentoTransporte() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var event = DocumentoTransporteAnuladoEvent.of(documentoTransporte.getId(), ZonedDateTime.now(), cotacaoFreteId);

        var message = new TOTVSMessage<DocumentoTransporteAnuladoEvent>(DocumentoTransporteAnuladoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAtualizado.getSituacao()).isEqualTo("ANULADO");
    }

    @Test
    void deveCancelarDocumentoTransporte() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var event = DocumentoTransporteCanceladoEvent.of(documentoTransporte.getId(), ZonedDateTime.now(), cotacaoFreteId);

        var message = new TOTVSMessage<DocumentoTransporteCanceladoEvent>(DocumentoTransporteCanceladoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAtualizado.getSituacao()).isEqualTo("CANCELADO");
    }


    @Test
    void deveAutorizarDocumentoTransporte() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var event = DocumentoTransporteAutorizadoEvent.of(documentoTransporte.getId(), ZonedDateTime.now(), cotacaoFreteId, documentoTransporte.getChaveAcesso());

        var message = new TOTVSMessage<DocumentoTransporteAutorizadoEvent>(DocumentoTransporteAutorizadoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAtualizado.getSituacao()).isEqualTo("AUTORIZADO");
    }

    @Test
    void deveTrazerDocumentoTransportePaginadoporId() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransportePorId = DocumentoTransporteSpecification.comId(documentoTransporte.getId());
        assertThat(documentoTransportePorId.getClass()).isEqualTo(documentoTransportePorId.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePaginadoporRemetenteIdId() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransportePorId = DocumentoTransporteSpecification.comremetenteId(documentoTransporte.getRemetenteId());
        assertThat(documentoTransportePorId.getClass()).isEqualTo(documentoTransportePorId.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePorPagadorFreteId() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.compagadorFreteId(documentoTransporte.getPagadorFreteId());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }


    @Test
    void deveTrazerDocumentoTransportePorSituacao() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.naSituacao(documentoTransporte.getSituacao());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePorChaveAcesso() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.comChaveAcesso(documentoTransporte.getChaveAcesso());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePorNumero() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.comNumero(documentoTransporte.getNumero());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePorEmissao() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.comEmissao(documentoTransporte.getEmissao());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }

    @Test
    void deveTrazerDocumentoTransportePorEmissaoAte() {
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());
        var documentoTransporteFiltrado = DocumentoTransporteSpecification.comEmissaoAte(documentoTransporte.getEmissao());
        assertThat(documentoTransporteFiltrado.getClass()).isEqualTo(documentoTransporteFiltrado.getClass());

    }

    @Test
    void deveAdicionarEdepoisExcluirCargaDocumentoTransporte() {

        var idCarga = DocumentoTransporteTestFactory.umDocumentoTransporteId();
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var eventAdicao = DocumentoTransporteDocumentoCargaAdicionadoEvent.of(documentoTransporte.getId(),
                idCarga, numero, LocalDate.now(), serie, modelo, chaveAcesso);

        var messageAdicao = new TOTVSMessage<DocumentoTransporteDocumentoCargaAdicionadoEvent>(DocumentoTransporteDocumentoCargaAdicionadoEvent.NAME, eventAdicao);

        messageAdicao.sendTo(exchange.input());


        var documentoCargaAdicionado = documentoCargaRepository.findByIdOrThrowNotFound(idCarga);

        assertThat(documentoCargaAdicionado.getDocumentoTransporteId()).isEqualTo(documentoTransporte.getId());




        var eventExclusao = DocumentoTransporteDocumentoCargaExcluidoEvent.of(documentoTransporte.getId(),
                idCarga);

        var messageExclusao = new TOTVSMessage<DocumentoTransporteDocumentoCargaExcluidoEvent>(DocumentoTransporteDocumentoCargaExcluidoEvent.NAME, eventExclusao);


        messageExclusao.sendTo(exchange.input());
        Assertions.assertThrows(ONBDocumentoCargaNaoEncontradoException.class, () -> documentoCargaRepository.findByIdOrThrowNotFound(idCarga));

    }


    @Test
    void deveExcluirCargaDocumentoTransporte() {

        // given
        var documentoTransporte = DocumentoTransporteTestFactory.persistir(documentoTransporteRepository, DocumentoTransporteTestFactory.umDocumentoTransporte());

        var event = DocumentoTransporteAutorizadoEvent.of(documentoTransporte.getId(), ZonedDateTime.now(), cotacaoFreteId, documentoTransporte.getChaveAcesso());

        var message = new TOTVSMessage<DocumentoTransporteAutorizadoEvent>(DocumentoTransporteAutorizadoEvent.NAME, event);

        // when
        message.sendTo(exchange.input());

        // then
        var documentoTransporteAtualizado = documentoTransporteRepository.findByIdOrThrowNotFound(documentoTransporte.getId().toString());

        assertThat(documentoTransporteAtualizado.getSituacao()).isEqualTo("AUTORIZADO");
    }

    @Test
    void deveRetornarDocumentoTransporteNaoEncontrado() {
        Assertions.assertThrows(ONBDocumentoTransporteNaoEncontradoException.class, () -> documentoTransporteRepository.findByIdOrThrowNotFound("99999154777799999999"));
    }




}
