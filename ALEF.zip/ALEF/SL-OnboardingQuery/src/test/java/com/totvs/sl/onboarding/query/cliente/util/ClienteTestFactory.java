package com.totvs.sl.onboarding.query.cliente.util;

import java.util.UUID;

import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteRepository;

public class ClienteTestFactory {

	private static final String NOME = "Lorem Ipsom Merol";
	private static final String CPF = "00000000191";

	public static String umClienteId() {
		return UUID.randomUUID().toString();
	}

	public static ClienteModel umClienteAtivo() {
		return umClienteBuilder().situacao("ATIVO").documento(CPF).pessoaFisica(true).build();
	}

	public static ClienteModel umClienteInativo() {
		return umClienteBuilder().situacao("INATIVO").documento(CPF).pessoaFisica(true).build();
	}

	public static ClienteModel.ClienteModelBuilder umClienteBuilder() {
		return ClienteModel.builder().id(umClienteId()).nome(NOME);
	}

	public static ClienteModel persistir(ClienteRepository repository, ClienteModel cliente) {
		repository.saveAndFlush(cliente);
		return cliente;
	}
}