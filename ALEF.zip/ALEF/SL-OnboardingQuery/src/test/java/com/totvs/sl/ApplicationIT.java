package com.totvs.sl;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class ApplicationIT {

	@Test
	void contextLoads() {
		Application.main(new String[] { "--spring.profiles.active=local" });
		assertTrue(true);
	}
}
