package com.totvs.sl.onboarding.query.cliente.api;

import static com.totvs.sl.onboarding.query.util.TestUtils.buildURL;
import static com.totvs.sl.onboarding.query.util.TestUtils.userToken;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import com.totvs.sl.onboarding.query.cliente.util.ClienteTestFactory;
import com.totvs.sl.onboarding.query.util.ConfigIT;

@DisplayName("ClienteControllerIT - Teste das APIs de consulta")
class ClienteControllerIT extends ConfigIT {

	@Autowired
	private MockMvc mock;

	@BeforeEach
	void setup() {

		ClienteTestFactory.persistir(clienteRepository,
									 ClienteTestFactory.umClienteBuilder()
													   .id("c5989507-44db-47d5-9fb1-56419cab846f")
													   .nome("CLIENTE PJ 01")
													   .documento("45014118000107")
													   .situacao("ATIVO")
													   .build());

		ClienteTestFactory.persistir(clienteRepository,
									 ClienteTestFactory.umClienteBuilder()
													   .id("82330af6-9ddb-4dc2-a308-aebd17e1eadf")
													   .nome("CLIENTE PJ 02")
													   .documento("80626232000199")
													   .situacao("INATIVO")
													   .build());

		ClienteTestFactory.persistir(clienteRepository,
									 ClienteTestFactory.umClienteBuilder()
													   .id("d3da3816-f143-4422-9863-c849f3d625d7")
													   .nome("CLIENTE PF 01")
													   .documento("36544893030")
													   .situacao("ATIVO")
													   .build());

		ClienteTestFactory.persistir(clienteRepository,
									 ClienteTestFactory.umClienteBuilder()
													   .id("2a83e24e-ab2b-4416-9721-2e916aa5a144")
													   .nome("CLIENTE PF 02")
													   .documento("30302323015")
													   .situacao("INATIVO")
													   .build());

	}

	@Test
	void deveRetornarTodosClientes() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(4)));
	}

	@Test
	void deveRetornarTodosClientesPaginados() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).with(userToken).param("page", "1").param("pageSize", "2"))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(true)))
			.andExpect(jsonPath("$.items.length()", is(2)));
	}

	@Test
	void deveRetornarTodosClientesOrdenadosPorNome() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).with(userToken)
														  .param("page", "1")
														  .param("pageSize", "2")
														  .param("order", "nome"))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(true)))
			.andExpect(jsonPath("$.items[0].nome", is("CLIENTE PF 01")))
			.andExpect(jsonPath("$.items.length()", is(2)));
	}

	@Test
	@DisplayName("Deve retornar uma lista de clientes conforme parâmetro nome")
	void deveRetornarTodosClientesComFiltroPorNome() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("nome", "CLIENTE PF")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(2)));
	}

	@Test
	@DisplayName("Deve retornar uma lista de clientes conforme parâmetro documento")
	void deveRetornarTodosClientesComFiltroPorDocumento() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("documento", "80626232000199")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(1)));
	}

	@Test
	@DisplayName("Deve retornar uma lista de clientes conforme parâmetro documento")
	void deveRetornarTodosClientesComFiltroPorSituacao() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("situacao", "ATIVO")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(2)));
	}

	@Test
	void deveRetornarTodosClientesConformeSearchTermPorNome() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("searchTerm", "CLIENTE PJ")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(2)));
	}

	@Test
	void deveRetornarTodosClientesConformeSearchTermPorDocumento() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("searchTerm", "45014118000107")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(1)))
			.andExpect(jsonPath("$.items[0].id", is("c5989507-44db-47d5-9fb1-56419cab846f")))
			.andExpect(jsonPath("$.items[0].nome", is("CLIENTE PJ 01")))
			.andExpect(jsonPath("$.items[0].documento", is("45014118000107")))
			.andExpect(jsonPath("$.items[0].pessoaFisica", is(false)))
			.andExpect(jsonPath("$.items[0].situacao", is("ATIVO")));
	}

	@Test
	void deveRetornarSomenteIdENomeDeTodosClientesConformeDocumento() throws Exception {
		mock.perform(get(buildURL(ClienteController.PATH)).param("page", "1")
														  .param("pageSize", "4")
														  .param("documento", "80626232000199")
														  .param("fields", "id")
														  .param("fields", "nome")
														  .with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.hasNext", is(false)))
			.andExpect(jsonPath("$.items.length()", is(1)))
			.andExpect(jsonPath("$.items[0].id", is("82330af6-9ddb-4dc2-a308-aebd17e1eadf")))
			.andExpect(jsonPath("$.items[0].nome", is("CLIENTE PJ 02")))
			.andExpect(jsonPath("$.items[0].documento").doesNotExist())
			.andExpect(jsonPath("$.items[0].pessoaFisica").doesNotExist())
			.andExpect(jsonPath("$.items[0].situacao").doesNotExist());
	}

	@Test
	@DisplayName("Deve retornar um acessório conforme parâmetro id")
	void deveRetornarUmClienteById() throws Exception {
		var id = "2a83e24e-ab2b-4416-9721-2e916aa5a144";
		mock.perform(get(buildURL(ClienteController.PATH + "/" + id)).with(userToken))
			.andExpect(status().is2xxSuccessful())
			.andExpect(jsonPath("$.id", is(id)));
	}

	@Test
	@DisplayName("Deve retornar exception GetById")
	void deveRetornarExceptionGetById() throws Exception {
		var result = mock.perform(get(buildURL(ClienteController.PATH + "/"
				+ UUID.randomUUID().toString())).with(userToken)).andExpect(status().isNotFound()).andReturn();

		assertThat(result.getResponse().getContentAsString()).contains("ONBClienteNaoEncontradoException");
	}
}