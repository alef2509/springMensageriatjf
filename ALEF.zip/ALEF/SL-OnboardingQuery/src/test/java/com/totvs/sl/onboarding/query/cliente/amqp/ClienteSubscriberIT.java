package com.totvs.sl.onboarding.query.cliente.amqp;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.ZonedDateTime;
import java.util.UUID;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAlteradoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteAtivadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteCriadoEvent;
import com.totvs.sl.onboarding.query.cliente.amqp.event.ClienteInativadoEvent;
import com.totvs.sl.onboarding.query.cliente.util.ClienteTestFactory;
import com.totvs.sl.onboarding.query.config.amqp.OnboardingChannel;
import com.totvs.sl.onboarding.query.util.ConfigIT;
import com.totvs.sl.onboarding.query.util.TestUtils;
import com.totvs.tjf.core.message.TOTVSMessage;

@DisplayName("ClienteSubscriberIT - Teste das APIs de consulta")
class ClienteSubscriberIT extends ConfigIT {

	@Autowired
	private OnboardingChannel.OnboardingExchangeInput exchange;

	private final String id = UUID.randomUUID().toString();
	private final String nome = "NOME CLIENTE";
	private final String novoNome = "NOVO NOME CLIENTE";
	private final String cpf = "05351821982";

	@BeforeAll
	static void beforeAll() {
		TestUtils.setAuthenticationInfo();
	}

	@Test
	void deveInserirUmNovoCliente() {

		// given
		var event = ClienteCriadoEvent.builder()
									  .id(id)
									  .nome(nome)
									  .documento(cpf)
									  .pessoaFisica(true)
									  .situacao("ATIVO")
									  .build();

		var message = new TOTVSMessage<ClienteCriadoEvent>(ClienteCriadoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var cliente = clienteRepository.findByIdOrThrowNotFound(id);

		assertThat(cliente.getNome()).isEqualTo(event.getNome());
		assertThat(cliente.getDocumento()).isEqualTo(event.getDocumento());
		assertThat(cliente.isPessoaFisica()).isTrue();
		assertThat(cliente.getSituacao()).isEqualTo(event.getSituacao());

	}

	@Test
	void deveAlterarInformacoesDeUmCliente() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var event = ClienteAlteradoEvent.of(cliente.getId(), novoNome);

		var message = new TOTVSMessage<ClienteAlteradoEvent>(ClienteAlteradoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAlterado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAlterado.getNome()).isEqualTo(event.getNome());
	}

	@Test
	void naoDeveAlterarInformacoesDeUmClienteQuandoEventoAtrasado() {

		// given
		var cliente = ClienteTestFactory.umClienteAtivo();
		cliente.setNome("JOAO", ZonedDateTime.now().plusSeconds(5));
		ClienteTestFactory.persistir(clienteRepository, cliente);

		var event = ClienteAlteradoEvent.of(cliente.getId(), novoNome);

		var message = new TOTVSMessage<ClienteAlteradoEvent>(ClienteAlteradoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAlterado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAlterado.getNome()).isEqualTo(cliente.getNome());
	}

	@Test
	void deveInativarUmCliente() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteAtivo());

		var event = ClienteInativadoEvent.of(cliente.getId(), "INATIVO");

		var message = new TOTVSMessage<ClienteInativadoEvent>(ClienteInativadoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAtualizado.getSituacao()).isEqualTo(event.getSituacao());
	}

	@Test
	void naoDeveInativarUmClienteQuandoEventoAtrasado() {

		// given
		var cliente = ClienteTestFactory.umClienteAtivo();
		cliente.setSituacao("ATIVO", ZonedDateTime.now().plusSeconds(5));
		ClienteTestFactory.persistir(clienteRepository, cliente);

		var event = ClienteInativadoEvent.of(cliente.getId(), "INATIVO");

		var message = new TOTVSMessage<ClienteInativadoEvent>(ClienteInativadoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAtualizado.getSituacao()).isEqualTo(cliente.getSituacao());
	}

	@Test
	void deveAtivarUmCliente() {

		// given
		var cliente = ClienteTestFactory.persistir(clienteRepository, ClienteTestFactory.umClienteInativo());

		var event = ClienteAtivadoEvent.of(cliente.getId(), "ATIVO");

		var message = new TOTVSMessage<ClienteAtivadoEvent>(ClienteAtivadoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAtualizado.getSituacao()).isEqualTo(event.getSituacao());
	}

	@Test
	void naoDeveAtivarUmClienteQuandoEventoAtrasado() {

		// given
		var cliente = ClienteTestFactory.umClienteInativo();
		cliente.setSituacao("INATIVO", ZonedDateTime.now().plusSeconds(5));
		ClienteTestFactory.persistir(clienteRepository, cliente);

		var event = ClienteAtivadoEvent.of(cliente.getId(), "ATIVO");

		var message = new TOTVSMessage<ClienteAtivadoEvent>(ClienteAtivadoEvent.NAME, event);

		// when
		message.sendTo(exchange.input());

		// then
		var clienteAtualizado = clienteRepository.findByIdOrThrowNotFound(cliente.getId().toString());

		assertThat(clienteAtualizado.getSituacao()).isEqualTo(cliente.getSituacao());
	}

}