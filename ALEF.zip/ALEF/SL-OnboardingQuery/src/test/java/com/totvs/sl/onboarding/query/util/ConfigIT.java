package com.totvs.sl.onboarding.query.util;

import javax.transaction.Transactional;

import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaRepository;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteRepository;

@AutoConfigureMockMvc
@SpringBootTest
@ActiveProfiles(profiles = "test")
@Transactional
public abstract class ConfigIT {

	@Autowired
	protected ObjectMapper objectMapper;

	@Autowired
	protected ClienteRepository clienteRepository;

	@Autowired
	protected DocumentoTransporteRepository documentoTransporteRepository;

	@Autowired
	protected DocumentoCargaRepository documentoCargaRepository;

}
