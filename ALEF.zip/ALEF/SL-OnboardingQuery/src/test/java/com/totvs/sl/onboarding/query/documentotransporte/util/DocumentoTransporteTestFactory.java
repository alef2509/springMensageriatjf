package com.totvs.sl.onboarding.query.documentotransporte.util;

import com.totvs.sl.onboarding.query.cliente.model.ClienteModel;
import com.totvs.sl.onboarding.query.cliente.repository.ClienteRepository;
import com.totvs.sl.onboarding.query.documentocarga.model.DocumentoCargaModel;
import com.totvs.sl.onboarding.query.documentocarga.repository.DocumentoCargaRepository;
import com.totvs.sl.onboarding.query.documentotransporte.model.DocumentoTransporteModel;
import com.totvs.sl.onboarding.query.documentotransporte.model.SituacaoDocumento;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteRepository;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.UUID;

public class DocumentoTransporteTestFactory {
    private static final String numero = "1";
    private static final String serie = "1";
    private static final String modelo = "1";
    private static final String chaveAcesso = "30399462417772944246614321172896928750631741";
    private static final String situacao = "DIGITADO";
    private static final String remetenteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private static final String cotacaoFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private static final String destinatarioId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private static final String pagadorFreteId = "11666b8e-51b0-4058-80a4-f1875b9447e5";
    private static final ZonedDateTime emissao = ZonedDateTime.now(ZoneId.of("UTC"));


    public static String umDocumentoTransporteId() {
        return UUID.randomUUID().toString();
    }

    public static DocumentoTransporteModel umDocumentoTransporte() {
        return umDocumentoTransporteBuilder().situacao("DIGITADO").build();
    }

    public static DocumentoTransporteModel.DocumentoTransporteModelBuilder umDocumentoTransporteBuilder() {
        return DocumentoTransporteModel.builder()
                .id(umDocumentoTransporteId())
                .numero(numero)
                .serie(serie)
                .emissao(emissao)
                .situacao(situacao)
                .modelo(modelo)
                .chaveAcesso(chaveAcesso)
                .remetenteId(remetenteId)
                .cotacaoFreteId(cotacaoFreteId)
                .destinatarioId(destinatarioId)
                .pagadorFreteId(pagadorFreteId);
    }



    public static DocumentoTransporteModel persistir(DocumentoTransporteRepository repository, DocumentoTransporteModel documentoTransporte) {
        repository.saveAndFlush(documentoTransporte);
        return documentoTransporte;
    }

    public static DocumentoCargaModel persistir(DocumentoCargaRepository repository, DocumentoCargaModel documentoCarga) {
        repository.saveAndFlush(documentoCarga);
        return documentoCarga;
    }
}
