package com.totvs.sl.onboarding.query.util;

import static com.totvs.tjf.mock.test.JWTTestProvider.oauth2JWT;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.web.servlet.request.RequestPostProcessor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.totvs.tjf.core.common.security.SecurityPrincipal;

public class TestUtils {

	private static ObjectMapper mapper = new ObjectMapper();

	public static String tenantId = "public";
	public static String userId = "1";
	public static RequestPostProcessor userToken = oauth2JWT(userId);

	public static void setAuthenticationInfo() {

		SecurityPrincipal principal = new SecurityPrincipal(String.valueOf(userId), tenantId, tenantId, tenantId);
		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(principal, null);
		SecurityContextHolder.getContext().setAuthentication(authentication);
	}

	static {
		mapper.registerModule(new JavaTimeModule());
	}

	public static String buildURL(String... args) {
		var url = "/";

		for (int i = 0; i < args.length; i++) {
			url += (url.length() > 1 ? "/" : "");
			url += args[i];
		}

		return url;
	}
}
