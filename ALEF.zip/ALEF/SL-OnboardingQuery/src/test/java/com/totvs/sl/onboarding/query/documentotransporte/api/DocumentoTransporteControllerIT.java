package com.totvs.sl.onboarding.query.documentotransporte.api;

import com.totvs.sl.onboarding.query.cliente.api.ClienteController;
import com.totvs.sl.onboarding.query.cliente.util.ClienteTestFactory;
import com.totvs.sl.onboarding.query.documentotransporte.api.dto.DocumentoTransporteGetByIdDTO;
import com.totvs.sl.onboarding.query.documentotransporte.exception.ONBDocumentoTransporteNaoEncontradoException;
import com.totvs.sl.onboarding.query.documentotransporte.repository.DocumentoTransporteSpecification;
import com.totvs.sl.onboarding.query.documentotransporte.util.DocumentoTransporteTestFactory;
import com.totvs.sl.onboarding.query.util.ConfigIT;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import static com.totvs.sl.onboarding.query.util.TestUtils.buildURL;
import static com.totvs.sl.onboarding.query.util.TestUtils.userToken;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@DisplayName("DocumentoTransporteControllerIT - Teste das APIs de consulta")
public class DocumentoTransporteControllerIT extends ConfigIT {

    @Autowired
    private MockMvc mock;

    @BeforeEach
    void setup() {

        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository,
                DocumentoTransporteTestFactory.umDocumentoTransporteBuilder()
                        .id("12330af6-9ddb-4dc2-a308-aebd17e1eadf")
                        .numero("1")
                        .serie("1")
                        .modelo("1")
                        .chaveAcesso("30399462417772944246614321172896928750631741")
                        .remetenteId("11666b8e-51b0-4058-80a4-f1875b9442t4")
                        .cotacaoFreteId("11666b8e-51b0-4058-80a4-f1875b9442t4")
                        .destinatarioId("11666b8e-51b0-4058-80a4-f1875b9442t4")
                        .pagadorFreteId("11666b8e-51b0-4058-80a4-f1875b9442t4")
                        .build());

        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository,
                DocumentoTransporteTestFactory.umDocumentoTransporteBuilder()
                        .id("22330af6-9ddb-4dc2-a308-aebd17e1eabc")
                        .numero("2")
                        .serie("2")
                        .modelo("2")
                        .chaveAcesso("30399462417772944246614321172896928750631742")
                        .remetenteId("11666b8e-51b0-4058-80a4-f1875b9442t5")
                        .cotacaoFreteId("11666b8e-51b0-4058-80a4-f1875b9442t5")
                        .destinatarioId("11666b8e-51b0-4058-80a4-f1875b9442t5")
                        .pagadorFreteId("11666b8e-51b0-4058-80a4-f1875b9442t5")
                        .build());

        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository,
                DocumentoTransporteTestFactory.umDocumentoTransporteBuilder()
                        .id("32330af6-9ddb-4dc2-a308-aebd17e1edef")
                        .numero("3")
                        .serie("3")
                        .modelo("3")
                        .chaveAcesso("30399462417772944246614321172896928750631743")
                        .remetenteId("11666b8e-51b0-4058-80a4-f1875b9442t6")
                        .cotacaoFreteId("11666b8e-51b0-4058-80a4-f1875b9442t6")
                        .destinatarioId("11666b8e-51b0-4058-80a4-f1875b9442t6")
                        .pagadorFreteId("11666b8e-51b0-4058-80a4-f1875b9442t6")
                        .build());

        DocumentoTransporteTestFactory.persistir(documentoTransporteRepository,
                DocumentoTransporteTestFactory.umDocumentoTransporteBuilder()
                        .id("42330af6-9ddb-4dc2-a308-aebd17e1eghi")
                        .numero("4")
                        .serie("4")
                        .modelo("4")
                        .chaveAcesso("30399462417772944246614321172896928750631744")
                        .remetenteId("11666b8e-51b0-4058-80a4-f1875b9442t7")
                        .cotacaoFreteId("11666b8e-51b0-4058-80a4-f1875b9442t7")
                        .destinatarioId("11666b8e-51b0-4058-80a4-f1875b9442t7")
                        .pagadorFreteId("11666b8e-51b0-4058-80a4-f1875b9442t7")
                        .build());

    }


    @Test
    void deveRetornarTodosDocumentoTransporte() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(false)))
                .andExpect(jsonPath("$.items.length()", is(4)));
    }

    @Test
    void deveRetornarTodosDocumentoTransportePaginados() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken).param("page", "1").param("pageSize", "2"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(true)))
                .andExpect(jsonPath("$.items.length()", is(2)));
    }


    @Test
    void deveRetornarTodosDocumentoTransporteOrdenadosPorserie() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "2")
                        .param("order", "serie"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(true)))
                .andExpect(jsonPath("$.items[0].serie", is("1")))
                .andExpect(jsonPath("$.items.length()", is(2)));
    }

    @Test
    void deveRetornarDocumentoTransportePorNumero() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "2")
                        .param("order", "numero"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(true)))
                .andExpect(jsonPath("$.items[0].id", is("12330af6-9ddb-4dc2-a308-aebd17e1eadf")))
                .andExpect(jsonPath("$.items.length()", is(2)));
    }

    @Test
    void deveRetornarDocumentoTransportePorId() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "2")
                        .param("order", "id"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(true)))
                .andExpect(jsonPath("$.items[0].id", is("12330af6-9ddb-4dc2-a308-aebd17e1eadf")))
                .andExpect(jsonPath("$.items.length()", is(2)));
    }

    @Test
    void deveRetornarDocumentoTransportePorChaveAcesso() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "2")
                        .param("order", "chaveAcesso"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(jsonPath("$.hasNext", is(true)))
                .andExpect(jsonPath("$.items[0].chaveAcesso", is("30399462417772944246614321172896928750631741")))
                .andExpect(jsonPath("$.items.length()", is(2)));
    }

    @Test
    void deveRetornarUmDocumentoTransportePorId() throws Exception {
        mock.perform(
                get(buildURL(DocumentoTransporteController.PATH + "/12330af6-9ddb-4dc2-a308-aebd17e1eadf")).with(userToken))
                        .andExpect(status().is2xxSuccessful())
        .andExpect(status().isOk());
    }

    @Test
    void deveRetornarDocumentoTransportesFiltradosPorSearchTerm() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "1")
                        .param("searchTerm", "30399462417772944246614321172896928750631741"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()", is(1)));

    }

    @Test
    void deveRetornarDocumentoTransportesFiltradosPorId() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "1")
                        .param("id", "30399462417772944246614321172896928750631741"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()", is(1)));

    }

    @Test
    void deveRetornarDocumentoTransportesFiltradosPorChaveAcesso() throws Exception {
        mock.perform(get(buildURL(DocumentoTransporteController.PATH)).with(userToken)
                        .param("page", "1")
                        .param("pageSize", "1")
                        .param("chaveAcesso", "30399462417772944246614321172896928750631743"))
                .andExpect(status().is2xxSuccessful())
                .andExpect(status().isOk()).andExpect(jsonPath("$.items.length()", is(1)));
    }
}
